# Render the preview on your computer

You need **Node.js 18 or newer** (https://nodejs.org) installed.

1. Unzip this folder to a **short path**, e.g. `C:\wv\cat` (long paths break `npm i` on Windows).
2. Open a terminal in that folder and run:

```
npm i
npx remotion render WhatIf out/preview_10s.mp4 --frames=0-299 --gl=angle --codec=h264 --crf=16 --pixel-format=yuv420p
```

The first run downloads a headless browser (about 100 MB). The finished clip is `out/preview_10s.mp4`
(0-10 s, 1080x1920, 30 fps, with sound).

Optional: `npx remotion studio` opens a live preview in your browser where you can scrub the timeline.

If the render shows a black picture, replace `--gl=angle` with `--gl=swangle`.
