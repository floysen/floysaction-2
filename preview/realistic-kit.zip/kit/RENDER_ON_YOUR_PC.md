# Realistic kit — look test

Needs Node.js 18+. Unzip to a short path (e.g. `C:\wv\kit`), then in Git Bash:

```
npm i
npx remotion studio                 # live preview: pick "KitTest", scrub the timeline
npx remotion render KitTest out/kit-test.mp4 --gl=angle      # 8 s test clip
npx remotion render KitTest out/kit-faces.mp4 --gl=angle --props='{"shot":"faces"}'
```

Kit components live in `src/kit/` (Sky, Character, FaceBlur, Nature, Surfaces, Post).
See MASTER_PROMPT_ADDENDUM_REALISTIC.md for the new style rules and MIXAMO_DOWNLOAD_LIST.md for what to download.
