import * as THREE from "three";
import React, { useMemo } from "react";
import { weave } from "../textures";

// Procedural faceless human, ~1.75 m. Head is a blank low-poly sphere: no face geometry or texture, ever.
type V3 = [number, number, number];

const Limb: React.FC<{ from: V3; to: V3; r: number; color: string; map?: THREE.Texture }> = ({ from, to, r, color, map }) => {
  const a = new THREE.Vector3(...from);
  const b = new THREE.Vector3(...to);
  const dir = b.clone().sub(a);
  const len = dir.length();
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
  const mid = a.clone().add(b).multiplyScalar(0.5);
  return (
    <mesh position={mid} quaternion={q} castShadow receiveShadow>
      <capsuleGeometry args={[r, Math.max(0.001, len - 2 * r), 3, 8]} />
      <meshStandardMaterial color={color} roughness={0.85} flatShading map={map} />
    </mesh>
  );
};

export type SeatedProps = {
  position: V3;
  yaw: number;
  // right-hand target in the character's local space
  handTarget: V3;
  hair: string;
  sweater: string;
  pants: string;
  skin: string;
  lean?: number;
};

// Seated pose: hips on seat (local y = 0), thighs forward, shins down to floor at local y = -0.47
export const SeatedPerson: React.FC<SeatedProps> = ({ position, yaw, handTarget, hair, sweater, pants, skin, lean = 0 }) => {
  const knit = useMemo(() => weave([3, 3]), []);
  const shoulderR: V3 = [0.2, 0.5, 0];
  const shoulderL: V3 = [-0.2, 0.5, 0];
  // right arm: two segments, elbow pushed outward/down
  const ht = new THREE.Vector3(...handTarget);
  const sr = new THREE.Vector3(...shoulderR);
  const elbowR = sr.clone().lerp(ht, 0.5).add(new THREE.Vector3(0.06, -0.08, -0.02));
  const e: V3 = [elbowR.x, elbowR.y, elbowR.z];
  return (
    <group position={position} rotation={[0, yaw, 0]}>
      <group rotation={[0, 0, lean]}>
        {/* hips + torso */}
        <mesh position={[0, 0.08, 0]} castShadow>
          <boxGeometry args={[0.36, 0.16, 0.24]} />
          <meshStandardMaterial color={pants} roughness={0.85} flatShading />
        </mesh>
        <mesh position={[0, 0.34, 0]} scale={[1.25, 1, 0.72]} castShadow receiveShadow>
          <capsuleGeometry args={[0.15, 0.32, 4, 10]} />
          <meshStandardMaterial color={sweater} roughness={0.85} flatShading map={knit} />
        </mesh>
        {/* neck + head (blank) */}
        <Limb from={[0, 0.6, 0]} to={[0, 0.72, 0.01]} r={0.055} color={skin} />
        <mesh position={[0, 0.79, 0.02]} castShadow>
          <icosahedronGeometry args={[0.12, 1]} />
          <meshStandardMaterial color={skin} roughness={0.8} flatShading />
        </mesh>
        {/* hair cap, slightly back, with a small fringe forward for facing direction */}
        <mesh position={[0, 0.83, -0.01]} scale={[1.08, 0.8, 1.1]} castShadow>
          <icosahedronGeometry args={[0.12, 1]} />
          <meshStandardMaterial color={hair} roughness={0.9} flatShading />
        </mesh>
        <mesh position={[0, 0.89, 0.07]} scale={[1, 0.35, 0.6]}>
          <icosahedronGeometry args={[0.1, 0]} />
          <meshStandardMaterial color={hair} roughness={0.9} flatShading />
        </mesh>
        {/* arms */}
        <Limb from={shoulderL} to={[-0.27, 0.22, 0.12]} r={0.055} color={sweater} map={knit} />
        <Limb from={[-0.27, 0.22, 0.12]} to={[-0.14, 0.12, 0.32]} r={0.05} color={sweater} map={knit} />
        <mesh position={[-0.12, 0.1, 0.36]}>
          <sphereGeometry args={[0.05, 8, 6]} />
          <meshStandardMaterial color={skin} roughness={0.8} flatShading />
        </mesh>
        <Limb from={shoulderR} to={e} r={0.055} color={sweater} map={knit} />
        <Limb from={e} to={handTarget} r={0.05} color={sweater} map={knit} />
        <mesh position={handTarget} scale={[1.1, 0.6, 1.3]}>
          <sphereGeometry args={[0.05, 8, 6]} />
          <meshStandardMaterial color={skin} roughness={0.8} flatShading />
        </mesh>
      </group>
      {/* legs */}
      <Limb from={[-0.1, 0.05, 0]} to={[-0.1, 0.07, 0.45]} r={0.075} color={pants} />
      <Limb from={[0.1, 0.05, 0]} to={[0.1, 0.07, 0.45]} r={0.075} color={pants} />
      <Limb from={[-0.1, 0.06, 0.45]} to={[-0.11, -0.4, 0.48]} r={0.065} color={pants} />
      <Limb from={[0.1, 0.06, 0.45]} to={[0.11, -0.4, 0.48]} r={0.065} color={pants} />
      <mesh position={[-0.11, -0.44, 0.53]} castShadow>
        <boxGeometry args={[0.1, 0.07, 0.22]} />
        <meshStandardMaterial color="#3A3330" roughness={0.9} flatShading />
      </mesh>
      <mesh position={[0.11, -0.44, 0.53]} castShadow>
        <boxGeometry args={[0.1, 0.07, 0.22]} />
        <meshStandardMaterial color="#3A3330" roughness={0.9} flatShading />
      </mesh>
    </group>
  );
};
