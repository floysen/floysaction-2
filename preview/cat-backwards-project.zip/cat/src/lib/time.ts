import { Easing, getInputProps, interpolate } from "remotion";
import beats from "../beats.json";

export const FPS = beats.meta.fps;
export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
export const smooth = (k: number) => k * k * (3 - 2 * k);
export const easeInOut = Easing.bezier(0.3, 0, 0.7, 1);

// 0→1 ramp between t0 and t1 (clamped, smoothstep)
export const ramp = (t: number, t0: number, t1: number) => smooth(clamp((t - t0) / (t1 - t0)));

export const fade = (t: number, tin: number, tout: number, d = 0.3) =>
  interpolate(t, [tin, tin + d, tout - d, tout], [0, 1, 1, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

export type Beat = (typeof beats.beats)[number];
export const beatAt = (t: number): Beat =>
  beats.beats.find((b) => t >= b.start && t < b.end) ?? beats.beats[beats.beats.length - 1];

type V3 = [number, number, number];
export const cameraAt = (t: number) => {
  const b = beatAt(t);
  const keys = b.camera.keys as [number, V3, V3, number][];
  let i = 0;
  while (i < keys.length - 2 && t > keys[i + 1][0]) i++;
  const [t0, p0, l0, f0] = keys[i];
  const [t1, p1, l1, f1] = keys[i + 1];
  let k = clamp((t - t0) / (t1 - t0));
  k = b.camera.ease === "inout" && i === 0 ? easeInOut(k) : k;
  const mix = (a: V3, c: V3): V3 => [lerp(a[0], c[0], k), lerp(a[1], c[1], k), lerp(a[2], c[2], k)];
  return { pos: mix(p0, p1), look: mix(l0, l1), fov: lerp(f0, f1, k), dof: Boolean((b.camera as { dof?: boolean }).dof) };
};

// --props='{"preview":true}' switches to cheaper AO/shadows for quick test renders
export const PREVIEW = Boolean((getInputProps() as { preview?: boolean }).preview);
