"""Synthesised 74 s soundtrack for "What if everyone shared one mind except you?".

No music. Ambience kept low (>= 8 dB under the SFX). The crowd's sounds are always in unison.
"""
import sys
import numpy as np
import soundfile as sf
from scipy.signal import butter, sosfilt

SR = 44100
DUR = 74.0
N = int(SR * DUR)
rng = np.random.default_rng(11)
tt = np.arange(N) / SR


def db(x):
    return 10 ** (x / 20)


def filt(x, kind, f):
    return sosfilt(butter(2, f, kind, fs=SR, output="sos"), x)


def edge(x, ms=12):
    n = min(max(1, int(SR * ms / 1000)), len(x) // 2)
    x = x.copy()
    x[:n] *= np.linspace(0, 1, n)
    x[-n:] *= np.linspace(1, 0, n)
    return x


def norm(x):
    return x / (np.max(np.abs(x)) + 1e-9)


L = np.zeros(N)
R = np.zeros(N)


def place(x, t, level, pan=0.0):
    i = int(t * SR)
    if i >= N:
        return
    x = edge(norm(x)) * db(level)
    n = min(len(x), N - i)
    a = np.pi / 4 * (pan + 1)
    L[i:i + n] += x[:n] * np.cos(a)
    R[i:i + n] += x[:n] * np.sin(a)


def env(t0, t1, fin=0.3, fout=0.3):
    up = np.clip((tt - t0) / max(fin, 1e-3), 0, 1)
    dn = np.clip((t1 - tt) / max(fout, 1e-3), 0, 1)
    return np.sin(up * np.pi / 2) * np.sin(dn * np.pi / 2)


def bed(seed, lo, hi, level, e):
    for ch, s in ((L, seed), (R, seed + 100)):
        x = np.random.default_rng(s).standard_normal(N)
        x = filt(x, "bandpass", [lo, hi]) if lo else filt(x, "lowpass", hi)
        ch += norm(x) * e * db(level)


# ---------- ambience (quiet) ----------
FREEZE = 5.6
# busy plaza: murmur (formant-ish bandpassed noise with syllable modulation) + traffic, cut dead at the freeze
mur = env(0, FREEZE, 0.3, 0.01)
syll = 0.6 + 0.4 * np.abs(np.sin(2 * np.pi * 3.1 * tt + np.sin(2 * np.pi * 0.7 * tt) * 3))
for ch, s in ((L, 1), (R, 2)):
    x = filt(np.random.default_rng(s).standard_normal(N), "bandpass", [250, 2500]) * syll
    ch += norm(x) * mur * db(-32)
bed(3, 0, 300, -36, env(0, FREEZE, 0.3, 0.01))           # distant traffic rumble
for k in range(16):                                         # scattered free footsteps before the freeze
    t0 = rng.random() * 5.4
    n = int(0.06 * SR)
    place(filt(rng.standard_normal(n), "bandpass", [300, 2500]) * np.exp(-np.linspace(0, 8, n)), t0, -38 - rng.random() * 6, rng.random() * 1.6 - 0.8)
# fountain: continuous until 66 s (dips inside the silences)
fount = env(0, 66.0, 0.3, 0.6)
bed(4, 1200, 6000, -38, fount)
bed(5, 0, 160, -40, env(18, 22, 0.4, 0.4))                 # even car passes (no horns)
bed(6, 300, 1500, -38, env(34, 46, 0.6, 0.6))              # wind in the trees
bed(7, 0, 200, -36, env(58, 61.5, 1.0, 1.5))               # city hum swells, then fades

# ---------- SFX ----------


def step(f=110, n=0.12):
    k = np.arange(int(n * SR)) / SR
    return filt(rng.standard_normal(len(k)), "bandpass", [200, 2200]) * np.exp(-k * 45) + np.sin(2 * np.pi * f * k) * np.exp(-k * 30) * 0.6


def burst(seconds, lo, hi, decay):
    n = int(seconds * SR)
    return filt(rng.standard_normal(n), "bandpass", [lo, hi]) * np.exp(-np.linspace(0, decay, n))


def chime(freqs, seconds, decay):
    k = np.arange(int(seconds * SR)) / SR
    return sum(np.sin(2 * np.pi * f * k) * np.exp(-k * decay * (1 + j * 0.4)) for j, f in enumerate(freqs))


def mixa(*xs):
    n = max(len(x) for x in xs)
    out = np.zeros(n)
    for x in xs:
        out[:len(x)] += x
    return out


def riser():
    n = int(0.8 * SR)
    k = np.arange(n) / SR
    f = 400 * (3800 / 400) ** (k / 0.8)
    return (np.sin(2 * np.pi * np.cumsum(f) / SR) * 0.4 + filt(rng.standard_normal(n), "highpass", 2000) * 0.6) * (k / 0.8) ** 2


def hit(f0=55, f1=36, tail=1.6):
    n = int(tail * SR)
    k = np.arange(n) / SR
    f = f0 * (f1 / f0) ** np.minimum(k / 0.4, 1)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-k * 3) * 0.8 + filt(rng.standard_normal(n), "lowpass", 800) * np.exp(-k * 16) * 0.35


# accent 1: the freeze
place(riser(), FREEZE - 0.8, -26)
place(hit(), FREEZE, -14)
# pigeons scatter
wings = np.zeros(int(1.4 * SR))
for k in range(30):
    i = int(rng.random() * 1.1 * SR)
    b = burst(0.04, 600, 4000, 6)
    wings[i:i + len(b)] += b * (0.5 + rng.random() * 0.5)
place(wings, FREEZE + 0.05, -26, 0.3)

# unison footsteps: one big step every 0.556 s from 6.4 to 34 (then lighter until the turn)
stepper = mixa(*[step(100 + 15 * j, 0.14) * (0.8 + 0.4 * rng.random()) for j in range(6)])
t = 6.4
while t < 46.3:
    place(stepper, t, -22 if t < 34 else -27, 0.0)
    t += 1 / 1.8
# 9 cups set down on one frame
place(mixa(chime([3100, 4700, 6200], 0.35, 14), burst(0.05, 2000, 8000, 10)), 12.2, -20, -0.5)
# guitar strum decay
place(sum(np.sin(2 * np.pi * f * np.arange(int(2.2 * SR)) / SR) * np.exp(-np.arange(int(2.2 * SR)) / SR * 2.2) for f in (196, 247, 294, 392)), 14.4, -30, 0.5)
# traffic-light relay click
place(mixa(burst(0.04, 1500, 6000, 12), chime([900], 0.05, 60)), 18.2, -24, 0.4)
# typing passes from one laptop to the next
for k in range(22):
    place(burst(0.03, 1500, 6000, 6), 22.05 + k * 0.17 + (k % 3) * 0.02, -32, -0.6 + min(1.2, k * 0.06))
# phone buzz, then cut
n = int(0.9 * SR)
k = np.arange(n) / SR
place(np.sin(2 * np.pi * 180 * k) * (0.5 + 0.5 * np.sign(np.sin(2 * np.pi * 4 * k))), 25.4, -24)
# crowd inhale
place(filt(rng.standard_normal(int(1.2 * SR)), "bandpass", [400, 3000]) * np.sin(np.linspace(0, np.pi, int(1.2 * SR))) ** 2, 34.3, -28)
# child scuff + many arms rustle
place(burst(0.2, 300, 3000, 10), 38.4, -24, 0.4)
place(burst(0.8, 800, 5000, 4), 38.5, -26, 0.4)
# accent 2: they turn
place(riser(), 46.3 - 0.8, -28)
place(hit(62, 40, 1.4), 46.3, -17)
place(burst(0.8, 600, 4000, 3), 46.3, -24)                  # one shared fabric shift
# windows clicking on, as one soft thump
place(mixa(hit(90, 70, 0.5) * 0.7, burst(0.05, 1000, 5000, 15)), 54.2, -24)
# the stranger's four footsteps (not in unison)
for j, t0 in enumerate((54.2, 54.62, 55.06, 55.48)):
    place(step(120, 0.12), t0, -26 + j, 0.2)
# you stand: chair scrape + one step
n = int(0.5 * SR)
scr = filt(rng.standard_normal(n), "bandpass", [700, 2400]) * (0.6 + 0.4 * np.sin(np.arange(n) / SR * 2 * np.pi * 40)) * np.hanning(n)
place(scr, 62.6, -26, -0.2)
place(step(100, 0.14), 63.2, -24)
# end-card stinger: one soft synthesised tone, long decay
k = np.arange(int(5.5 * SR)) / SR
place((np.sin(2 * np.pi * 110 * k) + 0.4 * np.sin(2 * np.pi * 165 * k) + 0.2 * np.sin(2 * np.pi * 220.5 * k)) * np.exp(-k * 0.9) * np.minimum(k / 0.3, 1), 68.0, -20)

mix = np.stack([L, R], axis=1)
# scripted silences: beat 13 (only fountain + wind faintly) and the end (total)
duck = np.ones(N)
duck *= 1 - 0.85 * env(50.4, 53.6, 0.08, 0.08)
mix *= duck[:, None]
mix = mix / np.max(np.abs(mix)) * db(-1)
sf.write(sys.argv[1], mix.astype(np.float32), SR, subtype="PCM_16")
print("wrote", sys.argv[1], round(mix.shape[0] / SR, 2), "s")
