// Story state as pure functions of time t (seconds). Everything the scenes need per frame.
import { clamp, lerp, ramp } from "./lib/time";

type V3 = [number, number, number];

export const beatIndex = (t: number) => {
  const starts = [0, 6, 10, 14, 18, 22, 26, 30, 34, 38, 42, 46, 50, 54, 58];
  let i = 0;
  while (i < starts.length - 1 && t >= starts[i + 1]) i++;
  return i + 1; // 1-based beat id
};

export type Sky = "dusk" | "noon" | "overcast" | "golden" | "evening" | "dawn";

export type Light = {
  sky: Sky;
  keyColor: string;
  keyIntensity: number;
  keyPos: V3;
  hemiSky: string;
  hemiGround: string;
  hemi: number;
  lamp: number; // floor lamp 0..1
  bloom: number;
  sat: number;
  contrast: number;
  white: number; // white dissolve overlay 0..1
  rain: boolean;
};

export const lightAt = (t: number): Light => {
  const b = beatIndex(t);
  const base: Light = {
    sky: "dusk", keyColor: "#F2B07A", keyIntensity: 2.4, keyPos: [-3.2, 3.6, -9.5],
    hemiSky: "#CFD8E6", hemiGround: "#6A5040", hemi: 0.75, lamp: 1, bloom: 0.45, sat: 0.06, contrast: 0.06, white: 0, rain: false,
  };
  if (b <= 3) {
    // act 1: sunset; the last sun leaves the window during beat 3
    const k = b === 3 ? ramp(t, 10.5, 14) : 0;
    return { ...base, keyIntensity: lerp(2.4, 1.2, k) };
  }
  if (b === 7) {
    return { ...base, sky: "overcast", keyColor: "#E8ECF0", keyIntensity: 0.9, keyPos: [-3, 7, -9], hemiSky: "#C9D2DC", hemiGround: "#7A7068", hemi: 1.05, lamp: 0, bloom: 0.25, sat: -0.02, contrast: 0.04, rain: true };
  }
  if (b <= 8) {
    return { ...base, sky: "noon", keyColor: "#FFF4E0", keyIntensity: 2.6, keyPos: [-3, 7.5, -9], hemiSky: "#D6E2EE", hemiGround: "#7A6450", hemi: 0.95, lamp: 0, bloom: 0.3, sat: 0.04 };
  }
  if (b === 13) {
    return { ...base, sky: "evening", keyColor: "#E8A070", keyIntensity: 1.4, keyPos: [-3.4, 2.6, -9.5], hemiSky: "#B8C0D8", hemiGround: "#5A4A40", hemi: 0.7, lamp: 1, bloom: 0.5, sat: 0.02, contrast: 0.05 };
  }
  if (b <= 12) {
    return { ...base, sky: "golden", keyColor: "#FFD89A", keyIntensity: 2.6, keyPos: [-3, 5.5, -9], hemiSky: "#DCE4EE", hemiGround: "#7A6048", hemi: 0.95, lamp: 0, bloom: 0.55, sat: 0.1, contrast: 0.04 };
  }
  if (b === 14) {
    return { ...base, sky: "dawn", keyColor: "#FFF8EE", keyIntensity: 2.2, keyPos: [-3, 2.4, -9], hemiSky: "#EEE8F0", hemiGround: "#8A7A6A", hemi: 1.1, lamp: 0, bloom: 0.8, sat: -0.05, contrast: -0.08, white: lerp(0, 0.4, ramp(t, 54.3, 58)) };
  }
  // beat 15: memory (shelter) — starts out of white
  return { ...base, sky: "dusk", keyIntensity: 0, hemiSky: "#E8D8C0", hemiGround: "#3A3430", hemi: 0.45, lamp: 0, bloom: 0.7, sat: -0.03, contrast: 0.02, white: lerp(0.4, 0, ramp(t, 58, 58.6)) };
};

// --- time passing in the room ---
const YEARS = [2025, 2025, 2025, 2028, 2029, 2030, 2031, 2032, 2033, 2035, 2036, 2038, 2039, 2039, 2010];
export const yearAt = (t: number) => YEARS[beatIndex(t) - 1];
const PHOTOS = [1, 1, 1, 2, 2, 2, 2, 3, 4, 5, 5, 6, 6, 6, 0];
export const photosAt = (t: number) => PHOTOS[beatIndex(t) - 1];

export const hairGreyAt = (t: number) => {
  const b = beatIndex(t);
  if (b < 8) return 0;
  if (b === 8) return lerp(0, 0.3, ramp(t, 30.2, 30.8));
  return [0.4, 0.45, 0.5, 0.7, 0.8, 1.0, 0][b - 9];
};

// cat size (1 = adult) and grey patches by beat
const SCALE = [1, 1, 1, 1, 1, 1, 1, 1, 1, 0.9, 0.8, 0.5, 0.4, 0.32, 0.27];
export const catScaleAt = (t: number) => {
  const b = beatIndex(t);
  if (b === 12) return lerp(0.58, 0.5, ramp(t, 46.2, 46.7));
  return SCALE[b - 1];
};
export const catGreyAt = (t: number) => {
  if (t < 6.2) return 0.6;
  if (t < 10.3) return lerp(0.6, 0.52, ramp(t, 6.2, 6.6));
  if (t < 14) return lerp(0.52, 0.18, ramp(t, 10.3, 11.0));
  return 0;
};

// ballistic hop between two points (no squash/overshoot)
export const hop = (t: number, t0: number, dur: number, a: V3, b: V3, h: number): V3 => {
  const k = clamp((t - t0) / dur);
  return [lerp(a[0], b[0], k), lerp(a[1], b[1], k) + 4 * h * k * (1 - k), lerp(a[2], b[2], k)];
};

export const YOU = { hair: "#5A3A28", top: "#C98A3A", pants: "#2E3A4A", skin: "#C99A7A" };
export const DAUGHTER = { hair: "#3A2418", top: "#E8C04A", pants: "#E8C04A", skin: "#D8AA88", dress: true };
