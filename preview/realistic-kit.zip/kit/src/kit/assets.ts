// Cached, render-blocking asset loaders (Remotion waits for every delayRender before capturing a frame).
import * as THREE from "three";
import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { useThree } from "@react-three/fiber";
import { continueRender, delayRender, staticFile } from "remotion";
import { GLTFLoader, type GLTF } from "three/examples/jsm/loaders/GLTFLoader.js";
import { RGBELoader } from "three/examples/jsm/loaders/RGBELoader.js";

const cache = new Map<string, Promise<unknown>>();

function load<T>(key: string, fn: () => Promise<T>): Promise<T> {
  let p = cache.get(key) as Promise<T> | undefined;
  if (!p) {
    p = fn();
    cache.set(key, p);
  }
  return p;
}

// all handles released after ONE shared double redraw (many instances may resolve in the same tick)
const pending: number[] = [];
let scheduled = false;
function release(h: number, advance: (t: number) => void) {
  pending.push(h);
  if (scheduled) return;
  scheduled = true;
  const step = (n: number) => {
    try {
      advance(performance.now());
    } catch (e) {
      console.error("asset redraw failed", e);
    }
    if (n > 1) requestAnimationFrame(() => step(n - 1));
    else {
      scheduled = false;
      pending.splice(0).forEach((x) => continueRender(x));
    }
  };
  requestAnimationFrame(() => step(2));
}

// suspend-free hook: blocks the frame with delayRender until the asset is loaded AND drawn.
// Remotion drives r3f manually, so after the asset arrives we advance the canvas twice before releasing.
function useAsset<T>(key: string, fn: () => Promise<T>): T | null {
  const [value, setValue] = useState<T | null>(null);
  const handle = useRef<number | null>(null);
  const { advance } = useThree();
  useLayoutEffect(() => {
    if (value) return;
    handle.current = delayRender(`asset:${key}`, { timeoutInMilliseconds: 120000 });
    let alive = true;
    load(key, fn).then((v) => alive && setValue(v));
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  useEffect(() => {
    if (!value || handle.current === null) return;
    const h = handle.current;
    handle.current = null;
    release(h, advance);
  }, [value, advance]);
  return value;
}

export const useGLTF = (file: string) =>
  useAsset<GLTF>(`gltf:${file}`, () => new GLTFLoader().loadAsync(staticFile(file)));

export const useHDR = (file: string) =>
  useAsset<THREE.DataTexture>(`hdr:${file}`, async () => {
    const tex = await new RGBELoader().loadAsync(staticFile(file));
    tex.mapping = THREE.EquirectangularReflectionMapping;
    return tex;
  });

export const useTexture = (file: string, repeat: [number, number] = [1, 1], color = false) =>
  useAsset<THREE.Texture>(`tex:${file}:${repeat.join("x")}`, async () => {
    const tex = await new THREE.TextureLoader().loadAsync(staticFile(file));
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(...repeat);
    if (color) tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 8;
    return tex;
  });

export const HDRI = {
  sunrise: "assets/hdri/spruit_sunrise_1k.hdr",
  sunrise2: "assets/hdri/blouberg_sunrise_2_1k.hdr",
  city: "assets/hdri/pedestrian_overpass_1k.hdr",
  plaza: "assets/hdri/royal_esplanade_1k.hdr",
  bridge: "assets/hdri/san_giuseppe_bridge_2k.hdr",
  open: "assets/hdri/quarry_01_1k.hdr",
  sunset: "assets/hdri/venice_sunset_1k.hdr",
  night: "assets/hdri/moonless_golf_1k.hdr",
} as const;
export type HdriName = keyof typeof HDRI;
