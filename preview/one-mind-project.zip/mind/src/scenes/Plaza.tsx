import * as THREE from "three";
import React, { useMemo } from "react";
import { random } from "remotion";
import { textTex, weave } from "../three/textures";
import { SeatedPerson, StandingPerson } from "../three/chars/Faceless";
import { clamp, lerp, ramp } from "../lib/time";
import {
  beatIndex, billboardText, carAt, clockText, crosserAt, DIR, FREEZE, GUESTS, guestLook, Light, N_CARS, N_CROSSERS, N_WALKERS,
  rimAt, sipAt, Sky, STAND, TABLES, TURN, V3, walkerAt, YOU_LOOK, YOU_POS, YOU_YAW,
} from "../story";

// ---------- helpers ----------
const Box: React.FC<{ p: V3; s: V3; c: string; map?: THREE.Texture; r?: number; shadow?: boolean; rot?: V3; emissive?: string; ei?: number; emap?: THREE.Texture }> = ({ p, s, c, map, r = 0.8, shadow = true, rot, emissive, ei = 0, emap }) => (
  <mesh position={p} rotation={rot} castShadow={shadow} receiveShadow>
    <boxGeometry args={s} />
    <meshStandardMaterial color={c} roughness={r} flatShading map={map} emissive={emissive ?? "#000000"} emissiveIntensity={ei} emissiveMap={emap} />
  </mesh>
);

const tiled = (key: string, size: number, rep: [number, number], draw: (g: CanvasRenderingContext2D, s: number) => void) => {
  const tex = textTex(key, size, size, (g) => draw(g, size));
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(rep[0], rep[1]);
  tex.anisotropy = 8;
  return tex;
};

const slabs = () =>
  tiled("slabs", 512, [14, 12], (g, s) => {
    g.fillStyle = "#EEEEEE";
    g.fillRect(0, 0, s, s);
    for (let i = 0; i < 2600; i++) {
      const v = 200 + Math.floor(random(`sl${i}`) * 50);
      g.fillStyle = `rgba(${v},${v},${v},0.5)`;
      g.fillRect(random(`sx${i}`) * s, random(`sy${i}`) * s, 2, 2);
    }
    g.strokeStyle = "rgba(120,120,120,0.55)";
    g.lineWidth = 3;
    for (let k = 0; k <= 4; k++) {
      g.beginPath(); g.moveTo(0, (k * s) / 4); g.lineTo(s, (k * s) / 4); g.stroke();
    }
    for (let row = 0; row < 4; row++)
      for (let k = 0; k <= 2; k++) {
        const x = ((k + (row % 2) * 0.5) * s) / 2;
        g.beginPath(); g.moveTo(x, (row * s) / 4); g.lineTo(x, ((row + 1) * s) / 4); g.stroke();
      }
  });

const asphalt = () =>
  tiled("asphalt", 256, [12, 1], (g, s) => {
    g.fillStyle = "#E4E4E4";
    g.fillRect(0, 0, s, s);
    for (let i = 0; i < 3000; i++) {
      const v = 170 + Math.floor(random(`as${i}`) * 80);
      g.fillStyle = `rgba(${v},${v},${v},0.6)`;
      g.fillRect(random(`ax${i}`) * s, random(`ay${i}`) * s, 1.5, 1.5);
    }
    g.strokeStyle = "rgba(110,110,110,0.4)";
    for (let k = 0; k < 4; k++) {
      g.beginPath();
      let x = random(`ac${k}`) * s, y = random(`ad${k}`) * s;
      g.moveTo(x, y);
      for (let j = 0; j < 6; j++) { x += (random(`ae${k}${j}`) - 0.5) * 40; y += (random(`af${k}${j}`) - 0.5) * 40; g.lineTo(x, y); }
      g.stroke();
    }
  });

// façade: day map (light wall, darker windows) + emissive map (windows only)
const facade = (lit: boolean) =>
  tiled(`facade-${lit}`, 256, [4, 3], (g, s) => {
    g.fillStyle = lit ? "#000000" : "#F0F0F0";
    g.fillRect(0, 0, s, s);
    for (let r = 0; r < 4; r++)
      for (let c = 0; c < 4; c++) {
        g.fillStyle = lit ? "#FFFFFF" : "#8A93A0";
        g.fillRect(14 + c * 62, 12 + r * 62, 34, 40);
        if (!lit) { g.fillStyle = "#D8D8D8"; g.fillRect(12 + c * 62, 52 + r * 62, 38, 4); }
      }
  });

const SKIES: Record<Sky, string[]> = {
  morning: ["#5F8CC8", "#9EC0E4", "#DDE8F2", "#F2EEE6"],
  noon: ["#4F84C8", "#8FB6E0", "#D6E6F2", "#EEF2F6"],
  golden: ["#7A8CC0", "#C8B8C8", "#F2C890", "#F6D8A8"],
  dusk: ["#2A2450", "#4A3A6A", "#9A6A8A", "#C98A8A"],
  night: ["#0C0E20", "#141A3A", "#1C2147", "#2A2C58"],
};
const skyTex = (s: Sky) =>
  textTex(`psky-${s}`, 16, 256, (g) => {
    const gr = g.createLinearGradient(0, 0, 0, 256);
    SKIES[s].forEach((c, i) => gr.addColorStop([0, 0.35, 0.47, 0.52][i], c));
    gr.addColorStop(1, SKIES[s][3]);
    g.fillStyle = gr;
    g.fillRect(0, 0, 16, 256);
  });

const signTex = (key: string, text: string, w: number, h: number, bg: string, fg: string, font: string) =>
  textTex(`${key}-${text}`, w, h, (g) => {
    g.fillStyle = bg;
    g.fillRect(0, 0, w, h);
    g.fillStyle = fg;
    g.font = font;
    g.textAlign = "center";
    g.textBaseline = "middle";
    g.fillText(text, w / 2, h / 2);
  });

const toWorld = (local: V3, pos: V3, yaw: number): V3 => {
  const v = new THREE.Vector3(...local).applyAxisAngle(new THREE.Vector3(0, 1, 0), yaw).add(new THREE.Vector3(...pos));
  return [v.x, v.y, v.z];
};
const toLocal = (w: V3, pos: V3, yaw: number): V3 => {
  const v = new THREE.Vector3(...w).sub(new THREE.Vector3(...pos)).applyAxisAngle(new THREE.Vector3(0, 1, 0), -yaw);
  return [v.x, v.y, v.z];
};
const faceTo = (from: V3, to: V3) => Math.atan2(to[0] - from[0], to[2] - from[2]);
const mixV = (a: V3, b: V3, k: number): V3 => [lerp(a[0], b[0], k), lerp(a[1], b[1], k), lerp(a[2], b[2], k)];

const Points: React.FC<{ n: number; seed: string; size: number; color: string; opacity: number; additive?: boolean; at: (i: number, r: (k: string) => number) => V3 | null }> = ({ n, seed, size, color, opacity, additive, at }) => {
  const geo = useMemo(() => new THREE.BufferGeometry(), []);
  const pos = new Float32Array(n * 3);
  let m = 0;
  for (let i = 0; i < n; i++) {
    const p = at(i, (k) => random(`${seed}${k}${i}`));
    if (!p) continue;
    pos.set(p, m * 3);
    m++;
  }
  geo.setAttribute("position", new THREE.BufferAttribute(pos.slice(0, m * 3), 3));
  return (
    <points geometry={geo}>
      <pointsMaterial color={color} size={size} transparent opacity={opacity} depthWrite={false} blending={additive ? THREE.AdditiveBlending : THREE.NormalBlending} />
    </points>
  );
};

// ---------- environment pieces ----------
const Tree: React.FC<{ p: V3; t: number; h: number; seed: string; leaf: string }> = ({ p, t, h, seed, leaf }) => {
  const sway = Math.sin(t * 0.75 + p[0] * 0.13 + p[2] * 0.07) * 0.16;
  return (
    <group position={p}>
      <mesh position={[0, h * 0.3, 0]} castShadow>
        <cylinderGeometry args={[0.16, 0.24, h * 0.6, 6]} />
        <meshStandardMaterial color="#6A5A48" roughness={0.9} flatShading />
      </mesh>
      <mesh position={[sway, h * 0.75, 0]} rotation={[0, random(seed) * 3, sway * 0.2]} castShadow>
        <icosahedronGeometry args={[h * 0.3, 0]} />
        <meshStandardMaterial color={leaf} roughness={0.9} flatShading />
      </mesh>
      <mesh position={[sway * 1.2 + h * 0.12, h * 0.9, h * 0.08]} castShadow>
        <icosahedronGeometry args={[h * 0.2, 0]} />
        <meshStandardMaterial color={leaf} roughness={0.9} flatShading />
      </mesh>
    </group>
  );
};

const Building: React.FC<{ p: V3; s: V3; c: string; night: number }> = ({ p, s, c, night }) => {
  const day = useMemo(() => facade(false), []);
  const lit = useMemo(() => facade(true), []);
  return <Box p={[p[0], s[1] / 2, p[2]]} s={s} c={c} map={day} r={0.85} emissive="#E8E0FF" ei={night * 1.3} emap={lit} />;
};

const Car: React.FC<{ pos: V3; yaw: number; color: string; night: number }> = ({ pos, yaw, color, night }) => (
  <group position={pos} rotation={[0, yaw, 0]}>
    <Box p={[0, 0.55, 0]} s={[1.75, 0.6, 4.1]} c={color} r={0.45} />
    <Box p={[0, 1.08, -0.2]} s={[1.6, 0.5, 2.2]} c="#2E3440" r={0.15} />
    {[[-0.8, 1.35], [0.8, 1.35], [-0.8, -1.35], [0.8, -1.35]].map(([x, z], i) => (
      <mesh key={i} position={[x, 0.32, z]} rotation={[0, 0, Math.PI / 2]} castShadow>
        <cylinderGeometry args={[0.32, 0.32, 0.22, 10]} />
        <meshStandardMaterial color="#1A1A1A" roughness={0.9} />
      </mesh>
    ))}
    {[-0.6, 0.6].map((x) => (
      <mesh key={x} position={[x, 0.6, 2.06]}>
        <boxGeometry args={[0.32, 0.14, 0.02]} />
        <meshBasicMaterial color={new THREE.Color("#FFF2D0").multiplyScalar(0.6 + night * 2)} toneMapped={false} />
      </mesh>
    ))}
  </group>
);

const Pigeon: React.FC<{ i: number; t: number }> = ({ i, t }) => {
  const r = (k: string) => random(`pg${i}${k}`);
  const p0: V3 = [-6.5 + r("x") * 5, 0, 4.5 + r("z") * 3];
  if (t > FREEZE + 9) return null;
  const fly = t >= FREEZE + 0.05;
  const d = t - (FREEZE + 0.05);
  const v: V3 = [(r("vx") - 0.5) * 5, 3.2 + r("vy") * 1.5, -2 - r("vz") * 4];
  const pos: V3 = fly ? [p0[0] + v[0] * d, Math.max(0, v[1] * d - 0.12 * d * d * 2), p0[2] + v[2] * d] : p0;
  const flap = fly ? Math.sin(t * 75 + i) * 0.9 : 0;
  const peck = fly ? 0 : Math.max(0, Math.sin(t * 3 + i * 1.7)) * 0.5;
  const yaw = fly ? Math.atan2(v[0], v[2]) : r("y") * 6.28;
  return (
    <group position={pos} rotation={[0, yaw, 0]}>
      <mesh position={[0, 0.12, 0]} scale={[0.8, 0.7, 1.3]} castShadow>
        <icosahedronGeometry args={[0.09, 0]} />
        <meshStandardMaterial color="#8A8C94" roughness={0.8} flatShading />
      </mesh>
      <mesh position={[0, 0.2 - peck * 0.08, 0.1 + peck * 0.03]}>
        <icosahedronGeometry args={[0.045, 0]} />
        <meshStandardMaterial color="#5A6070" roughness={0.8} flatShading />
      </mesh>
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 0.07, 0.15, 0]} rotation={[0, 0, s * (0.2 + flap)]}>
          <boxGeometry args={[0.16, 0.012, 0.12]} />
          <meshStandardMaterial color="#7A7C84" roughness={0.8} flatShading />
        </mesh>
      ))}
    </group>
  );
};

const Fountain: React.FC<{ t: number }> = ({ t }) => (
  <group>
    <mesh position={[0, 0.25, 0]} castShadow receiveShadow>
      <cylinderGeometry args={[3.0, 3.1, 0.5, 28, 1, true]} />
      <meshStandardMaterial color="#D8D0C4" roughness={0.7} side={THREE.DoubleSide} />
    </mesh>
    <mesh position={[0, 0.5, 0]} rotation={[-Math.PI / 2, 0, 0]}>
      <ringGeometry args={[2.85, 3.15, 28]} />
      <meshStandardMaterial color="#E8E0D4" roughness={0.6} />
    </mesh>
    <mesh position={[0, 0.38, 0]} rotation={[-Math.PI / 2, 0, 0]}>
      <circleGeometry args={[2.9, 28]} />
      <meshStandardMaterial color="#5E8AA8" roughness={0.12} metalness={0.1} envMapIntensity={1.2} />
    </mesh>
    <mesh position={[0, 0.8, 0]} castShadow>
      <cylinderGeometry args={[0.25, 0.4, 1.0, 10]} />
      <meshStandardMaterial color="#D8D0C4" roughness={0.7} flatShading />
    </mesh>
    <Points n={360} seed="jet" size={0.05} color="#E8F2FA" opacity={0.75} at={(i, r) => {
      const life = 1.15;
      const age = (t + r("o") * life) % life;
      const a = r("a") * Math.PI * 2;
      const sp = 0.4 + r("s") * 0.5;
      const vy = 5.2 + r("v") * 0.6;
      return [Math.cos(a) * sp * age, 1.3 + vy * age - 4.9 * age * age, Math.sin(a) * sp * age];
    }} />
  </group>
);

const Awning: React.FC<{ p: V3; w: number }> = ({ p, w }) => {
  const tex = useMemo(() => tiled("awning", 64, [6, 1], (g, s) => {
    for (let i = 0; i < 2; i++) { g.fillStyle = i ? "#F4EEE4" : "#C8463A"; g.fillRect((i * s) / 2, 0, s / 2, s); }
  }), []);
  return (
    <group position={p}>
      <mesh position={[0, 2.5, 0]} rotation={[-0.25, 0, 0]} castShadow>
        <boxGeometry args={[w, 0.04, 2.2]} />
        <meshStandardMaterial map={tex} roughness={0.85} />
      </mesh>
      {[-w / 2 + 0.1, w / 2 - 0.1].map((x) => (
        <Box key={x} p={[x, 1.25, 1.0]} s={[0.06, 2.5, 0.06]} c="#2E2A28" />
      ))}
    </group>
  );
};

// ---------- the scene ----------
export const Plaza: React.FC<{ t: number; l: Light }> = ({ t, l }) => {
  const b = beatIndex(t);
  const pave = useMemo(() => slabs(), []);
  const road = useMemo(() => asphalt(), []);
  const rim = rimAt(t);
  const leaf = b >= 9 ? "#B88A3A" : "#5E7E44";
  const lampOn = l.night + (t > 59 && t < 60 ? -Math.sin(((t - 59) / 1) * Math.PI) * 0.8 : 0);
  const trafficOn = t < 18.2;
  const red = Math.floor(t / 6) % 2 === 0;

  // café cups / laptops
  const guests = GUESTS.map((g, i) => {
    const tb = TABLES[g.table];
    const pos: V3 = [tb[0] + Math.cos(g.ang) * 0.62, 0.47, tb[2] + Math.sin(g.ang) * 0.62];
    const yaw = faceTo(pos, tb);
    return { ...g, i, pos, yaw };
  });

  return (
    <group>
      {/* sky dome + sun */}
      <mesh>
        <sphereGeometry args={[200, 24, 16]} />
        <meshBasicMaterial map={skyTex(l.sky)} side={THREE.BackSide} fog={false} toneMapped={false} />
      </mesh>
      {l.sky !== "night" && (
        <mesh position={[l.keyPos[0] * 9, Math.max(6, l.keyPos[1] * 9), l.keyPos[2] * 9]}>
          <sphereGeometry args={[4, 16, 12]} />
          <meshBasicMaterial color={new THREE.Color(l.sky === "dusk" ? "#F2A080" : "#FFF0D0").multiplyScalar(2.2)} toneMapped={false} fog={false} />
        </mesh>
      )}

      {/* ground: paving, road, zebra, kerbs */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 1]} receiveShadow>
        <planeGeometry args={[60, 50]} />
        <meshStandardMaterial color="#C8C0B4" roughness={0.85} map={pave} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, 13]} receiveShadow>
        <planeGeometry args={[60, 3.6]} />
        <meshStandardMaterial color="#4A4A50" roughness={0.9} map={road} />
      </mesh>
      {Array.from({ length: 7 }, (_, i) => (
        <mesh key={i} rotation={[-Math.PI / 2, 0, 0]} position={[1.6 + i * 0.8, 0.015, 13]}>
          <planeGeometry args={[0.45, 3.4]} />
          <meshStandardMaterial color="#EDEDED" roughness={0.8} />
        </mesh>
      ))}
      <Box p={[0, 0.06, 11.15]} s={[60, 0.12, 0.2]} c="#B8B0A4" shadow={false} />
      <Box p={[0, 0.06, 14.85]} s={[60, 0.12, 0.2]} c="#B8B0A4" shadow={false} />

      {/* buildings around the plaza */}
      <Building p={[-10, 0, -16]} s={[14, 13, 6]} c="#C9A27A" night={l.night} />
      <Building p={[4, 0, -17]} s={[12, 16, 6]} c="#B9C6D6" night={l.night} />
      <Building p={[16, 0, -15]} s={[10, 11, 6]} c="#D8C8B2" night={l.night} />
      <Building p={[-19, 0, 2]} s={[6, 12, 22]} c="#A8835E" night={l.night} />
      <Building p={[20, 0, 1]} s={[6, 14, 22]} c="#C98A8A" night={l.night} />
      <Building p={[-6, 0, 21]} s={[18, 11, 6]} c="#B8A27E" night={l.night} />
      <Building p={[14, 0, 21]} s={[16, 13, 6]} c="#8A93A0" night={l.night} />
      {/* billboard on the right façade */}
      <mesh position={[16.9, 7.2, -1.5]} rotation={[0, -Math.PI / 2, 0]}>
        <planeGeometry args={[7, 2.6]} />
        <meshBasicMaterial map={signTex("bb", billboardText(t), 512, 190, "#141A2A", "#EDE6DA", "bold 64px sans-serif")} toneMapped={false} color={new THREE.Color("#FFFFFF").multiplyScalar(0.9 + l.night * 0.4)} />
      </mesh>

      {/* trees */}
      {Array.from({ length: 8 }, (_, i) => (
        <Tree key={i} p={[-12 + i * 3.4, 0, -11.5]} t={t} h={6.5} seed={`pt${i}`} leaf={leaf} />
      ))}
      {Array.from({ length: 3 }, (_, i) => (
        <Tree key={`r${i}`} p={[14.5, 0, -6 + i * 5]} t={t} h={6} seed={`pr${i}`} leaf={leaf} />
      ))}
      {b >= 9 && b <= 13 && (
        <Points n={120} seed="leaves" size={0.09} color="#C8963A" opacity={0.9} at={(i, r) => {
          const fall = 0.6 + r("v") * 0.5;
          const y = 6 - ((t * fall + r("o") * 6) % 6);
          return [-12 + r("x") * 26 + Math.sin(t * 1.3 + i) * 0.4, y, -11.5 + r("z") * 3 + Math.cos(t + i) * 0.4];
        }} />
      )}

      <Fountain t={t} />

      {/* plaza clock */}
      <group position={[11, 0, -8]}>
        <Box p={[0, 2, 0]} s={[0.16, 4, 0.16]} c="#2E2A28" />
        <group position={[0, 4.3, 0]} rotation={[0, faceTo([11, 0, -8], YOU_POS), 0]}>
          <Box p={[0, 0, 0]} s={[1.3, 0.8, 0.2]} c="#2E2A28" />
          <mesh position={[0, 0, 0.105]}>
            <planeGeometry args={[1.15, 0.65]} />
            <meshBasicMaterial map={signTex("clk", clockText(t), 256, 144, "#F4EEE4", "#2E2A28", "bold 96px sans-serif")} toneMapped={false} />
          </mesh>
        </group>
      </group>

      {/* traffic lights */}
      {([[-2.5, 11.0], [6.5, 15.0]] as [number, number][]).map(([x, z], i) => (
        <group key={i} position={[x, 0, z]}>
          <Box p={[0, 1.5, 0]} s={[0.12, 3, 0.12]} c="#2E2A28" />
          <Box p={[0, 3.2, 0]} s={[0.35, 0.9, 0.3]} c="#1E1E22" />
          {["#FF4A3A", "#3AFF7A"].map((c, k) => {
            const on = trafficOn && (k === 0 ? red : !red);
            return (
              <mesh key={k} position={[0, 3.45 - k * 0.45, i === 0 ? 0.16 : -0.16]}>
                <circleGeometry args={[0.1, 12]} />
                <meshBasicMaterial color={new THREE.Color(on ? c : "#2A2A2A").multiplyScalar(on ? 2 : 1)} toneMapped={false} side={THREE.DoubleSide} />
              </mesh>
            );
          })}
        </group>
      ))}

      {/* lamp posts + benches around the plaza */}
      {Array.from({ length: 8 }, (_, i) => {
        const a = (i / 8) * Math.PI * 2 + 0.2;
        const p: V3 = [Math.cos(a) * 11, 0, Math.sin(a) * 10.2];
        return (
          <group key={i} position={p}>
            <Box p={[0, 1.8, 0]} s={[0.1, 3.6, 0.1]} c="#2E2A28" />
            <mesh position={[0, 3.65, 0]}>
              <sphereGeometry args={[0.18, 10, 8]} />
              <meshBasicMaterial color={new THREE.Color("#FFE6B0").multiplyScalar(0.5 + Math.max(0, lampOn) * 2.2)} toneMapped={false} />
            </mesh>
            {lampOn > 0.1 && <pointLight position={[0, 3.4, 0]} color="#FFD8A0" intensity={4 * lampOn} distance={9} decay={1.6} />}
          </group>
        );
      })}
      {BENCHES.map((bb, i) => (
        <group key={i} position={bb.p} rotation={[0, bb.yaw, 0]}>
          <Box p={[0, 0.45, 0]} s={[1.8, 0.06, 0.5]} c="#8A6A4A" />
          <Box p={[0, 0.75, -0.24]} s={[1.8, 0.4, 0.05]} c="#8A6A4A" />
          <Box p={[-0.8, 0.22, 0]} s={[0.06, 0.44, 0.45]} c="#2E2A28" />
          <Box p={[0.8, 0.22, 0]} s={[0.06, 0.44, 0.45]} c="#2E2A28" />
        </group>
      ))}

      {/* café terrace */}
      <Awning p={[-10.2, 0, 7.4]} w={3.4} />
      <Awning p={[-10.2, 0, 11.4]} w={3.4} />
      {TABLES.map((tb, i) => (
        <group key={i} position={tb}>
          <mesh position={[0, 0.74, 0]} castShadow receiveShadow>
            <cylinderGeometry args={[0.38, 0.38, 0.03, 16]} />
            <meshStandardMaterial color="#EDE6DA" roughness={0.4} />
          </mesh>
          <Box p={[0, 0.37, 0]} s={[0.06, 0.72, 0.06]} c="#2E2A28" />
        </group>
      ))}
      {guests.map((g) => {
        const L = { ...guestLook(g.i), rim };
        const typing = g.laptop && !(g.i === 1 && t >= 22 && t < 30);
        const jit = (k: number) => (typing ? Math.max(0, Math.sin(t * 15 + k * 2 + g.i)) * 0.02 : 0);
        const sip = sipAt(g.i, t);
        let handR: V3 = g.laptop ? [-0.12, 0.29 + jit(0), 0.42] : mixV([-0.14, 0.29, 0.4], [-0.05, 0.66, 0.2], sip);
        let handL: V3 = g.laptop ? [0.12, 0.29 + jit(1), 0.42] : [0.16, 0.12 + (t < FREEZE ? Math.max(0, Math.sin(t * 2.5 + g.i)) * 0.25 : 0), 0.34];
        // beat 6: the stranger at the next seat keeps typing on HER laptop
        if (g.i === 2 && t >= 22.6 && t < 30) {
          const her = guests[1];
          const lap = toWorld([0, 0.3, 0.42], her.pos, her.yaw);
          handR = toLocal([lap[0] + 0.08, lap[1] + Math.max(0, Math.sin(t * 15)) * 0.02, lap[2]], g.pos, g.yaw);
          handL = toLocal([lap[0] - 0.08, lap[1] + Math.max(0, Math.sin(t * 15 + 2)) * 0.02, lap[2]], g.pos, g.yaw);
        }
        const cup = toWorld(handR, g.pos, g.yaw);
        return (
          <React.Fragment key={g.i}>
            <SeatedPerson position={g.pos} yaw={g.yaw} handTarget={handR} handL={handL} look={L} lean={g.i === 2 && t >= 22.6 && t < 30 ? -0.18 : 0} />
            <Box p={[g.pos[0], 0.44, g.pos[2]]} s={[0.42, 0.04, 0.42]} c="#2E2A28" />
            {!g.laptop && (
              <mesh position={[cup[0], cup[1] + 0.04, cup[2]]} castShadow>
                <cylinderGeometry args={[0.04, 0.032, 0.08, 10]} />
                <meshStandardMaterial color="#F4EEE4" roughness={0.3} />
              </mesh>
            )}
            {g.laptop && <Laptop pos={toWorld([0, 0.3, 0.42], g.pos, g.yaw)} yaw={g.yaw + Math.PI} t={t} lines={g.i === 1 ? laptopLines(t) : 4} />}
          </React.Fragment>
        );
      })}

      {/* road traffic */}
      {Array.from({ length: N_CARS }, (_, i) => {
        const c = carAt(i, t);
        return <Car key={i} pos={c.pos} yaw={c.yaw} color={c.color} night={l.night} />;
      })}

      {/* pigeons */}
      {Array.from({ length: 12 }, (_, i) => (
        <Pigeon key={i} i={i} t={t} />
      ))}

      {/* crowd */}
      {Array.from({ length: N_WALKERS }, (_, i) => {
        const w = walkerAt(i, t);
        return <StandingPerson key={i} position={w.pos} yaw={w.yaw} look={{ ...w.look, rim }} walk={w.walk} stride={w.stride} scale={w.scale} />;
      })}
      {Array.from({ length: N_CROSSERS }, (_, i) => {
        const w = crosserAt(i, t);
        return <StandingPerson key={`c${i}`} position={w.pos} yaw={w.yaw} look={{ ...w.look, rim }} walk={w.walk} stride={w.stride} scale={w.scale} />;
      })}
      <Groups t={t} rim={rim} />
      <Child t={t} rim={rim} />
      {b >= 11 && <BenchSitters rim={rim} />}
      <Stranger t={t} rim={rim} />
      <You t={t} />

      {/* dust in the sun */}
      <Points n={260} seed="pdust" size={0.03} color="#FFE8C0" opacity={l.night > 0.5 ? 0.15 : 0.5} additive at={(i, r) => [
        -14 + r("x") * 28 + Math.sin(t * 0.3 + i) * 0.3, 0.3 + ((r("y") * 4 + t * 0.05) % 4), -8 + r("z") * 22,
      ]} />
    </group>
  );
};

const BENCHES = [0.9, 1.7, 2.6, 3.6, 4.5, 5.4].map((a) => {
  const p: V3 = [Math.cos(a) * 10.4, 0, Math.sin(a) * 9.8];
  return { p, yaw: Math.atan2(-p[0], -p[2]) };
});

const laptopLines = (t: number) => (t < 22 ? 4 : t < 22.6 ? 5 : Math.min(9, 5 + Math.floor((t - 22.6) * 1.6)));

const Laptop: React.FC<{ pos: V3; yaw: number; t: number; lines: number }> = ({ pos, yaw, lines }) => {
  const tex = textTex(`lap-${lines}`, 128, 96, (g) => {
    g.fillStyle = "#E8F0F8";
    g.fillRect(0, 0, 128, 96);
    g.fillStyle = "#5A6478";
    for (let k = 0; k < lines; k++) g.fillRect(10, 10 + k * 9, 60 + ((k * 37) % 48), 4);
  });
  return (
    <group position={[pos[0], 0.755, pos[2]]} rotation={[0, yaw, 0]}>
      <Box p={[0, 0, 0]} s={[0.32, 0.015, 0.22]} c="#9AA0A8" r={0.3} />
      <group position={[0, 0.0, -0.11]} rotation={[-0.25, 0, 0]}>
        <Box p={[0, 0.11, 0]} s={[0.32, 0.22, 0.01]} c="#9AA0A8" r={0.3} />
        <mesh position={[0, 0.11, 0.006]} rotation={[0, 0, 0]}>
          <planeGeometry args={[0.29, 0.19]} />
          <meshBasicMaterial map={tex} toneMapped={false} />
        </mesh>
      </group>
    </group>
  );
};

// two groups of friends + a street musician (beat 4: they nod together)
const Groups: React.FC<{ t: number; rim: number }> = ({ t, rim }) => {
  const centers: V3[] = [[6.2, 0, -8.8], [9.0, 0, -6.2]];
  const nod = Math.sin(Math.PI * clamp((t - 15.2) / 0.5)) * 0.35;
  const out: React.ReactNode[] = [];
  centers.forEach((c, gi) => {
    for (let k = 0; k < 3; k++) {
      const a = (k / 3) * Math.PI * 2 + gi;
      const p: V3 = [c[0] + Math.cos(a) * 0.75, 0, c[2] + Math.sin(a) * 0.75];
      const inward = faceTo(p, c);
      const toYou = faceTo(p, YOU_POS);
      let d = toYou - inward;
      d = Math.atan2(Math.sin(d), Math.cos(d));
      const yaw = inward + d * ramp(t, TURN, TURN + 0.8);
      const talk = t < FREEZE ? Math.max(0, Math.sin(t * 3 + k * 2 + gi)) * 0.3 : 0;
      out.push(<StandingPerson key={`${gi}${k}`} position={p} yaw={yaw} look={{ ...guestLook(20 + gi * 3 + k), rim }} handR={[-0.22, 0.95 + talk, 0.2 + talk * 0.5]} headPitch={nod} />);
    }
  });
  // musician lowers his guitar at 14.4
  const m: V3 = [10.2, 0, -2.6];
  const lower = ramp(t, 14.4, 15.0);
  const myaw = lerp(faceTo(m, [0, 0, 0]), faceTo(m, YOU_POS), ramp(t, TURN, TURN + 0.8));
  out.push(
    <group key="mus">
      <StandingPerson position={m} yaw={myaw} look={{ ...guestLook(40), rim }} handR={[-0.1, lerp(1.1, 0.9, lower), 0.32]} handL={[0.25, lerp(1.2, 0.95, lower), 0.25]} />
      <group position={toWorld([0, lerp(1.05, 0.65, lower), 0.22], m, myaw)} rotation={[0, myaw, lerp(0.9, 1.5, lower)]}>
        <Box p={[0, 0, 0]} s={[0.36, 0.5, 0.1]} c="#A8583A" r={0.4} />
        <Box p={[0, 0.5, 0]} s={[0.06, 0.55, 0.04]} c="#5A3A22" />
      </group>
    </group>,
  );
  return <>{out}</>;
};

// beat 10: a child trips and every hand nearby reaches out
const Child: React.FC<{ t: number; rim: number }> = ({ t, rim }) => {
  const helpers: V3[] = [[7.6, 0, 5.4], [9.5, 0, 5.6], [8.9, 0, 7.4]];
  const target: V3 = [8.45, 0, 6.3];
  const reach = ramp(t, 38.5, 38.9) * (1 - ramp(t, 40.4, 40.9));
  const out: React.ReactNode[] = helpers.map((h, i) => {
    const toChild = faceTo(h, target);
    const toYou = faceTo(h, YOU_POS);
    let d = toYou - toChild;
    d = Math.atan2(Math.sin(d), Math.cos(d));
    const yaw = t >= TURN ? toChild + d * ramp(t, TURN, TURN + 0.8) : toChild;
    const hand: V3 = mixV([-0.24, 0.9, 0.05], [-0.1, 0.7, 0.55], reach);
    const handL: V3 = mixV([0.24, 0.9, 0.05], [0.1, 0.7, 0.55], reach);
    return <StandingPerson key={i} position={h} yaw={yaw} look={{ ...guestLook(50 + i), rim }} handR={hand} handL={handL} headPitch={reach * 0.4} />;
  });
  if (t >= 38) {
    const run = clamp((t - 38) / 0.4);
    const p0: V3 = [6.8, 0, 7.6];
    const p = mixV(p0, target, run);
    const fall = ramp(t, 38.4, 38.95) * (1 - ramp(t, 39.3, 40.1));
    const yaw = faceTo(p0, target);
    out.push(
      <group key="child" position={p} rotation={[0, yaw, 0]}>
        <group rotation={[fall * 1.3, 0, 0]}>
          <StandingPerson position={[0, 0, 0]} yaw={0} look={{ hair: "#3A2418", top: "#E8C04A", pants: "#2E3A4A", skin: "#D8AA88", rim }} walk={t < 38.4 ? t * 22 : undefined} scale={0.55} />
        </group>
      </group>,
    );
  }
  return <>{out}</>;
};

const BenchSitters: React.FC<{ rim: number }> = ({ rim }) => (
  <>
    {BENCHES.flatMap((bb, i) =>
      [-0.35, 0.35].map((x, k) => {
        const p = toWorld([x, 0.47, 0.05], bb.p, bb.yaw);
        return <SeatedPerson key={`${i}${k}`} position={p} yaw={bb.yaw} handTarget={[-0.12, 0.1, 0.34]} look={{ ...guestLook(60 + i * 2 + k), rim }} lean={k ? 0.08 : -0.08} />;
      }),
    )}
  </>
);

// beat 14: a stranger walks up and offers an open hand
const Stranger: React.FC<{ t: number; rim: number }> = ({ t, rim }) => {
  if (t < 54) return null;
  const a: V3 = [-4.6, 0, 5.4];
  const bpos: V3 = [-7.15, 0, 8.05];
  const k = clamp((t - 54) / 1.6);
  const p = mixV(a, bpos, k);
  const yaw = t < 55.6 ? faceTo(a, bpos) : faceTo(bpos, YOU_POS);
  const offer = ramp(t, 55.6, 56.2);
  return (
    <StandingPerson position={p} yaw={yaw} look={{ hair: "#5A3A28", top: "#A8583A", pants: "#3A3330", skin: "#B8846A", rim }}
      walk={k < 1 ? (t - 54) * 2 * Math.PI * 1.6 : undefined} handR={mixV([-0.24, 0.9, 0.0], [-0.1, 1.1, 0.52], offer)} />
  );
};

// YOU: seated at the café table, phone in hand; stands and steps back at the end
const You: React.FC<{ t: number }> = ({ t }) => {
  const table = TABLES[4];
  const phoneW: V3 = [table[0] - 0.12, 0.765, table[2] + 0.08];
  const buzz = t >= 25.4 && t < 26.3 ? Math.sin(t * 160) * 0.004 : 0;
  const ended = t >= 26.3;
  const screen = textTex(`phone-${ended}`, 96, 192, (g) => {
    g.fillStyle = ended ? "#1A1C22" : "#2A3448";
    g.fillRect(0, 0, 96, 192);
    g.fillStyle = "#EDE6DA";
    g.textAlign = "center";
    g.font = "bold 13px sans-serif";
    g.fillText(ended ? "CALL ENDED" : "MOM", 48, 70);
    if (!ended) { g.font = "11px sans-serif"; g.fillText("CALLING", 48, 92); g.fillStyle = "#7FBF7A"; g.beginPath(); g.arc(48, 150, 12, 0, 6.28); g.fill(); }
  });
  const phone = (
    <group position={[phoneW[0] + buzz, phoneW[1], phoneW[2]]} rotation={[0, YOU_YAW + Math.PI, 0]}>
      <Box p={[0, 0, 0]} s={[0.075, 0.009, 0.15]} c="#1A1A1A" r={0.2} />
      <mesh position={[0, 0.0055, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[0.068, 0.14]} />
        <meshBasicMaterial map={screen} toneMapped={false} color={new THREE.Color("#FFFFFF").multiplyScalar(t > 28 ? 0.25 : 1)} />
      </mesh>
    </group>
  );
  if (t < STAND) {
    const hand = toLocal([phoneW[0] + 0.02, phoneW[1] + 0.02, phoneW[2] + 0.06], YOU_POS, YOU_YAW);
    return (
      <>
        <SeatedPerson position={YOU_POS} yaw={YOU_YAW} handTarget={hand} handL={toLocal([table[0] + 0.15, 0.77, table[2] + 0.12], YOU_POS, YOU_YAW)} look={YOU_LOOK} />
        <Box p={[YOU_POS[0], 0.44, YOU_POS[2]]} s={[0.42, 0.04, 0.42]} c="#2E2A28" />
        {phone}
      </>
    );
  }
  const back = ramp(t, STAND, STAND + 0.6);
  const pos: V3 = [YOU_POS[0] - DIR[0] * (0.35 + back * 0.45), 0, YOU_POS[2] - DIR[2] * (0.35 + back * 0.45)];
  return (
    <>
      <StandingPerson position={pos} yaw={YOU_YAW} look={YOU_LOOK} walk={back > 0 && back < 1 ? back * Math.PI : undefined} />
      <Box p={[YOU_POS[0] - DIR[0] * 0.2, 0.44, YOU_POS[2] - DIR[2] * 0.2]} s={[0.42, 0.04, 0.42]} c="#2E2A28" rot={[0, 0.3, 0]} />
      {phone}
    </>
  );
};

export const _w = weave;
