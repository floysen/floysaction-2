// Realistic trees (ez-tree, MIT), water (three.js Water shader) and flying birds — all pure functions of time.
import * as THREE from "three";
import React, { useLayoutEffect, useMemo } from "react";
import { Tree as EzTree } from "@dgreenheck/ez-tree";
import { Water as WaterImpl } from "three/examples/jsm/objects/Water.js";
import { useGLTF, useTexture } from "./assets";

type V3 = [number, number, number];

export type TreePreset =
  | "Ash Small" | "Ash Medium" | "Ash Large" | "Aspen Small" | "Aspen Medium" | "Aspen Large"
  | "Oak Small" | "Oak Medium" | "Oak Large" | "Pine Small" | "Pine Medium" | "Pine Large"
  | "Bush 1" | "Bush 2" | "Bush 3";

// one shared wind clock for every tree material (set each frame; also used on first shader compile)
const WIND = { value: 0 };
const treeCache = new Map<string, EzTree>();
const makeTree = (preset: TreePreset, seed: number, leafTint?: number) => {
  const key = `${preset}:${seed}:${leafTint ?? ""}`;
  let t = treeCache.get(key);
  if (!t) {
    t = new EzTree();
    t.loadPreset(preset);
    t.options.seed = seed;
    if (leafTint !== undefined) (t.options as unknown as { leaves: { tint: number } }).leaves.tint = leafTint;
    t.generate();
    t.traverse((o) => {
      const m = o as THREE.Mesh;
      if (!m.isMesh) return;
      m.castShadow = true;
      m.receiveShadow = true;
      const mat = m.material as THREE.Material;
      const orig = mat.onBeforeCompile;
      mat.onBeforeCompile = (sh, r) => {
        orig.call(mat, sh, r);
        if (sh.uniforms.uTime) sh.uniforms.uTime = WIND;
      };
    });
    treeCache.set(key, t);
  }
  return t;
};

// instances share geometry + materials with the generated prototype
export const Tree: React.FC<{ preset: TreePreset; seed?: number; position: V3; scale?: number; rotation?: number; t: number; wind?: number; leafTint?: number }> = ({
  preset, seed = 1, position, scale = 1, rotation = 0, t, wind = 1, leafTint,
}) => {
  const proto = useMemo(() => makeTree(preset, seed, leafTint), [preset, seed, leafTint]);
  const inst = useMemo(() => proto.clone(true), [proto]);
  useLayoutEffect(() => {
    WIND.value = t * wind;
  });
  return <primitive object={inst} position={position} scale={scale} rotation={[0, rotation, 0]} />;
};

// realistic water plane with animated normals + sky reflection
export const Water: React.FC<{ position: V3; size: [number, number]; t: number; sun?: V3; color?: string; distortion?: number; circle?: number }> = ({
  position, size, t, sun = [0.5, 0.6, 0.3], color = "#1E4A5A", distortion = 1.2, circle,
}) => {
  const normals = useTexture("assets/tex/waternormals.jpg");
  const water = useMemo(() => {
    if (!normals) return null;
    const geo = circle ? new THREE.CircleGeometry(circle, 48) : new THREE.PlaneGeometry(size[0], size[1]);
    const w = new WaterImpl(geo, {
      textureWidth: 512, textureHeight: 512, waterNormals: normals,
      sunDirection: new THREE.Vector3(...sun).normalize(), sunColor: 0xffffff, waterColor: new THREE.Color(color).getHex(),
      distortionScale: distortion, fog: true,
    });
    w.rotation.x = -Math.PI / 2;
    return w;
  }, [normals, size, sun, color, distortion, circle]);
  useLayoutEffect(() => {
    if (water) (water.material as THREE.ShaderMaterial).uniforms.time.value = t * 0.6;
  });
  if (!water) return null;
  return <primitive object={water} position={position} />;
};

// flock of animated birds (morph-target flap) flying along analytic paths
export const Birds: React.FC<{ kind?: "Stork" | "Parrot" | "Flamingo"; count: number; t: number; path: (i: number, t: number) => { pos: V3; yaw: number; pitch?: number }; scale?: number }> = ({
  kind = "Stork", count, t, path, scale = 0.02,
}) => {
  const gltf = useGLTF(`assets/birds/${kind}.glb`);
  const flock = useMemo(() => {
    if (!gltf) return [];
    return Array.from({ length: count }, () => {
      const mesh = (gltf.scene.children[0] as THREE.Mesh).clone();
      mesh.castShadow = true;
      const mixer = new THREE.AnimationMixer(mesh);
      const a = mixer.clipAction(gltf.animations[0]);
      a.play();
      return { mesh, mixer, a, dur: gltf.animations[0].duration };
    });
  }, [gltf, count]);
  useLayoutEffect(() => {
    flock.forEach((b, i) => {
      b.a.time = (t * 1.0 + i * 0.37) % b.dur;
      b.mixer.update(0);
      const p = path(i, t);
      b.mesh.position.set(...p.pos);
      b.mesh.rotation.set(p.pitch ?? 0, p.yaw, 0);
      b.mesh.scale.setScalar(scale);
    });
  });
  return (
    <>
      {flock.map((b, i) => (
        <primitive key={i} object={b.mesh} />
      ))}
    </>
  );
};
