import React from "react";
import { Composition } from "remotion";
import { KitTest } from "./KitTest";

export const RemotionRoot: React.FC = () => (
  <>
    <Composition id="KitTest" component={KitTest} durationInFrames={240} fps={30} width={1080} height={1920} />
  </>
);
