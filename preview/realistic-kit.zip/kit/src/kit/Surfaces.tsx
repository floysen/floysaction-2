// Procedural PBR surface sets (colour + normal + roughness), seeded and cached. No downloads needed.
import * as THREE from "three";
import React, { useMemo } from "react";
import { random } from "remotion";

type V3 = [number, number, number];
export type SurfaceKind = "paving" | "asphalt" | "brick" | "plaster" | "concrete" | "wood" | "grass";

type Set = { map: THREE.Texture; normalMap: THREE.Texture; roughnessMap: THREE.Texture };
const cache = new Map<string, Set>();

const S = 512;
const canvas = () => {
  const c = document.createElement("canvas");
  c.width = c.height = S;
  return c;
};

// value noise (seeded) for natural variation
const noise = (seed: string, scale: number) => {
  const g = 64;
  const grid = new Float32Array(g * g).map((_, i) => random(`${seed}${i}`));
  return (x: number, y: number) => {
    const fx = (x / S) * scale, fy = (y / S) * scale;
    const x0 = Math.floor(fx), y0 = Math.floor(fy);
    const tx = fx - x0, ty = fy - y0;
    const at = (a: number, b: number) => grid[((((b % g) + g) % g) * g + (((a % g) + g) % g))];
    const sx = tx * tx * (3 - 2 * tx), sy = ty * ty * (3 - 2 * ty);
    return (at(x0, y0) * (1 - sx) + at(x0 + 1, y0) * sx) * (1 - sy) + (at(x0, y0 + 1) * (1 - sx) + at(x0 + 1, y0 + 1) * sx) * sy;
  };
};

// returns height (0..1), colour (rgb 0..255) and roughness (0..1) per pixel
type Fn = (x: number, y: number) => { h: number; c: [number, number, number]; r: number };

const RECIPES: Record<SurfaceKind, (seed: string) => Fn> = {
  paving: (seed) => {
    const n1 = noise(seed + "a", 24), n2 = noise(seed + "b", 6);
    const rows = 4, cols = 2;
    return (x, y) => {
      const row = Math.floor((y / S) * rows);
      const off = row % 2 ? 0.5 : 0;
      const u = ((x / S) * cols + off) % 1, v = ((y / S) * rows) % 1;
      const edge = Math.min(u, 1 - u, v * 2, (1 - v) * 2) * 40;
      const joint = Math.min(1, edge / 1.6);
      const tile = random(`${seed}t${row}${Math.floor((x / S) * cols + off)}`);
      const base = 168 + tile * 22 + n1(x, y) * 26 - 10 + n2(x, y) * 12;
      const k = joint;
      return { h: k * (0.85 + n1(x, y) * 0.15), c: [base * k + 90 * (1 - k), base * k * 0.97 + 86 * (1 - k), base * k * 0.92 + 80 * (1 - k)], r: 0.78 + (1 - k) * 0.15 };
    };
  },
  asphalt: (seed) => {
    const n1 = noise(seed + "a", 90), n2 = noise(seed + "b", 8);
    return (x, y) => {
      const g = random(`${seed}${x * 7 + y * 13}`) * 0.5 + n1(x, y) * 0.5;
      const v = 52 + g * 30 + n2(x, y) * 10;
      return { h: g, c: [v, v, v * 1.03], r: 0.86 - g * 0.1 };
    };
  },
  brick: (seed) => {
    const n1 = noise(seed + "a", 40), n2 = noise(seed + "b", 5);
    const rows = 16, cols = 6;
    return (x, y) => {
      const row = Math.floor((y / S) * rows);
      const off = row % 2 ? 0.5 : 0;
      const u = ((x / S) * cols + off) % 1, v = ((y / S) * rows) % 1;
      const edge = Math.min(u * 4, (1 - u) * 4, v, 1 - v) * 12;
      const k = Math.min(1, edge);
      const b = random(`${seed}b${row}${Math.floor((x / S) * cols + off)}`);
      const r0 = 140 + b * 40 + n1(x, y) * 20, g0 = 70 + b * 18 + n1(x, y) * 10, b0 = 52 + b * 12;
      return { h: k * (0.8 + n1(x, y) * 0.2), c: [r0 * k + 170 * (1 - k), g0 * k + 162 * (1 - k), b0 * k + 150 * (1 - k)].map((c) => c * (0.9 + n2(x, y) * 0.2)) as [number, number, number], r: 0.82 };
    };
  },
  plaster: (seed) => {
    const n1 = noise(seed + "a", 60), n2 = noise(seed + "b", 4);
    return (x, y) => {
      const v = n1(x, y) * 0.6 + n2(x, y) * 0.4;
      const c = 214 + v * 24;
      return { h: v * 0.5, c: [c, c * 0.97, c * 0.92], r: 0.9 };
    };
  },
  concrete: (seed) => {
    const n1 = noise(seed + "a", 50), n2 = noise(seed + "b", 6);
    return (x, y) => {
      const pit = random(`${seed}p${x * 3 + y * 17}`) > 0.995 ? -0.6 : 0;
      const v = n1(x, y) * 0.5 + n2(x, y) * 0.5 + pit;
      const c = 150 + v * 40;
      return { h: 0.5 + v * 0.4, c: [c, c, c * 0.98], r: 0.85 };
    };
  },
  wood: (seed) => {
    const n1 = noise(seed + "a", 6), n2 = noise(seed + "b", 50);
    return (x, y) => {
      const plank = Math.floor((y / S) * 6);
      const v = ((y / S) * 6) % 1;
      const k = Math.min(1, Math.min(v, 1 - v) * 60);
      const grain = Math.sin((x / S) * 40 + n1(x, y + plank * 50) * 18) * 0.5 + 0.5;
      const t = random(`${seed}w${plank}`);
      return { h: k * (0.7 + grain * 0.3), c: [(150 + t * 40 + grain * 25) * k + 60 * (1 - k), (100 + t * 25 + grain * 15) * k + 40 * (1 - k), (62 + t * 15 + grain * 8) * k + 28 * (1 - k)], r: 0.55 + n2(x, y) * 0.2 };
    };
  },
  grass: (seed) => {
    const n1 = noise(seed + "a", 120), n2 = noise(seed + "b", 10);
    return (x, y) => {
      const blade = random(`${seed}g${x * 5 + y * 11}`);
      const v = blade * 0.6 + n1(x, y) * 0.4;
      return { h: v, c: [52 + v * 40 + n2(x, y) * 20, 92 + v * 60 + n2(x, y) * 20, 38 + v * 20], r: 0.92 };
    };
  },
};

export const surface = (kind: SurfaceKind, repeat: [number, number], seed = "s") => {
  const key = `${kind}:${seed}`;
  let set = cache.get(key);
  if (!set) {
    const fn = RECIPES[kind](seed);
    const H = new Float32Array(S * S);
    const cc = canvas(), rc = canvas(), nc = canvas();
    const cd = cc.getContext("2d")!.createImageData(S, S);
    const rd = rc.getContext("2d")!.createImageData(S, S);
    const nd = nc.getContext("2d")!.createImageData(S, S);
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const p = fn(x, y);
        const i = y * S + x;
        H[i] = p.h;
        cd.data.set([Math.min(255, p.c[0]), Math.min(255, p.c[1]), Math.min(255, p.c[2]), 255], i * 4);
        const r = Math.min(255, p.r * 255);
        rd.data.set([r, r, r, 255], i * 4);
      }
    const strength = 3.0;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S; x++) {
        const h = (a: number, b: number) => H[((b + S) % S) * S + ((a + S) % S)];
        const dx = (h(x + 1, y) - h(x - 1, y)) * strength;
        const dy = (h(x, y + 1) - h(x, y - 1)) * strength;
        const len = Math.hypot(dx, dy, 1);
        const i = (y * S + x) * 4;
        nd.data.set([(-dx / len * 0.5 + 0.5) * 255, (dy / len * 0.5 + 0.5) * 255, (1 / len * 0.5 + 0.5) * 255, 255], i);
      }
    cc.getContext("2d")!.putImageData(cd, 0, 0);
    rc.getContext("2d")!.putImageData(rd, 0, 0);
    nc.getContext("2d")!.putImageData(nd, 0, 0);
    const tex = (c: HTMLCanvasElement, srgb: boolean) => {
      const t = new THREE.CanvasTexture(c);
      t.wrapS = t.wrapT = THREE.RepeatWrapping;
      t.anisotropy = 8;
      if (srgb) t.colorSpace = THREE.SRGBColorSpace;
      return t;
    };
    set = { map: tex(cc, true), normalMap: tex(nc, false), roughnessMap: tex(rc, false) };
    cache.set(key, set);
  }
  // per-use repeat: clone the texture wrappers (images are shared)
  const out = {
    map: set.map.clone(), normalMap: set.normalMap.clone(), roughnessMap: set.roughnessMap.clone(),
  };
  for (const t of Object.values(out)) {
    t.repeat.set(...repeat);
    t.needsUpdate = true;
  }
  return out;
};

export const Ground: React.FC<{ kind: SurfaceKind; size: [number, number]; repeat: [number, number]; position?: V3; tint?: string; normalScale?: number }> = ({
  kind, size, repeat, position = [0, 0, 0], tint = "#FFFFFF", normalScale = 1,
}) => {
  const tex = useMemo(() => surface(kind, repeat), [kind, repeat]);
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={position} receiveShadow>
      <planeGeometry args={size} />
      <meshStandardMaterial color={tint} {...tex} normalScale={new THREE.Vector2(normalScale, normalScale)} roughness={1} envMapIntensity={0.6} />
    </mesh>
  );
};

// a city building: PBR wall + recessed reflective windows with frames and sills
export const Building: React.FC<{ position: V3; size: V3; wall?: SurfaceKind; tint?: string; floors?: number; cols?: number; night?: number; rotation?: number; seed?: string }> = ({
  position, size, wall = "plaster", tint = "#FFFFFF", floors, cols, night = 0, rotation = 0, seed = "b",
}) => {
  const [w, h, d] = size;
  const nf = floors ?? Math.max(2, Math.floor(h / 3.2));
  const nc = cols ?? Math.max(2, Math.floor(w / 2.6));
  const tex = useMemo(() => surface(wall, [w / 4, h / 4]), [wall, w, h]);
  const glass = useMemo(() => new THREE.MeshPhysicalMaterial({ color: "#3A4450", metalness: 0.9, roughness: 0.06, envMapIntensity: 1.4 }), []);
  const lit = useMemo(() => new THREE.MeshStandardMaterial({ color: "#2A2A30", emissive: new THREE.Color("#FFE2B0"), emissiveIntensity: 1.6, roughness: 0.3 }), []);
  const frame = useMemo(() => new THREE.MeshStandardMaterial({ color: "#E8E2D8", roughness: 0.5 }), []);
  const winW = (w / nc) * 0.5, winH = (h / nf) * 0.55;
  const panes: React.ReactNode[] = [];
  for (let f = 0; f < nf; f++)
    for (let c = 0; c < nc; c++) {
      const x = -w / 2 + (w / nc) * (c + 0.5);
      const y = (h / nf) * (f + 0.55);
      const on = night > 0 && random(`${seed}${f}${c}`) < 0.75;
      panes.push(
        <group key={`${f}${c}`} position={[x, y, d / 2]}>
          <mesh position={[0, 0, 0.012]} material={on ? lit : glass}>
            <planeGeometry args={[winW, winH]} />
          </mesh>
          <mesh position={[0, -winH / 2 - 0.05, 0.05]} material={frame} castShadow>
            <boxGeometry args={[winW + 0.2, 0.08, 0.2]} />
          </mesh>
          <mesh position={[0, winH / 2 + 0.04, 0.02]} material={frame}>
            <boxGeometry args={[winW + 0.12, 0.08, 0.1]} />
          </mesh>
        </group>,
      );
    }
  return (
    <group position={position} rotation={[0, rotation, 0]}>
      <mesh position={[0, h / 2, 0]} castShadow receiveShadow>
        <boxGeometry args={size} />
        <meshStandardMaterial color={tint} {...tex} roughness={1} />
      </mesh>
      <mesh position={[0, h + 0.15, 0]} castShadow>
        <boxGeometry args={[w + 0.3, 0.3, d + 0.3]} />
        <meshStandardMaterial color="#9A948C" roughness={0.8} />
      </mesh>
      {panes}
    </group>
  );
};
