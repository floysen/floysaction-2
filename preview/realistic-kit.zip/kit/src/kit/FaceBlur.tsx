// Pixel-mosaic over every registered face, computed in screen space each frame.
// Mount <FaceTracker/> after the characters (so bones are posed) and <FaceBlurPass/> inside the EffectComposer.
import * as THREE from "three";
import React, { useLayoutEffect, useMemo } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { Effect } from "postprocessing";
import { useCurrentFrame } from "remotion";
import { FACES } from "./faces";

const MAX = 64;

const frag = /* glsl */ `
uniform vec4 faces[${MAX}];   // xy = centre (uv), zw = radii (uv)
uniform int count;
uniform vec2 res;
void mainImage(const in vec4 inputColor, const in vec2 uv, out vec4 outputColor) {
  outputColor = inputColor;
  for (int i = 0; i < ${MAX}; i++) {
    if (i >= count) break;
    vec4 f = faces[i];
    vec2 d = (uv - f.xy) / f.zw;
    if (dot(d, d) < 1.0) {
      // ~5 blocks across the face height: no feature can be read
      float block = max(6.0, f.w * res.y * 2.0 / 5.0);
      vec2 b = vec2(block) / res;
      vec2 q = (floor((uv - f.xy) / b) + 0.5) * b + f.xy;
      outputColor = texture2D(inputBuffer, q);
      break;
    }
  }
}`;

export class FaceBlurEffect extends Effect {
  constructor() {
    super("FaceBlur", frag, {
      uniforms: new Map<string, THREE.Uniform>([
        ["faces", new THREE.Uniform(Array.from({ length: MAX }, () => new THREE.Vector4()))],
        ["count", new THREE.Uniform(0)],
        ["res", new THREE.Uniform(new THREE.Vector2(1080, 1920))],
      ]),
    });
  }
}

export const FACE_BLUR = new FaceBlurEffect();

export const FaceBlurPass: React.FC = () => <primitive object={FACE_BLUR} />;

// projects each head to screen space and writes the uniforms (pure function of the posed scene)
export const FaceTracker: React.FC<{ padding?: number }> = ({ padding = 1.35 }) => {
  const frame = useCurrentFrame();
  const { camera, size } = useThree();
  const tmp = useMemo(() => ({ a: new THREE.Vector3(), b: new THREE.Vector3(), c: new THREE.Vector3(), r: new THREE.Vector3() }), []);
  // runs inside every r3f draw (before the composer at priority 1), so heads are always current
  const compute = () => {
    camera.updateMatrixWorld();
    const list = FACE_BLUR.uniforms.get("faces")!.value as THREE.Vector4[];
    let n = 0;
    for (const f of FACES.values()) {
      if (n >= MAX) break;
      f.head.updateWorldMatrix(true, false);
      f.head.getWorldPosition(tmp.a);
      if (f.top) {
        f.top.updateWorldMatrix(true, false);
        f.top.getWorldPosition(tmp.b);
        tmp.c.copy(tmp.a).lerp(tmp.b, 0.45);
      } else tmp.c.copy(tmp.a).add(new THREE.Vector3(0, 0.1, 0));
      // camera-facing radius: offset along camera right
      const dist = tmp.c.distanceTo(camera.position);
      const p = tmp.c.clone().project(camera);
      if (p.z < -1 || p.z > 1) continue; // behind the camera / clipped
      tmp.r.setFromMatrixColumn(camera.matrixWorld, 0).multiplyScalar(f.radius * padding).add(tmp.c);
      const q = tmp.r.project(camera);
      const rx = Math.abs(q.x - p.x) / 2; // ndc → uv
      const aspect = size.width / size.height;
      if (rx < 0.0008 || dist < 0.05) continue;
      list[n].set((p.x + 1) / 2, (p.y + 1) / 2, rx, rx * aspect * 1.15);
      n++;
    }
    FACE_BLUR.uniforms.get("count")!.value = n;
    (FACE_BLUR.uniforms.get("res")!.value as THREE.Vector2).set(size.width, size.height);
  };
  useFrame(compute);
  useLayoutEffect(compute, [frame, camera, size, tmp]);
  return null;
};
