"""Full 70 s synthesised soundtrack (no recording sources reachable from the build machine).

Follows the Sound Cue Sheet: ambience per act, one SFX per visible action, 2 accents,
the beat-14 scripted silence, sparse piano (music = yes) and an end stinger.
"""
import sys
import numpy as np
import soundfile as sf
from scipy.signal import butter, sosfilt

SR = 44100
DUR = 70.0
N = int(SR * DUR)
rng = np.random.default_rng(7)


def db(x):
    return 10 ** (x / 20)


def filt(x, kind, f):
    return sosfilt(butter(2, f, kind, fs=SR, output="sos"), x)


def edge(x, ms=15):
    n = max(1, int(SR * ms / 1000))
    x = x.copy()
    n = min(n, len(x) // 2)
    x[:n] *= np.linspace(0, 1, n)
    x[-n:] *= np.linspace(1, 0, n)
    return x


def norm(x):
    return x / (np.max(np.abs(x)) + 1e-9)


L = np.zeros(N)
R = np.zeros(N)


def place(x, t, level, pan=0.0):
    i = int(t * SR)
    x = edge(norm(x)) * db(level)
    n = min(len(x), N - i)
    a = np.pi / 4 * (pan + 1)
    L[i:i + n] += x[:n] * np.cos(a)
    R[i:i + n] += x[:n] * np.sin(a)


def seg(t0, t1, fade=0.4):
    """envelope for an ambience bed between t0 and t1 with equal-power crossfades"""
    tt = np.arange(N) / SR
    up = np.clip((tt - (t0 - fade / 2)) / fade, 0, 1)
    dn = np.clip(((t1 + fade / 2) - tt) / fade, 0, 1)
    return np.sin(up * np.pi / 2) * np.sin(dn * np.pi / 2)


def noise(seed, lo=None, hi=None):
    r = np.random.default_rng(seed)
    x = r.standard_normal(N)
    if lo and hi:
        return filt(x, "bandpass", [lo, hi])
    if hi:
        return filt(x, "lowpass", hi)
    return x


tt = np.arange(N) / SR
# ---------- ambience beds ----------
room_l, room_r = norm(noise(1, hi=380)), norm(noise(2, hi=380))
swell = 1 + 0.25 * np.sin(2 * np.pi * 0.1 * tt)
room = seg(0, 58)
L += room_l * swell * room * db(-30)
R += room_r * swell * room * db(-30)
# distant evening traffic (act 1)
for tc, pan in ((2.0, -0.4), (7.2, 0.5), (11.5, -0.2)):
    n = int(3.0 * SR)
    place(filt(rng.standard_normal(n), "bandpass", [180, 900]) * np.hanning(n), tc - 1.5, -36, pan)
# birds (act 2 afternoon + act 3 spring): short chirp trains


def chirps(t0, t1, density, level, seed):
    r = np.random.default_rng(seed)
    t = t0
    while t < t1:
        f0 = 2800 + r.random() * 2200
        n = int(0.06 * SR)
        k = np.arange(n) / SR
        f = f0 * (1 + 0.25 * np.sin(2 * np.pi * 18 * k))
        c = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.hanning(n)
        for j in range(r.integers(2, 5)):
            place(c, t + j * 0.09, level + r.random() * -6, r.random() * 1.4 - 0.7)
        t += density * (0.6 + r.random())


chirps(14.2, 25.8, 1.4, -38, 11)
chirps(30.2, 33.8, 1.6, -38, 12)
chirps(34.2, 49.8, 1.0, -36, 13)
# rain on the window (beat 7)
rain = norm(noise(5, 1500, 7000)) * (0.6 + 0.4 * np.abs(noise(6, hi=8)) / 3)
L += rain * seg(26, 30) * db(-31)
R += norm(noise(7, 1500, 7000)) * seg(26, 30) * db(-31)
# evening hush (beat 13) and dawn air (beat 14, mostly ducked)
L += norm(noise(8, hi=250)) * seg(50, 54) * db(-34)
R += norm(noise(9, hi=250)) * seg(50, 54) * db(-34)
# shelter: echoey room tone (beat 15)
sh = norm(filt(noise(10, hi=600), "highpass", 80))
L += sh * seg(58, 63.5, 0.5) * db(-32)
R += np.roll(sh, 2200) * seg(58, 63.5, 0.5) * db(-32)

# ---------- SFX ----------


def purr(seconds, breath=0.28):
    n = int(seconds * SR)
    k = np.arange(n) / SR
    pulses = (0.5 + 0.5 * np.sin(2 * np.pi * 25 * k)) ** 3
    return filt(rng.standard_normal(n), "lowpass", 260) * pulses * (0.55 + 0.45 * np.sin(2 * np.pi * breath * k) ** 2)


def burst(seconds, lo, hi, decay):
    n = int(seconds * SR)
    return filt(rng.standard_normal(n), "bandpass", [lo, hi]) * np.exp(-np.linspace(0, decay, n))


def thud(seconds=0.35, f0=90):
    n = int(seconds * SR)
    k = np.arange(n) / SR
    return np.sin(2 * np.pi * f0 * k * (1 - 0.3 * k)) * np.exp(-k * 22) + filt(rng.standard_normal(n), "lowpass", 700) * np.exp(-k * 40) * 0.5


def bell(seconds=0.6):
    n = int(seconds * SR)
    k = np.arange(n) / SR
    return sum(np.sin(2 * np.pi * f * k) * np.exp(-k * d) for f, d in ((4200, 9), (6100, 12), (7900, 16)))


def mew(seconds=0.6):
    n = int(seconds * SR)
    k = np.arange(n) / SR
    f = 700 + 300 * np.sin(np.pi * k / seconds)
    tone = sum(np.sin(2 * np.pi * f * h * np.cumsum(np.ones(n)) / SR) / h for h in (1, 2, 3))
    return filt(tone, "bandpass", [500, 3500]) * np.sin(np.pi * k / seconds) ** 1.5


place(purr(4.6), 1.0, -24)
place(purr(3.8) * np.linspace(0.7, 1, int(3.8 * SR)), 6.2, -21)
place(burst(0.8, 900, 5000, 5), 5.7, -27, 0.1)            # stretch rustle
place(burst(0.8, 1200, 6000, 4) * (0.5 + 0.5 * np.sin(np.linspace(0, 60, int(0.8 * SR)))), 10.3, -24)  # body shake
for k in range(5):
    place(thud(0.12, 140), 14.05 + k * 0.13, -32, -0.4)   # paws on wood
place(thud(0.35, 85), 15.1, -19, -0.5)                     # counter landing
for k in range(4):
    place(thud(0.2, 120), 18.58 + k * 0.32, -24, 0.5)      # stairs
place(bell(), 22.3, -24)
place(bell(), 23.6, -22)
place(burst(0.4, 600, 4000, 6), 23.6, -26)                 # pounce rustle
for k in range(18):
    place(burst(0.03, 1500, 6000, 6), 26.1 + k * 0.21 + (k % 3) * 0.03, -36, -0.3)  # keys
place(burst(0.3, 1200, 6000, 5), 30.2, -28)                # collar flick
mob = sum(bell(2.0) * 0.4 for _ in range(1))
for k in range(5):
    place(bell(1.2), 34.3 + k * 0.42, -32, 0.2 * (k % 2))  # mobile tinkle
for t0 in (38.4, 39.6, 40.8):
    place(burst(0.25, 800, 4000, 8), t0 + 0.4, -26)        # paw skids
for k in range(3):
    place(burst(0.15, 1000, 3000, 10) * 0.8, 38.6 + k * 1.2, -34, -0.5)  # toy rattle
place(purr(3.5, 0.2), 42.3, -27)                           # tiny sleep purr
place(mew(), 46.4, -22)
place(burst(1.0, 500, 3000, 3), 50.3, -26)                 # fleece rustle
place(purr(3.0, 0.3) * 0.5, 54.5, -36)                     # the only sound in the silence
place(mew(0.5) * 0.7, 59.7, -26)

# ---------- accents (2) ----------


def riser():
    n = int(0.8 * SR)
    k = np.arange(n) / SR
    f = 500 * (4500 / 500) ** (k / 0.8)
    return (np.sin(2 * np.pi * np.cumsum(f) / SR) * 0.4 + filt(rng.standard_normal(n), "highpass", 2000) * 0.6) * (k / 0.8) ** 2


def sub_hit():
    n = int(1.6 * SR)
    k = np.arange(n) / SR
    f = 55 * (38 / 55) ** np.minimum(k / 0.4, 1)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-k * 3.2) * 0.8 + filt(rng.standard_normal(n), "lowpass", 900) * np.exp(-k * 18) * 0.35


place(riser(), 4.8, -26)
place(sub_hit(), 5.6, -15)
place(riser(), 60.7, -27)
place(sum(np.sin(2 * np.pi * f * np.arange(int(2.5 * SR)) / SR) * np.exp(-np.arange(int(2.5 * SR)) / SR * 1.6) for f in (880, 1320, 2640)), 61.5, -20)

# ---------- music: sparse additive piano ----------


def note(midi, seconds=2.8):
    f0 = 440 * 2 ** ((midi - 69) / 12)
    n = int(seconds * SR)
    k = np.arange(n) / SR
    x = np.zeros(n)
    for h in range(1, 7):
        fh = f0 * h * np.sqrt(1 + 0.0004 * h * h)
        x += 0.6 ** h * np.sin(2 * np.pi * fh * k) * np.exp(-k * (0.9 + 0.35 * h))
    return x * np.minimum(k / 0.003, 1)


A2, A3, B3, C4, D4, E4, F4, G4, A4, B4, C5, D5, E5, G5, A5 = 45, 57, 59, 60, 62, 64, 65, 67, 69, 71, 72, 74, 76, 79, 81
notes = [
    (1.2, A3), (2.5, E4), (3.8, C5),
    (6.0, A4), (7.3, C5), (8.5, E4), (9.6, B4), (10.0, A4), (11.3, E4), (12.6, C5), (14.0, D5), (15.3, A4),
    (16.6, E4), (18.0, C5), (19.3, B4), (20.6, G4), (22.0, A4), (23.3, E4), (24.6, C5), (26.0, A4), (27.4, F4),
    (28.7, E4), (30.2, A4), (32.2, E4),
    (34.0, C4), (35.0, G4), (36.0, E5), (37.0, C5), (38.0, G4), (39.0, E5), (40.0, D5), (41.0, C5), (42.0, G4),
    (43.0, E4), (44.0, C5), (45.0, G4), (46.0, A4), (47.0, E5), (48.0, C5), (49.0, G4),
    (50.0, E5), (51.5, D5), (53.0, C5),
    (58.4, A2), (61.5, A5),
]
for t0, m in notes:
    place(note(m), t0, -27 if t0 < 34 or t0 > 50 else -25, -0.15)
# end-card chord (A minor add9) decaying into silence
chord = sum(note(m, 6.0) for m in (A3, C4, E4, 71))
place(chord, 64.0, -20)

mix = np.stack([L, R], axis=1)
# scripted silence: duck everything except the tiny purr (54.5-57.5)
duck = 1 - 0.97 * (seg(54.5, 57.5, 0.06))
mix *= duck[:, None]
mix = mix / np.max(np.abs(mix)) * db(-1)
sf.write(sys.argv[1], mix.astype(np.float32), SR, subtype="PCM_16")
print("wrote", sys.argv[1], mix.shape[0] / SR, "s")
