import React from "react";
import { Composition } from "remotion";
import beats from "./beats.json";
import { WhatIf } from "./WhatIf";

export const RemotionRoot: React.FC = () => (
  <Composition
    id="WhatIf"
    component={WhatIf}
    durationInFrames={Math.round(beats.meta.duration * beats.meta.fps)}
    fps={beats.meta.fps}
    width={beats.meta.width}
    height={beats.meta.height}
  />
);
