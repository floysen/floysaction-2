// Registry of character head bones; the FaceBlur effect pixelates every registered face each frame.
import * as THREE from "three";

export type FaceEntry = { head: THREE.Object3D; top?: THREE.Object3D; radius: number };
export const FACES = new Map<string, FaceEntry>();

export const registerFace = (id: string, e: FaceEntry) => FACES.set(id, e);
export const unregisterFace = (id: string) => FACES.delete(id);
