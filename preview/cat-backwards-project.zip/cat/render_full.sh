#!/usr/bin/env bash
# Render + master the full 70 s video. Run from this folder in Git Bash:  bash render_full.sh
set -e
cd "$(dirname "$0")"
mkdir -p out
[ -d node_modules ] || npm i

echo "== 1/3 Rendering 2100 frames (1080x1920, 30 fps) =="
npx remotion render WhatIf out/raw.mp4 --gl=angle --codec=h264 --crf=16 --pixel-format=yuv420p --concurrency=50% --timeout=120000

echo "== 2/3 Mastering sound to -16 LUFS (two-pass) =="
FF="npx remotion ffmpeg"
J=$($FF -hide_banner -i out/raw.mp4 -vn -af loudnorm=I=-16:TP=-1.5:LRA=7:print_format=json -c:a pcm_s16le -f null - 2>&1 | sed -n '/^{/,/^}/p')
g(){ echo "$J" | grep "\"$1\"" | grep -o '[-0-9.]*' | head -1; }
$FF -hide_banner -loglevel error -y -i out/raw.mp4 -c:v copy \
  -af "loudnorm=I=-16:TP=-1.5:LRA=7:measured_I=$(g input_i):measured_TP=$(g input_tp):measured_LRA=$(g input_lra):measured_thresh=$(g input_thresh):offset=$(g target_offset):linear=true" \
  -ar 44100 -c:a aac -b:a 192k -movflags +faststart out/cat-backwards_en_70s.mp4

echo "== 3/3 Check =="
$FF -hide_banner -i out/cat-backwards_en_70s.mp4 -vn -af loudnorm=I=-16:TP=-1.5:print_format=json -c:a pcm_s16le -f null - 2>&1 | grep -E '"input_(i|tp)"'
echo "Done: out/cat-backwards_en_70s.mp4"
