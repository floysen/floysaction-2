import React from "react";
import { AbsoluteFill, Audio, staticFile, useCurrentFrame } from "remotion";
import { ThreeCanvas } from "@remotion/three";
import * as THREE from "three";
import beats from "./beats.json";
import { FPS, ramp } from "./lib/time";
import { lightAt } from "./story";
import { Plaza } from "./scenes/Plaza";
import { CameraRig, Env, Lights, Post } from "./three/Stage";
import { Callout, Caption, EndCard, Fade, Hud, Title, Vignette } from "./overlay/Overlays";

export const WhatIf: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const { width, height } = beats.meta;
  const l = lightAt(t);
  const [b0, b1] = beats.fades.blackOut;
  return (
    <AbsoluteFill style={{ backgroundColor: "#1C2147" }}>
      {t < beats.endCard.from + 0.6 && (
        <ThreeCanvas
          width={width}
          height={height}
          shadows={{ type: THREE.PCFSoftShadowMap }}
          gl={{ alpha: false, antialias: true, preserveDrawingBuffer: true }}
          camera={{ fov: 46, near: 0.05, far: 400 }}
        >
          <color attach="background" args={[l.fog]} />
          <CameraRig />
          <Env />
          <Lights l={l} />
          <Plaza t={t} l={l} />
          <Post bloom={l.bloom} sat={l.sat} contrast={l.contrast} />
        </ThreeCanvas>
      )}
      <Vignette />
      <Title t={t} />
      <Hud t={t} />
      <Callout t={t} />
      <Caption t={t} />
      <Fade amount={ramp(t, b0, b1)} color="#000000" />
      <EndCard t={t} />
      <Audio src={staticFile("audio/mix.wav")} />
    </AbsoluteFill>
  );
};
