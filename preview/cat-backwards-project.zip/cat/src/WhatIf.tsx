import React from "react";
import { AbsoluteFill, Audio, staticFile, useCurrentFrame } from "remotion";
import { ThreeCanvas } from "@remotion/three";
import * as THREE from "three";
import beats from "./beats.json";
import { FPS } from "./lib/time";
import { Room } from "./scenes/Room";
import { CameraRig, Env, Lights, Post } from "./three/Stage";
import { Callout, Caption, Hud, Title, Vignette } from "./overlay/Overlays";

export const WhatIf: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const { width, height } = beats.meta;
  return (
    <AbsoluteFill style={{ backgroundColor: "#2A2226" }}>
      <ThreeCanvas
        width={width}
        height={height}
        shadows={{ type: THREE.PCFSoftShadowMap }}
        gl={{ alpha: false, antialias: true, preserveDrawingBuffer: true }}
        camera={{ fov: 42, near: 0.05, far: 60 }}
      >
        <color attach="background" args={["#2A2226"]} />
        <CameraRig />
        <Env />
        <Lights />
        <Room t={t} />
        <Post bloom={0.45} sat={0.06} contrast={0.06} />
      </ThreeCanvas>
      <Vignette />
      <Title t={t} />
      <Hud t={t} />
      <Callout t={t} />
      <Caption t={t} />
      <Audio src={staticFile("audio/mix.wav")} />
    </AbsoluteFill>
  );
};
