// Realistic post stack: contact AO, bloom, face mosaic, grade, AA. Includes the Remotion "black frame" fix.
import * as THREE from "three";
import React, { useEffect, useLayoutEffect } from "react";
import { useThree } from "@react-three/fiber";
import { continueRender, delayRender, useCurrentFrame } from "remotion";
import { EffectComposer, N8AO, Bloom, HueSaturation, BrightnessContrast, SMAA, DepthOfField, ToneMapping } from "@react-three/postprocessing";
import { ToneMappingMode } from "postprocessing";
import { FaceBlurPass } from "./FaceBlur";

const Kick: React.FC = () => {
  const { advance } = useThree();
  const frame = useCurrentFrame();
  useEffect(() => {
    const h = delayRender("postfx-kick");
    const id = requestAnimationFrame(() => {
      advance(performance.now());
      continueRender(h);
    });
    return () => cancelAnimationFrame(id);
  }, [advance, frame]);
  return null;
};

// renderer settings for physically based output
export const RendererSetup: React.FC<{ exposure?: number }> = ({ exposure = 1 }) => {
  const { gl } = useThree();
  useLayoutEffect(() => {
    gl.toneMapping = THREE.NoToneMapping; // tone mapping is done in the composer (after bloom)
    gl.outputColorSpace = THREE.SRGBColorSpace;
    gl.shadowMap.enabled = true;
    gl.shadowMap.type = THREE.PCFSoftShadowMap;
    (gl as unknown as { toneMappingExposure: number }).toneMappingExposure = exposure;
  }, [gl, exposure]);
  return null;
};

export const RealPost: React.FC<{ bloom?: number; sat?: number; contrast?: number; dof?: { target: THREE.Vector3; bokeh: number }; preview?: boolean }> = ({
  bloom = 0.35, sat = 0.04, contrast = 0.05, dof, preview = false,
}) => (
  <>
    <EffectComposer multisampling={0} enableNormalPass={false} frameBufferType={THREE.HalfFloatType}>
      <N8AO aoRadius={1.2} intensity={2.2} distanceFalloff={0.8} quality={preview ? "performance" : "high"} halfRes={preview} />
      <DepthOfField target={dof?.target ?? new THREE.Vector3(0, 0, -10)} focalLength={0.02} bokehScale={dof?.bokeh ?? 0} />
      <Bloom mipmapBlur intensity={bloom} luminanceThreshold={0.9} luminanceSmoothing={0.1} radius={0.7} />
      <ToneMapping mode={ToneMappingMode.AGX} />
      <FaceBlurPass />
      <HueSaturation saturation={sat} />
      <BrightnessContrast contrast={contrast} />
      <SMAA />
    </EffectComposer>
    <Kick />
  </>
);
