import * as THREE from "three";
import React, { useMemo } from "react";
import { random } from "remotion";
import { lawn, oakFloor, plaster, rugTex, textTex, weave } from "../three/textures";
import { SeatedPerson, StandingPerson } from "../three/chars/Faceless";
import { Cat } from "../three/chars/Cat";
import { clamp, lerp, ramp } from "../lib/time";
import { beatIndex, catGreyAt, catScaleAt, DAUGHTER, hairGreyAt, hop, Light, photosAt, Sky, yearAt, YOU } from "../story";

type V3 = [number, number, number];

const Box: React.FC<{ p: V3; s: V3; c: string; map?: THREE.Texture; r?: number; shadow?: boolean; rot?: V3; opacity?: number }> = ({ p, s, c, map, r = 0.8, shadow = true, rot, opacity }) => (
  <mesh position={p} rotation={rot} castShadow={shadow} receiveShadow>
    <boxGeometry args={s} />
    <meshStandardMaterial color={c} roughness={r} flatShading map={map} transparent={opacity !== undefined} opacity={opacity ?? 1} />
  </mesh>
);

const SKIES: Record<Sky, string[]> = {
  dusk: ["#5A4A78", "#C98A8A", "#F2B07A", "#F6C890"],
  noon: ["#6F9BD8", "#9EC0E4", "#D6E6F2", "#EEF4F8"],
  overcast: ["#8A929C", "#A9B0B8", "#C4C9CE", "#D2D6DA"],
  golden: ["#8FB4D8", "#C8D8E0", "#F4DCA8", "#FBE6B8"],
  evening: ["#3A3A62", "#7A6A8A", "#D88A70", "#E8A878"],
  dawn: ["#C8C0DC", "#E8DCE8", "#FFF0DC", "#FFF6EA"],
};
const skyTex = (s: Sky) =>
  textTex(`sky-${s}`, 64, 256, (g) => {
    const gr = g.createLinearGradient(0, 0, 0, 256);
    SKIES[s].forEach((c, i) => gr.addColorStop([0, 0.45, 0.8, 1][i], c));
    g.fillStyle = gr;
    g.fillRect(0, 0, 64, 256);
  });

const calendarTex = (year: number) =>
  textTex(`cal-${year}`, 256, 320, (g) => {
    g.fillStyle = "#F4EEE4";
    g.fillRect(0, 0, 256, 320);
    g.fillStyle = "#C8463A";
    g.fillRect(0, 0, 256, 70);
    g.fillStyle = "#FFFFFF";
    g.font = "bold 44px sans-serif";
    g.textAlign = "center";
    g.fillText(String(year), 128, 52);
    g.fillStyle = "#8A8070";
    for (let r = 0; r < 5; r++) for (let c = 0; c < 7; c++) g.fillRect(18 + c * 33, 96 + r * 42, 22, 22);
  });

const Tree: React.FC<{ p: V3; t: number; h: number; seed: string; leaf: string }> = ({ p, t, h, seed, leaf }) => {
  const sway = Math.sin(t * 0.75 + p[0] * 0.13 + p[2] * 0.07) * 0.16 * 0.45;
  return (
    <group position={p}>
      <mesh position={[0, h * 0.3, 0]}>
        <cylinderGeometry args={[0.12, 0.18, h * 0.6, 6]} />
        <meshStandardMaterial color="#4A3628" roughness={0.9} flatShading />
      </mesh>
      <mesh position={[sway, h * 0.75, 0]} rotation={[0, random(seed) * 3, sway * 0.3]}>
        <icosahedronGeometry args={[h * 0.32, 0]} />
        <meshStandardMaterial color={leaf} roughness={0.9} flatShading />
      </mesh>
      <mesh position={[sway * 1.2 + 0.3, h * 0.92, 0.2]}>
        <icosahedronGeometry args={[h * 0.2, 0]} />
        <meshStandardMaterial color={leaf} roughness={0.9} flatShading />
      </mesh>
    </group>
  );
};

// analytic particle cloud: positions are pure functions of t
const Points: React.FC<{ n: number; seed: string; size: number; color: string; opacity: number; additive?: boolean; at: (i: number, r: (k: string) => number) => V3 | null }> = ({ n, seed, size, color, opacity, additive, at }) => {
  const geo = useMemo(() => new THREE.BufferGeometry(), []);
  const pos = new Float32Array(n * 3);
  let m = 0;
  for (let i = 0; i < n; i++) {
    const p = at(i, (k) => random(`${seed}${k}${i}`));
    if (!p) continue;
    pos.set(p, m * 3);
    m++;
  }
  geo.setAttribute("position", new THREE.BufferAttribute(pos.slice(0, m * 3), 3));
  return (
    <points geometry={geo}>
      <pointsMaterial color={color} size={size} transparent opacity={opacity} toneMapped={false} depthWrite={false} blending={additive ? THREE.AdditiveBlending : THREE.NormalBlending} />
    </points>
  );
};

// world-space hand target → local space of a character standing/sitting at `pos` with `yaw`
const toLocal = (w: V3, pos: V3, yaw: number): V3 => {
  const v = new THREE.Vector3(...w).sub(new THREE.Vector3(...pos)).applyAxisAngle(new THREE.Vector3(0, 1, 0), -yaw);
  return [v.x, v.y, v.z];
};
const face = (from: V3, to: V3) => Math.atan2(to[0] - from[0], to[2] - from[2]);
const mixV = (a: V3, b: V3, k: number): V3 => [lerp(a[0], b[0], k), lerp(a[1], b[1], k), lerp(a[2], b[2], k)];

const Characters: React.FC<{ t: number }> = ({ t }) => {
  const b = beatIndex(t);
  const grey = catGreyAt(t);
  const scale = catScaleAt(t);
  const look = { ...YOU, hairGrey: hairGreyAt(t) };
  const stroke = Math.sin((t * Math.PI * 2) / 1.2);
  const sofaYou: V3 = [-0.42, 0.47, -0.4];
  const sofaYaw = 0.35;
  const catSofa: V3 = [0.2, 0.47, -0.36];

  if (b <= 3) {
    const sit = t >= 6;
    const lift = ramp(t, 5.6, 6.1);
    const stretch = ramp(t, 5.7, 6.0);
    const gk = clamp((t - 5.6) / 0.8);
    const glow = t >= 5.6 && t <= 6.4 ? Math.sin(Math.PI * gk) * 0.6 : 0;
    const shake = b === 3 ? Math.sin(Math.PI * clamp((t - 10.3) / 0.8)) : 0;
    const hand: V3 = sit
      ? [catSofa[0] - 0.08, catSofa[1] + 0.2 + stroke * 0.04, catSofa[2] - 0.04]
      : [catSofa[0] - 0.02 + stroke * 0.06, catSofa[1] + 0.12, catSofa[2] - 0.02];
    return (
      <>
        <SeatedPerson position={sofaYou} yaw={sofaYaw} handTarget={toLocal(hand, sofaYou, sofaYaw)} look={look} lean={-0.06} />
        <Cat position={catSofa} yaw={sit ? -0.25 : 0.6} t={t} pose={sit ? "sit" : "curl"} lift={lift} stretch={stretch} shake={shake} grey={grey} glow={glow} />
        {b === 3 && (
          // shed grey fur drifting down through the light
          <Points n={220} seed="fur" size={0.008} color="#BDBAB6" opacity={0.85} at={(i, r) => {
            const t0 = 10.3 + r("s") * 0.5;
            if (t < t0) return null;
            const d = t - t0;
            const a = r("a") * Math.PI * 2;
            const sp = 0.15 + r("v") * 0.35;
            return [catSofa[0] + Math.cos(a) * sp * Math.min(d, 0.6) + Math.sin(t + i) * 0.02, Math.max(0.47, catSofa[1] + 0.25 + r("h") * 0.1 - 0.12 * d), catSofa[2] + Math.sin(a) * sp * Math.min(d, 0.6)];
          }} />
        )}
      </>
    );
  }

  if (b === 4) {
    const youPos: V3 = [-2.0, 0, -1.05];
    const a: V3 = [-1.0, 0, 0.6];
    const m: V3 = [-1.85, 0, 0.25];
    const top: V3 = [-2.5, 0.945, 0.1];
    let p: V3 = a;
    let pose = { gait: 0, tuck: 0, crouch: 0 };
    let yaw = face(a, m);
    if (t < 14.65) {
      p = mixV(a, m, clamp((t - 14.0) / 0.65));
      pose = { gait: t * 18, tuck: 0, crouch: 0 };
    } else if (t < 15.1) {
      p = hop(t, 14.65, 0.45, m, top, 0.32);
      pose = { gait: 0, tuck: 1, crouch: 0 };
      yaw = face(m, top);
    } else {
      p = top;
      yaw = lerp(face(m, top), 0.9, ramp(t, 15.4, 16.4));
    }
    const turn = ramp(t, 15.1, 15.7) * 0.9;
    return (
      <>
        <StandingPerson position={youPos} yaw={-Math.PI / 2} look={look} handR={[-0.18, 0.96, 0.42]} handL={[0.18, 0.96, 0.42]} headYaw={turn} />
        <Cat position={p} yaw={yaw} t={t} pose="stand" {...pose} grey={grey} glow={0} scale={scale} />
      </>
    );
  }

  if (b === 5) {
    const stops: V3[] = [[2.65, 0, 2.35], [2.65, 0.36, 1.62], [2.65, 0.72, 1.06], [2.65, 1.08, 0.5], [2.65, 1.08, 0.05]];
    let p = stops[0];
    let tuck = 0;
    for (let k = 0; k < 4; k++) {
      const t0 = 18.3 + k * 0.32;
      if (t >= t0) {
        p = hop(t, t0, 0.28, stops[k], stops[k + 1], 0.2);
        tuck = t < t0 + 0.28 ? 1 : 0;
      }
    }
    return <Cat position={p} yaw={Math.PI} t={t} pose="stand" tuck={tuck} grey={grey} glow={0} scale={scale} />;
  }

  if (b === 6) {
    const start: V3 = [0.48, 0, 0.5];
    const land: V3 = [0.36, 0, 0.36];
    const p = t < 23.6 ? start : hop(t, 23.6, 0.35, start, land, 0.12);
    const crouch = t < 23.4 ? ramp(t, 22.2, 22.6) : t < 23.95 ? 0 : 1;
    return <Cat position={p} yaw={face(start, [0.25, 0, 0.1])} t={t} pose="stand" crouch={crouch} tuck={t >= 23.6 && t < 23.95 ? 0.6 : 0} grey={grey} glow={0} scale={scale} />;
  }

  if (b === 7) {
    const you: V3 = [-1.75, 0.47, -1.5];
    const jit = (k: number) => Math.max(0, Math.sin(t * 17 + k * 2.1)) * 0.025;
    const catP: V3 = [-0.88, 0.73, -2.38];
    return (
      <>
        <SeatedPerson position={you} yaw={Math.PI} handTarget={[0.15, 0.31 + jit(0), 0.42]} handL={[-0.15, 0.31 + jit(1), 0.42]} look={look} />
        <Cat position={catP} yaw={face(catP, you)} t={t} pose="sit" headTilt={ramp(t, 26.4, 26.9) * 0.26} grey={grey} glow={0} scale={scale} />
      </>
    );
  }

  if (b === 8) {
    const c: V3 = [0.1, 0, -1.7];
    const k = ramp(t, 30.2, 30.8) * (1 - ramp(t, 31.6, 32.2));
    const ang = (t - 30) * (Math.PI / 2) + 0.4;
    const catP: V3 = [c[0] + Math.cos(ang) * 0.4, 0, c[2] + Math.sin(ang) * 0.4];
    const catYaw = Math.atan2(-Math.sin(ang), Math.cos(ang));
    return (
      <>
        <StandingPerson position={c} yaw={Math.PI} look={look} handR={mixV([-0.24, 0.92, 0.08], [-0.09, 1.47, 0.13], k)} handL={mixV([0.24, 0.92, 0.08], [0.09, 1.47, 0.13], k)} headPitch={-0.08} />
        <Cat position={catP} yaw={catYaw} t={t} pose="stand" gait={t * 12} grey={grey} glow={0} scale={scale} />
      </>
    );
  }

  if (b === 9) {
    return (
      <>
        {/* baby asleep in the crib (blanket hump + small blank head) */}
        <mesh position={[-1.7, 0.52, -1.9]} scale={[1, 0.45, 1.6]} castShadow>
          <icosahedronGeometry args={[0.13, 1]} />
          <meshStandardMaterial color="#E8C04A" roughness={0.9} flatShading map={weave([2, 2])} />
        </mesh>
        <mesh position={[-1.7, 0.53, -1.62]} castShadow>
          <icosahedronGeometry args={[0.065, 1]} />
          <meshStandardMaterial color={DAUGHTER.skin} roughness={0.8} flatShading />
        </mesh>
        <Cat position={[-1.72, 0, -1.12]} yaw={0.4} t={t} pose="sit" grey={0} glow={0} scale={scale} />
      </>
    );
  }

  if (b === 10) {
    const spot = (tt: number): V3 => [0.3 + Math.sin(1.3 * (tt - 38)) * 0.45, 0, 0.25 + Math.sin(0.9 * (tt - 38) + 1) * 0.3];
    const kid: V3 = [-0.6, 0, 0.55];
    let p: V3 = [0.05, 0, 0.75];
    let tuck = 0;
    for (const t0 of [38.4, 39.6, 40.8]) {
      if (t >= t0) {
        const from = p;
        const to = spot(t0 + 0.4);
        p = hop(t, t0, 0.4, from, to, 0.18);
        tuck = t < t0 + 0.4 ? 1 : 0;
      }
    }
    const crouch = tuck ? 0 : 0.8;
    const sp = spot(t);
    return (
      <>
        <StandingPerson position={kid} yaw={face(kid, sp)} look={{ ...DAUGHTER }} handR={[-0.2, 1.15, 0.35]} handL={[0.2, 0.95, 0.15]} scale={0.55} />
        <mesh position={toWorld([-0.2, 1.15, 0.38], kid, face(kid, sp), 0.55)} rotation={[0.6, face(kid, sp), 0]}>
          <cylinderGeometry args={[0.035, 0.035, 0.008, 12]} />
          <meshStandardMaterial color="#E8F0F6" roughness={0.05} metalness={0.8} />
        </mesh>
        {/* the dancing light spot */}
        <mesh position={[sp[0], 0.007, sp[2]]} rotation={[-Math.PI / 2, 0, 0]}>
          <circleGeometry args={[0.07, 20]} />
          <meshBasicMaterial color={new THREE.Color("#FFF2C8").multiplyScalar(1.6)} toneMapped={false} transparent opacity={0.85} blending={THREE.AdditiveBlending} depthWrite={false} />
        </mesh>
        <Cat position={p} yaw={face(p, sp)} t={t} pose="stand" crouch={crouch} tuck={tuck} grey={0} glow={0} scale={scale} />
      </>
    );
  }

  if (b === 11) {
    const k = ramp(t, 42.3, 42.9);
    return <Cat position={[0.55, 0.035, 0.55]} yaw={lerp(0.4, 2.2, k)} t={t} pose="curl" grey={0} glow={0} scale={scale} />;
  }

  if (b === 12) {
    const you: V3 = [0, 0, 0.3];
    return (
      <>
        <StandingPerson position={you} yaw={0} look={look} handR={[-0.07, 0.99, 0.43]} handL={[0.07, 0.99, 0.43]} headPitch={0.3} />
        <Cat position={[0, 1.005, 0.74]} yaw={2.4} t={t} pose="curl" lift={0.3} grey={0} glow={0} scale={scale} />
      </>
    );
  }

  if (b === 13) {
    const kitten: V3 = [0.2, 0.47, -0.3];
    const tuck = ramp(t, 50.1, 50.6);
    const kid: V3 = [0.85, 0, 0.25];
    return (
      <>
        <SeatedPerson position={sofaYou} yaw={sofaYaw} handTarget={toLocal([0.14, 0.58 - tuck * 0.04, -0.28], sofaYou, sofaYaw)} look={look} lean={-0.08} />
        <Cat position={kitten} yaw={0.4} t={t} pose="curl" grey={0} glow={0} scale={scale} />
        {/* fleece blanket folded around her */}
        <mesh position={[0.2, 0.5, -0.33]} scale={[1.25, lerp(0.5, 0.38, tuck), 1.1]} castShadow>
          <icosahedronGeometry args={[0.13, 1]} />
          <meshStandardMaterial color="#E8DCC8" roughness={0.95} flatShading map={weave([3, 3])} />
        </mesh>
        <pointLight position={[0.2, 0.52, -0.2]} color="#FFB060" intensity={0.25 * tuck} distance={0.6} decay={2} />
        <StandingPerson position={kid} yaw={face(kid, kitten)} look={{ ...DAUGHTER }} handR={[-0.12, 0.95, 0.3]} handL={[0.12, 0.95, 0.3]} headPitch={0.35} scale={0.68} />
      </>
    );
  }

  // b === 14: dawn, holding her against the chest
  const you: V3 = [0, 0, -1.1];
  const sway = Math.sin(t * Math.PI * 2 * 0.3) * 0.08;
  const chest = toWorld([0, 1.27, 0.25], you, Math.PI + sway, 1);
  return (
    <>
      <StandingPerson position={you} yaw={Math.PI} sway={sway} look={look} handR={[-0.08, 1.22, 0.24]} handL={[0.08, 1.3, 0.24]} headPitch={0.35} />
      <Cat position={chest} yaw={Math.PI + sway + 1.2} t={t} pose="curl" grey={0} glow={0} scale={scale} />
    </>
  );
};

function toWorld(local: V3, pos: V3, yaw: number, scale: number): V3 {
  const v = new THREE.Vector3(...local).multiplyScalar(scale).applyAxisAngle(new THREE.Vector3(0, 1, 0), yaw).add(new THREE.Vector3(...pos));
  return [v.x, v.y, v.z];
}

export const Room: React.FC<{ t: number; l: Light }> = ({ t, l }) => {
  const floor = useMemo(() => oakFloor([3, 3]), []);
  const wall = useMemo(() => plaster([4, 2]), []);
  const sofaFab = useMemo(() => weave([4, 2]), []);
  const grass = useMemo(() => lawn([4, 4]), []);
  const b = beatIndex(t);
  const act = b <= 3 ? 1 : b <= 8 ? 2 : b <= 13 ? 3 : 4;
  const leaf = act === 3 ? "#5E8A4A" : act === 4 ? "#6A8A5A" : "#3E5A3A";
  const sunVisible = l.sky !== "overcast";
  const sunY = l.sky === "noon" || l.sky === "golden" ? 4.2 : l.sky === "dawn" ? 1.5 : 2.0;
  const photos = photosAt(t);
  const desk = b <= 8;
  const crib = b >= 9 && b <= 13;
  const rampOpacity = b <= 4 ? 1 : b === 5 ? 1 - ramp(t, 20.0, 20.5) : 0;
  const toyOut = t >= 22.3;
  const toyP: V3 = !toyOut ? [0.2, 0.03, -0.05] : t < 22.8 ? mixV([0.2, 0.03, -0.05], [0.3, 0.03, 0.25], ramp(t, 22.3, 22.8)) : [0.3, 0.03 + (t > 23.95 && t < 24.6 ? Math.abs(Math.sin(t * 20)) * 0.01 : 0), 0.25];

  return (
    <group>
      {/* floor + rug */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[6, 5.2]} />
        <meshStandardMaterial color="#B98A5E" roughness={0.65} map={floor} envMapIntensity={0.5} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.006, 0.45]} receiveShadow>
        <planeGeometry args={[2.4, 1.6]} />
        <meshStandardMaterial color="#C9B79A" roughness={0.95} map={rugTex()} />
      </mesh>

      {/* back wall with window opening (x -1.2..1.2, y 0.7..2.3) */}
      <Box p={[-2.1, 1.35, -2.55]} s={[1.8, 2.7, 0.1]} c="#D8C8B2" map={wall} />
      <Box p={[2.1, 1.35, -2.55]} s={[1.8, 2.7, 0.1]} c="#D8C8B2" map={wall} />
      <Box p={[0, 0.35, -2.55]} s={[2.4, 0.7, 0.1]} c="#D8C8B2" map={wall} />
      <Box p={[0, 2.5, -2.55]} s={[2.4, 0.4, 0.1]} c="#D8C8B2" map={wall} />
      <Box p={[0, 0.7, -2.5]} s={[2.5, 0.06, 0.18]} c="#EDE6DA" r={0.6} />
      <Box p={[0, 0.715, -2.36]} s={[2.4, 0.03, 0.3]} c="#EDE6DA" r={0.6} />
      <Box p={[0, 2.3, -2.5]} s={[2.5, 0.06, 0.12]} c="#EDE6DA" r={0.6} />
      <Box p={[-1.22, 1.5, -2.5]} s={[0.06, 1.66, 0.12]} c="#EDE6DA" r={0.6} />
      <Box p={[1.22, 1.5, -2.5]} s={[0.06, 1.66, 0.12]} c="#EDE6DA" r={0.6} />
      <Box p={[0, 1.5, -2.52]} s={[0.05, 1.6, 0.06]} c="#EDE6DA" r={0.6} shadow={false} />
      <Box p={[0, 1.55, -2.52]} s={[2.4, 0.04, 0.06]} c="#EDE6DA" r={0.6} shadow={false} />
      <mesh position={[0, 1.5, -2.53]}>
        <planeGeometry args={[2.4, 1.6]} />
        <meshStandardMaterial color="#FFFFFF" transparent opacity={0.08} roughness={0.08} metalness={0.1} depthWrite={false} envMapIntensity={1.4} />
      </mesh>
      {l.rain && (
        // rain streaks running down the glass
        <Points n={160} seed="rain" size={0.006} color="#E8EEF4" opacity={0.7} at={(i, r) => {
          const sp = 0.35 + r("v") * 0.5;
          const y = 2.28 - ((r("y") * 1.6 + t * sp) % 1.58);
          return [-1.18 + r("x") * 2.36, y, -2.535];
        }} />
      )}
      <Box p={[-3.0, 1.35, 0]} s={[0.1, 2.7, 5.2]} c="#CDBBA4" map={wall} />
      <Box p={[3.0, 1.35, 0]} s={[0.1, 2.7, 5.2]} c="#CDBBA4" map={wall} />
      <Box p={[0, 0.05, -2.48]} s={[6, 0.1, 0.03]} c="#EDE6DA" />

      {/* outside */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.02, -9]}>
        <planeGeometry args={[30, 13]} />
        <meshStandardMaterial color={act === 3 ? "#5E7E44" : "#4E6A3E"} roughness={0.9} map={grass} />
      </mesh>
      {Array.from({ length: 16 }, (_, i) => (
        <Box key={i} p={[-6 + i * 0.8, 0.5, -6]} s={[0.12, 1.0, 0.05]} c="#8A6A4A" shadow={false} />
      ))}
      <Box p={[0, 0.8, -6]} s={[13, 0.08, 0.04]} c="#8A6A4A" shadow={false} />
      <Tree p={[-2.2, 0, -7.5]} t={t} h={4.2} seed="t1" leaf={leaf} />
      <Tree p={[2.6, 0, -9]} t={t} h={5} seed="t2" leaf={leaf} />
      <Tree p={[0.4, 0, -12]} t={t} h={3.6} seed="t3" leaf={leaf} />
      <mesh position={[0, 4, -16]}>
        <planeGeometry args={[40, 14]} />
        <meshBasicMaterial map={skyTex(l.sky)} toneMapped={false} fog={false} />
      </mesh>
      {sunVisible && (
        <mesh position={[-1.6, sunY, -15.8]}>
          <circleGeometry args={[0.5, 24]} />
          <meshBasicMaterial color={new THREE.Color(l.sky === "noon" ? "#FFFBF0" : "#FFE0A8").multiplyScalar(2.4)} toneMapped={false} fog={false} />
        </mesh>
      )}

      {/* radiator, cat bed, bowl */}
      <Box p={[0, 0.38, -2.42]} s={[1.4, 0.5, 0.08]} c="#E6E0D6" r={0.5} />
      <mesh position={[-0.9, 0.06, -2.1]} receiveShadow castShadow>
        <cylinderGeometry args={[0.28, 0.24, 0.12, 10]} />
        <meshStandardMaterial color="#A33A2E" roughness={0.9} flatShading map={sofaFab} />
      </mesh>
      <mesh position={[0.9, 0.03, -2.0]} castShadow>
        <cylinderGeometry args={[0.1, 0.08, 0.06, 10]} />
        <meshStandardMaterial color="#6F9BD8" roughness={0.4} />
      </mesh>

      {/* sofa (seat top y = 0.47) */}
      <Box p={[0, 0.18, -0.4]} s={[2.1, 0.32, 0.9]} c="#4E6A68" map={sofaFab} />
      <Box p={[-0.5, 0.41, -0.36]} s={[0.98, 0.13, 0.8]} c="#5E7C7A" map={sofaFab} />
      <Box p={[0.5, 0.41, -0.36]} s={[0.98, 0.13, 0.8]} c="#5E7C7A" map={sofaFab} />
      <Box p={[0, 0.66, -0.78]} s={[2.1, 0.62, 0.22]} c="#5A7674" map={sofaFab} />
      <Box p={[-1.1, 0.5, -0.4]} s={[0.2, 0.32, 0.9]} c="#4E6A68" map={sofaFab} />
      <Box p={[1.1, 0.5, -0.4]} s={[0.2, 0.32, 0.9]} c="#4E6A68" map={sofaFab} />
      <Box p={[0.75, 0.49, -0.4]} s={[0.5, 0.04, 0.78]} c="#C98A5A" map={sofaFab} />

      {/* the old favourite toy (under the sofa until beat 6) */}
      <group position={toyP}>
        <mesh castShadow>
          <icosahedronGeometry args={[0.025, 0]} />
          <meshStandardMaterial color="#E8C04A" roughness={0.3} metalness={0.5} />
        </mesh>
        <mesh position={[0, 0.03, -0.04]} rotation={[0.9 + Math.sin(t * 5) * 0.2, 0, 0]}>
          <coneGeometry args={[0.018, 0.1, 4]} />
          <meshStandardMaterial color="#C8463A" roughness={0.9} flatShading />
        </mesh>
      </group>

      {/* floor lamp */}
      <Box p={[1.45, 0.02, -1.15]} s={[0.3, 0.04, 0.3]} c="#2E2A28" />
      <mesh position={[1.45, 0.78, -1.15]}>
        <cylinderGeometry args={[0.015, 0.015, 1.5, 6]} />
        <meshStandardMaterial color="#2E2A28" metalness={0.4} roughness={0.4} />
      </mesh>
      <mesh position={[1.45, 1.6, -1.15]}>
        <cylinderGeometry args={[0.16, 0.24, 0.3, 12, 1, true]} />
        <meshBasicMaterial color={new THREE.Color(l.lamp > 0 ? "#F2D27A" : "#E8DCC8").multiplyScalar(l.lamp > 0 ? 1.6 + Math.sin(t * 7.3) * 0.02 : 0.7)} toneMapped={false} side={THREE.DoubleSide} />
      </mesh>
      {l.lamp > 0 && <pointLight position={[1.45, 1.5, -1.15]} color="#FFC478" intensity={2.6 * l.lamp} distance={7} decay={1.6} />}

      {/* counter + step stool */}
      <Box p={[-2.6, 0.45, -0.3]} s={[0.7, 0.9, 2.4]} c="#8A5A35" />
      <Box p={[-2.6, 0.92, -0.3]} s={[0.78, 0.05, 2.5]} c="#E8DCC8" r={0.35} />
      {[-1.1, -0.3, 0.5].map((z, i) => (
        <Box key={i} p={[-2.24, 0.45, z]} s={[0.02, 0.8, 0.02]} c="#5A3A22" shadow={false} />
      ))}
      <Box p={[-2.0, 0.22, 0.6]} s={[0.35, 0.44, 0.3]} c="#7A6A5A" />

      {/* cat tree */}
      <Box p={[2.35, 0.7, -2.05]} s={[0.1, 1.4, 0.1]} c="#B8A27E" />
      <Box p={[2.35, 0.03, -2.05]} s={[0.6, 0.06, 0.6]} c="#8A6A4A" />
      <Box p={[2.35, 0.75, -2.05]} s={[0.5, 0.05, 0.5]} c="#8A6A4A" />
      <Box p={[2.35, 1.42, -2.05]} s={[0.55, 0.05, 0.55]} c="#8A6A4A" />

      {/* stairs on the right wall + landing, pet ramp at the bottom */}
      {Array.from({ length: 6 }, (_, i) => (
        <Box key={i} p={[2.65, 0.09 * (i + 1), 1.9 - i * 0.28]} s={[0.6, 0.18 * (i + 1), 0.28]} c={i % 2 ? "#A8835E" : "#B08A64"} map={floor} />
      ))}
      <Box p={[2.65, 0.54, -0.05]} s={[0.6, 1.08, 0.9]} c="#A8835E" />
      <Box p={[2.65, 1.09, -0.05]} s={[0.62, 0.02, 0.92]} c="#C9B79A" />
      {rampOpacity > 0 && (
        <Box p={[2.65, 0.1, 2.25]} s={[0.4, 0.03, 0.55]} rot={[0.4, 0, 0]} c="#7A6A5A" opacity={rampOpacity} shadow={rampOpacity > 0.9} />
      )}

      {/* desk + chair (act 1-2) */}
      {desk && (
        <>
          <Box p={[-1.75, 0.725, -2.05]} s={[1.0, 0.04, 0.55]} c="#C9A27A" r={0.5} />
          {[[-2.2, -2.27], [-1.3, -2.27], [-2.2, -1.83], [-1.3, -1.83]].map(([x, z], i) => (
            <Box key={i} p={[x, 0.36, z]} s={[0.04, 0.72, 0.04]} c="#5A3A22" />
          ))}
          <Box p={[-1.75, 0.79, -2.22]} s={[0.42, 0.26, 0.02]} rot={[-0.15, 0, 0]} c="#2E2A28" r={0.3} />
          <mesh position={[-1.75, 0.79, -2.205]} rotation={[-0.15, 0, 0]}>
            <planeGeometry args={[0.38, 0.22]} />
            <meshBasicMaterial color={new THREE.Color("#CFE0F0").multiplyScalar(1.1)} toneMapped={false} />
          </mesh>
          <Box p={[-1.75, 0.43, -1.5]} s={[0.44, 0.05, 0.44]} c="#5A3A22" />
          <Box p={[-1.75, 0.2, -1.5]} s={[0.05, 0.4, 0.05]} c="#2E2A28" />
        </>
      )}

      {/* crib + mobile (act 3) */}
      {crib && (
        <group position={[-1.7, 0, -1.9]}>
          <Box p={[0, 0.42, 0]} s={[0.62, 0.06, 1.15]} c="#F4EEE4" />
          {[-0.31, 0.31].map((x) => (
            <Box key={x} p={[x, 0.88, 0]} s={[0.04, 0.04, 1.15]} c="#F4EEE4" />
          ))}
          {[-0.57, 0.57].map((z) => (
            <Box key={z} p={[0, 0.88, z]} s={[0.62, 0.04, 0.04]} c="#F4EEE4" />
          ))}
          {[[-0.31, -0.57], [0.31, -0.57], [-0.31, 0.57], [0.31, 0.57]].map(([x, z], i) => (
            <Box key={i} p={[x, 0.45, z]} s={[0.05, 0.9, 0.05]} c="#F4EEE4" />
          ))}
          {Array.from({ length: 9 }, (_, i) => (
            <Box key={i} p={[-0.31, 0.65, -0.48 + i * 0.12]} s={[0.02, 0.42, 0.02]} c="#F4EEE4" shadow={false} />
          ))}
          <Box p={[0, 0.47, 0]} s={[0.56, 0.05, 1.08]} c="#EDE6DA" map={sofaFab} />
          <group position={[0, 1.3, 0.25]} rotation={[0, t >= 34.3 ? (t - 34.3) * 0.8 : 0, 0]}>
            <Box p={[0, 0, 0]} s={[0.4, 0.01, 0.01]} c="#8A6A4A" shadow={false} />
            {[["#E07070", 0.2], ["#6F9BD8", -0.2]].map(([c, x], i) => (
              <mesh key={i} position={[x as number, -0.12, 0]}>
                <icosahedronGeometry args={[0.035, 0]} />
                <meshStandardMaterial color={c as string} roughness={0.7} flatShading />
              </mesh>
            ))}
          </group>
        </group>
      )}

      {/* toddler toys + cardboard box (act 3 from beat 10/11) */}
      {b >= 10 && b <= 13 && (
        <>
          <Box p={[-0.2, 0.04, 0.95]} s={[0.08, 0.08, 0.08]} c="#E07070" />
          <Box p={[-0.1, 0.04, 1.05]} s={[0.08, 0.08, 0.08]} c="#6F9BD8" rot={[0, 0.5, 0]} />
          <Box p={[0.95, 0.04, 0.85]} s={[0.08, 0.08, 0.08]} c="#7FBF7A" rot={[0, 0.3, 0]} />
        </>
      )}
      {(b === 11 || b === 12) && (
        <group position={[0.55, 0, 0.55]}>
          <Box p={[0, 0.005, 0]} s={[0.46, 0.01, 0.34]} c="#B08A5E" />
          <Box p={[0, 0.09, 0.17]} s={[0.46, 0.18, 0.01]} c="#C49A68" />
          <Box p={[0, 0.09, -0.17]} s={[0.46, 0.18, 0.01]} c="#C49A68" />
          <Box p={[0.23, 0.09, 0]} s={[0.01, 0.18, 0.34]} c="#B8905E" />
          <Box p={[-0.23, 0.09, 0]} s={[0.01, 0.18, 0.34]} c="#B8905E" />
        </group>
      )}
      {b === 11 && (
        // warm sun patch sliding across the box (time-lapse)
        <mesh position={[lerp(0.35, 0.75, ramp(t, 42, 46)), 0.2, 0.55]} rotation={[-Math.PI / 2, 0, 0.3]}>
          <planeGeometry args={[0.9, 0.6]} />
          <meshBasicMaterial color="#FFE0A0" transparent opacity={0.22} blending={THREE.AdditiveBlending} depthWrite={false} toneMapped={false} />
        </mesh>
      )}

      {/* calendar + photo frames (fill up as the years pass) */}
      <mesh position={[-1.8, 1.6, -2.495]}>
        <planeGeometry args={[0.32, 0.4]} />
        <meshStandardMaterial map={calendarTex(yearAt(t))} roughness={0.8} />
      </mesh>
      {Array.from({ length: 6 }, (_, i) => {
        const x = 1.55 + (i % 3) * 0.32;
        const y = 1.85 - Math.floor(i / 3) * 0.36;
        const fill = ["#C98A5A", "#7FBF7A", "#6F9BD8", "#E8C04A", "#E07070", "#A58BE0"][i];
        return (
          <group key={i} position={[x, y, -2.49]}>
            <Box p={[0, 0, 0]} s={[0.26, 0.3, 0.02]} c="#2E2A28" shadow={false} />
            <mesh position={[0, 0, 0.012]}>
              <planeGeometry args={[0.2, 0.24]} />
              <meshStandardMaterial color={i < photos ? fill : "#EDE6DA"} roughness={0.5} />
            </mesh>
          </group>
        );
      })}

      <Characters t={t} />

      {/* dust motes in the light */}
      <Points n={220} seed="dust" size={0.012} color="#FFE2B0" opacity={l.rain ? 0.25 : 0.7} additive at={(i, r) => {
        const sp = 0.02 + r("s") * 0.03;
        return [-1.0 + r("x") * 2.2 + Math.sin(t * 0.3 + i) * 0.05, 0.2 + ((r("y") * 2.0 + t * sp) % 2.0), -2.3 + r("z") * 2.6 + Math.cos(t * 0.25 + i * 1.7) * 0.05];
      }} />
    </group>
  );
};

// ---------- beat 15: the day we met (shelter memory set) ----------
const signTex = () =>
  textTex("sign-free-kitten", 256, 128, (g) => {
    g.fillStyle = "#F4EEE4";
    g.fillRect(0, 0, 256, 128);
    g.fillStyle = "#2E2A28";
    g.font = "bold 40px sans-serif";
    g.textAlign = "center";
    g.fillText("FREE", 128, 52);
    g.fillText("KITTEN", 128, 100);
  });

const concrete = () =>
  textTex("concrete", 256, 256, (g) => {
    g.fillStyle = "#EDEDED";
    g.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 2500; i++) {
      const v = 190 + Math.floor(random(`cc${i}`) * 50);
      g.fillStyle = `rgba(${v},${v},${v},0.6)`;
      g.fillRect(random(`cx${i}`) * 256, random(`cy${i}`) * 256, 2, 2);
    }
  });

export const Shelter: React.FC<{ t: number }> = ({ t }) => {
  const floorTex = useMemo(() => {
    const tx = concrete();
    tx.wrapS = tx.wrapT = THREE.RepeatWrapping;
    tx.repeat.set(3, 3);
    return tx;
  }, []);
  // young hands reach in at +0.4 s and lift her at +1.6 s
  const reach = ramp(t, 58.4, 59.3);
  const lift = ramp(t, 59.6, 61.2);
  const handY = lerp(0.6, 0.16, reach) + lift * 0.42;
  const handZ = lerp(0.45, 0.02, reach) + lift * 0.14;
  const kitten: V3 = [0, 0.05 + lift * 0.43, 0.0 + lift * 0.14];
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[6, 6]} />
        <meshStandardMaterial color="#8A8580" roughness={0.9} map={floorTex} />
      </mesh>
      <Box p={[0, 1.5, -1.6]} s={[6, 3, 0.1]} c="#6A5A50" map={plaster([4, 2])} />
      {/* cardboard box with blanket */}
      <group>
        <Box p={[0, 0.005, 0]} s={[0.42, 0.01, 0.32]} c="#B08A5E" />
        <Box p={[0, 0.13, 0.16]} s={[0.42, 0.26, 0.01]} c="#C49A68" />
        <Box p={[0, 0.13, -0.16]} s={[0.42, 0.26, 0.01]} c="#C49A68" />
        <Box p={[0.21, 0.13, 0]} s={[0.01, 0.26, 0.32]} c="#B8905E" />
        <Box p={[-0.21, 0.13, 0]} s={[0.01, 0.26, 0.32]} c="#B8905E" />
        <Box p={[0, 0.28, -0.24]} s={[0.42, 0.01, 0.16]} rot={[-0.7, 0, 0]} c="#C49A68" />
        <Box p={[0, 0.03, 0]} s={[0.38, 0.04, 0.28]} c="#A33A2E" map={weave([2, 2])} />
        <mesh position={[0, 0.12, 0.175]} rotation={[-0.15, 0, 0]}>
          <planeGeometry args={[0.24, 0.12]} />
          <meshStandardMaterial map={signTex()} roughness={0.8} />
        </mesh>
      </group>
      <Cat position={kitten} yaw={0.6} t={t} pose="curl" lift={lift} grey={0} glow={0} scale={0.27} />
      {reach > 0 && (
        <>
          {[-1, 1].map((s) => {
            const hand: V3 = [s * 0.075, handY, handZ];
            const from: V3 = [s * 0.25, handY + 0.55, handZ + 0.75];
            return (
              <group key={s}>
                <mesh position={mixV(from, hand, 0.5)} quaternion={new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(...hand).sub(new THREE.Vector3(...from)).normalize())} castShadow>
                  <capsuleGeometry args={[0.05, new THREE.Vector3(...hand).distanceTo(new THREE.Vector3(...from)) - 0.1, 3, 8]} />
                  <meshStandardMaterial color={YOU.top} roughness={0.85} flatShading map={weave([3, 3])} />
                </mesh>
                <mesh position={hand} scale={[1.1, 0.6, 1.3]} castShadow>
                  <sphereGeometry args={[0.05, 8, 6]} />
                  <meshStandardMaterial color={YOU.skin} roughness={0.8} flatShading />
                </mesh>
              </group>
            );
          })}
        </>
      )}
      {/* one warm overhead bulb */}
      <mesh position={[0, 2.0, -0.2]}>
        <sphereGeometry args={[0.06, 12, 8]} />
        <meshBasicMaterial color={new THREE.Color("#FFD890").multiplyScalar(3)} toneMapped={false} />
      </mesh>
      <pointLight position={[0, 1.9, -0.2]} color="#FFC478" intensity={6} distance={6} decay={1.6} castShadow />
    </group>
  );
};
