import * as THREE from "three";
import React, { useMemo } from "react";
import { furTex } from "../textures";
import { lerp } from "../../lib/time";

// Faceless low-poly cat: blank head with ears only (no eyes/nose/mouth).
type V3 = [number, number, number];

export type CatProps = {
  position: V3;
  yaw: number;
  t: number;
  // 0 = curled asleep, 1 = sitting up
  sit: number;
  // head lift 0..1 and stretch 0..1 while curled
  lift: number;
  stretch: number;
  grey: number; // 0..1 amount of grey patches
  glow: number; // 0..1 trigger rim glow
  scale?: number;
};

const BLACK = "#1E1C1E";

export const Cat: React.FC<CatProps> = ({ position, yaw, t, sit, lift, stretch, grey, glow, scale = 1 }) => {
  const fur = useMemo(() => furTex(), []);
  const breath = 1 + Math.sin(t * Math.PI * 2 * 0.25) * 0.025 * (1 - sit);
  const mat = (
    <meshStandardMaterial
      color={BLACK}
      roughness={0.75}
      flatShading
      map={fur}
      emissive="#F2B060"
      emissiveIntensity={glow * 0.1}
    />
  );
  const greyMat = (
    <meshStandardMaterial color="#9C9A98" roughness={0.85} flatShading map={fur} transparent opacity={grey} depthWrite={false} />
  );

  // body pose: curled (long, low, rotated) → sitting (upright)
  const bodyPitch = lerp(0, -1.0, sit);
  const bodyPos: V3 = [0, lerp(0.09, 0.15, sit), lerp(0, -0.03, sit)];
  const bodyScale: V3 = [lerp(1.0, 0.85, sit), lerp(0.62, 0.9, sit) * breath, lerp(1.35 + stretch * 0.25, 1.15, sit)];
  // head: curled rests low at front-left; sitting on top front
  const headPos: V3 = [
    lerp(-0.07, 0, sit),
    lerp(0.08 + lift * 0.1, 0.36, sit),
    lerp(0.17 + stretch * 0.05, 0.08, sit),
  ];
  const headPitch = lerp(0.35 - lift * 0.5, -0.1, sit);
  const headYaw = lerp(-0.6 + lift * 0.4, 0.15 + Math.sin(t * 0.6) * 0.08, sit);

  const tail = useMemo(() => Array.from({ length: 14 }, (_, i) => i), []);

  return (
    <group position={position} rotation={[0, yaw, 0]} scale={scale}>
      {/* body */}
      <mesh position={bodyPos} rotation={[bodyPitch, 0, 0]} scale={bodyScale} castShadow receiveShadow>
        <icosahedronGeometry args={[0.13, 1]} />
        {mat}
      </mesh>
      {/* grey patches (fade out as she grows younger) */}
      {grey > 0.01 &&
        ([
          [0.05, 0.06, 0.08],
          [-0.05, 0.065, -0.05],
        ] as V3[]).map((p, i) => (
          <mesh key={i} position={[bodyPos[0] + p[0], bodyPos[1] + p[1] * lerp(1, 1.6, sit), bodyPos[2] + p[2] * lerp(1, 0.5, sit)]} scale={[0.55, 0.18, 0.7]}>
            <icosahedronGeometry args={[0.07, 1]} />
            {greyMat}
          </mesh>
        ))}
      {/* head (blank) + ears */}
      <group position={headPos} rotation={[headPitch, headYaw, 0]}>
        <mesh castShadow scale={[1, 0.88, 0.95]}>
          <icosahedronGeometry args={[0.075, 1]} />
          {mat}
        </mesh>
        {grey > 0.01 && (
          <mesh position={[0.02, 0.035, 0.035]} scale={[0.5, 0.3, 0.45]}>
            <icosahedronGeometry args={[0.07, 1]} />
            {greyMat}
          </mesh>
        )}
        {[-1, 1].map((s) => (
          <mesh key={s} position={[s * 0.042, 0.068, -0.005]} rotation={[0, 0, -s * 0.28]} castShadow>
            <coneGeometry args={[0.028, 0.055, 4]} />
            {mat}
          </mesh>
        ))}
      </group>
      {/* front legs (visible when sitting, tucked when curled) */}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 0.04, lerp(0.03, 0.08, sit), lerp(0.14 + stretch * 0.12, 0.06, sit)]} rotation={[lerp(Math.PI / 2, 0.05, sit), 0, 0]} castShadow>
          <capsuleGeometry args={[0.022, lerp(0.06, 0.1, sit), 3, 6]} />
          {mat}
        </mesh>
      ))}
      {/* tail: curls around the body */}
      {tail.map((i) => {
        const k = i / (tail.length - 1);
        const ang = lerp(Math.PI * 1.05, Math.PI * 2.1, k) + Math.sin(t * 1.3 + k * 2) * 0.05;
        const rad = lerp(0.15, 0.17, sit);
        return (
          <mesh key={i} position={[Math.cos(ang) * rad, 0.03 + (1 - k) * 0.02, Math.sin(ang) * rad * 1.1]} castShadow>
            <icosahedronGeometry args={[lerp(0.034, 0.022, k), 1]} />
            {mat}
          </mesh>
        );
      })}
    </group>
  );
};

export const _unused = THREE;
