import * as THREE from "three";
import { random } from "remotion";

const cache = new Map<string, THREE.Texture>();

const make = (key: string, size: number, draw: (g: CanvasRenderingContext2D, s: number) => void, repeat: [number, number]) => {
  const k = `${key}-${repeat.join("x")}`;
  const hit = cache.get(k);
  if (hit) return hit;
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const g = c.getContext("2d")!;
  draw(g, size);
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeat[0], repeat[1]);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  cache.set(k, tex);
  return tex;
};

// light greyscale patterns, tinted by material colour
export const oakFloor = (rep: [number, number]) =>
  make("oak", 512, (g, s) => {
    g.fillStyle = "#EFEFEF";
    g.fillRect(0, 0, s, s);
    const boards = 6;
    for (let i = 0; i < boards; i++) {
      const y = (i * s) / boards;
      const tone = 228 + Math.floor(random(`ob${i}`) * 22);
      g.fillStyle = `rgb(${tone},${tone},${tone})`;
      g.fillRect(0, y, s, s / boards);
      for (let k = 0; k < 40; k++) {
        const yy = y + random(`og${i}-${k}`) * (s / boards);
        g.strokeStyle = `rgba(150,150,150,${0.05 + random(`oa${i}-${k}`) * 0.08})`;
        g.lineWidth = 1;
        g.beginPath();
        g.moveTo(0, yy);
        g.bezierCurveTo(s * 0.3, yy + 3, s * 0.6, yy - 3, s, yy + 1);
        g.stroke();
      }
      g.fillStyle = "rgba(90,90,90,0.55)";
      g.fillRect(0, y, s, 2);
      const jx = random(`oj${i}`) * s;
      g.fillRect(jx, y, 2, s / boards);
    }
  }, rep);

export const plaster = (rep: [number, number]) =>
  make("plaster", 256, (g, s) => {
    g.fillStyle = "#F2F2F2";
    g.fillRect(0, 0, s, s);
    for (let i = 0; i < 1800; i++) {
      const v = 215 + Math.floor(random(`pl${i}`) * 40);
      g.fillStyle = `rgba(${v},${v},${v},0.5)`;
      g.fillRect(random(`px${i}`) * s, random(`py${i}`) * s, 1.5, 1.5);
    }
  }, rep);

export const weave = (rep: [number, number]) =>
  make("weave", 128, (g, s) => {
    g.fillStyle = "#EDEDED";
    g.fillRect(0, 0, s, s);
    for (let i = 0; i < s; i += 4) {
      g.fillStyle = "rgba(170,170,170,0.25)";
      g.fillRect(i, 0, 1, s);
      g.fillStyle = "rgba(170,170,170,0.18)";
      g.fillRect(0, i, s, 1);
    }
  }, rep);

export const rugTex = () =>
  make("rug", 512, (g, s) => {
    g.fillStyle = "#EEE";
    g.fillRect(0, 0, s, s);
    g.strokeStyle = "rgba(120,120,120,0.55)";
    g.lineWidth = 14;
    g.strokeRect(30, 30, s - 60, s - 60);
    g.lineWidth = 4;
    g.strokeRect(70, 70, s - 140, s - 140);
    for (let i = 0; i < 3000; i++) {
      g.fillStyle = `rgba(150,150,150,${random(`rw${i}`) * 0.2})`;
      g.fillRect(random(`rx${i}`) * s, random(`ry${i}`) * s, 2, 2);
    }
  }, [1, 1]);

export const furTex = () =>
  make("fur", 256, (g, s) => {
    g.fillStyle = "#F0F0F0";
    g.fillRect(0, 0, s, s);
    for (let i = 0; i < 900; i++) {
      const x = random(`fx${i}`) * s;
      const y = random(`fy${i}`) * s;
      const v = 190 + Math.floor(random(`fv${i}`) * 60);
      g.strokeStyle = `rgba(${v},${v},${v},0.55)`;
      g.lineWidth = 1.2;
      g.beginPath();
      g.moveTo(x, y);
      g.lineTo(x + 9, y + 2 + random(`fd${i}`) * 3);
      g.stroke();
    }
  }, [2, 2]);

export const lawn = (rep: [number, number]) =>
  make("lawn", 256, (g, s) => {
    for (let i = 0; i < 8; i++) {
      g.fillStyle = i % 2 ? "#E6E6E6" : "#F5F5F5";
      g.fillRect((i * s) / 8, 0, s / 8, s);
    }
    for (let i = 0; i < 1200; i++) {
      g.fillStyle = "rgba(160,160,160,0.25)";
      g.fillRect(random(`lx${i}`) * s, random(`ly${i}`) * s, 1, 3);
    }
  }, rep);

export const textTex = (key: string, w: number, h: number, draw: (g: CanvasRenderingContext2D) => void) => {
  const hit = cache.get(key);
  if (hit) return hit;
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  draw(c.getContext("2d")!);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  cache.set(key, tex);
  return tex;
};
