// Realistic rigged character (Mixamo skeleton) with deterministic animation.
// Animation is a pure function of time: every frame sets each clip's time + weight, then evaluates once.
import * as THREE from "three";
import React, { useLayoutEffect, useMemo } from "react";
import { clone as cloneSkinned } from "three/examples/jsm/utils/SkeletonUtils.js";
import { useGLTF } from "./assets";
import { registerFace, unregisterFace } from "./faces";

export const MODELS = {
  xbot: "assets/chars/Xbot.glb", // smooth mannequin: idle, walk, run, agree, headShake, sad_pose, sneak_pose
  soldier: "assets/chars/Soldier.glb", // realistic man: Idle, Walk, Run
  michelle: "assets/chars/Michelle.glb", // realistic woman: SambaDance (use xbot clips for walking)
} as const;
export type ModelName = keyof typeof MODELS;
const YAW_OFFSET: Partial<Record<ModelName, number>> = { soldier: Math.PI };

// clip library: any Mixamo clip retargets by bone name, so xbot's clips drive every model
const CLIP_SOURCE: Record<string, ModelName> = {
  idle: "xbot", walk: "xbot", run: "xbot", agree: "xbot", headShake: "xbot", sad_pose: "xbot", sneak_pose: "xbot",
};

export type ClipState = { clip: string; time: number; weight?: number; speed?: number };

export type CharacterProps = {
  id: string;
  model: ModelName;
  position: [number, number, number];
  yaw: number;
  clips: ClipState[]; // blended by weight (sum ≈ 1)
  tint?: string; // body colour (mannequin only)
  jointTint?: string;
  scale?: number;
  inPlace?: boolean; // strip root motion so `position` alone moves the character
  blurFace?: boolean;
};

const stripRootMotion = (clip: THREE.AnimationClip) => {
  const c = clip.clone();
  for (const tr of c.tracks) {
    if (!tr.name.endsWith("Hips.position")) continue;
    // keep the vertical bob, drop horizontal travel
    const v = tr.values;
    for (let i = 0; i < v.length; i += 3) {
      v[i] = v[0];
      v[i + 2] = v[2];
    }
  }
  return c;
};

export const Character: React.FC<CharacterProps> = ({ id, model, position, yaw, clips, tint, jointTint, scale = 1, inPlace = true, blurFace = true }) => {
  const gltf = useGLTF(MODELS[model]);
  const lib = useGLTF(MODELS.xbot);
  const rig = useMemo(() => {
    if (!gltf || !lib) return null;
    const root = cloneSkinned(gltf.scene) as THREE.Object3D;
    root.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) {
        m.castShadow = true;
        m.receiveShadow = true;
        m.frustumCulled = false;
        const mats = Array.isArray(m.material) ? m.material : [m.material];
        m.material = mats.map((mat) => {
          const c = (mat as THREE.MeshStandardMaterial).clone();
          if (model === "xbot") {
            const isJoint = /joint/i.test(mat.name);
            c.color = new THREE.Color(isJoint ? jointTint ?? "#3A3A40" : tint ?? "#C8C2BA");
            c.roughness = isJoint ? 0.35 : 0.55;
            c.metalness = isJoint ? 0.3 : 0.0;
          }
          return c;
        }) as unknown as THREE.Material;
        if (Array.isArray(m.material) && m.material.length === 1) m.material = m.material[0];
      }
    });
    const mixer = new THREE.AnimationMixer(root);
    const all = [...gltf.animations, ...(model === "xbot" ? [] : lib.animations)];
    const actions = new Map<string, THREE.AnimationAction>();
    for (const clip of all) {
      const name = clip.name;
      if (actions.has(name)) continue;
      const src = CLIP_SOURCE[name] === "xbot" && model !== "xbot" ? lib.animations.find((a) => a.name === name) ?? clip : clip;
      const a = mixer.clipAction(inPlace ? stripRootMotion(src) : src);
      a.play();
      a.setEffectiveWeight(0);
      actions.set(name, a);
    }
    let head: THREE.Object3D | undefined;
    let top: THREE.Object3D | undefined;
    root.traverse((o) => {
      if (/mixamorig:?Head$/.test(o.name)) head = o;
      if (/HeadTop_End$/.test(o.name)) top = o;
    });
    return { root, mixer, actions, head, top };
  }, [gltf, lib, model, tint, jointTint, inPlace]);

  useLayoutEffect(() => {
    if (!rig?.head || !blurFace) return;
    registerFace(id, { head: rig.head, top: rig.top, radius: 0.13 * scale });
    return () => {
      unregisterFace(id);
    };
  }, [rig, id, blurFace, scale]);

  useLayoutEffect(() => {
    if (!rig) return;
    for (const a of rig.actions.values()) a.setEffectiveWeight(0);
    for (const c of clips) {
      const a = rig.actions.get(c.clip);
      if (!a) continue;
      const d = a.getClip().duration;
      a.time = (((c.time * (c.speed ?? 1)) % d) + d) % d;
      a.setEffectiveWeight(c.weight ?? 1);
    }
    rig.mixer.update(0);
    rig.root.updateMatrixWorld(true);
  });

  if (!rig) return null;
  return (
    <group position={position} rotation={[0, yaw + (YAW_OFFSET[model] ?? 0), 0]} scale={scale}>
      <primitive object={rig.root} />
    </group>
  );
};

// helper: crossfade from clip A to clip B between t0 and t1
export const blend = (t: number, a: string, b: string, t0: number, t1: number, ta = t, tb = t): ClipState[] => {
  const k = Math.min(1, Math.max(0, (t - t0) / (t1 - t0)));
  return [
    { clip: a, time: ta, weight: 1 - k },
    { clip: b, time: tb, weight: k },
  ];
};
