// "What if everyone shared one mind except you?" — story state as pure functions of t.
import { random } from "remotion";
import { clamp, lerp, ramp } from "./lib/time";

export type V3 = [number, number, number];

export const beatIndex = (t: number) => {
  const starts = [0, 6, 10, 14, 18, 22, 26, 30, 34, 38, 42, 46, 50, 54, 58, 62];
  let i = 0;
  while (i < starts.length - 1 && t >= starts[i + 1]) i++;
  return i + 1;
};

// key moments
export const FREEZE = 5.6; // everyone stops
export const SYNC = 6.4; // they walk again, in step
export const TURN = 46.3; // they turn toward you
export const WINDOWS_ON = 54.2;
export const STAND = 62.6; // you stand and step back

export type Sky = "morning" | "noon" | "golden" | "dusk" | "night";
export type Light = {
  sky: Sky; keyColor: string; keyIntensity: number; keyPos: V3;
  hemiSky: string; hemiGround: string; hemi: number;
  fog: string; fogNear: number; fogFar: number;
  bloom: number; sat: number; contrast: number; night: number; // 0..1 window/lamp emissive
};

export const lightAt = (t: number): Light => {
  const b = beatIndex(t);
  if (b <= 2)
    return { sky: "morning", keyColor: "#FFE2B0", keyIntensity: 2.6, keyPos: [-12, 11, -6], hemiSky: "#CFD8E6", hemiGround: "#6A6460", hemi: 1.0, fog: "#C9D2DC", fogNear: 30, fogFar: 120, bloom: 0.3, sat: 0.06, contrast: 0.06, night: 0 };
  if (b <= 8) {
    // the hive is orderly: colour slowly drains
    const k = clamp((t - 10) / 24);
    return { sky: "noon", keyColor: "#FFF4E0", keyIntensity: 2.6, keyPos: [-9, 13, -7], hemiSky: "#D6E0EA", hemiGround: "#6A6460", hemi: 1.0, fog: "#C9D2DC", fogNear: 30, fogFar: 120, bloom: 0.25, sat: lerp(0, -0.15, k), contrast: 0.04, night: 0 };
  }
  if (b <= 13)
    return { sky: "golden", keyColor: "#F0C78A", keyIntensity: 2.4, keyPos: [-15, 5, -6], hemiSky: "#E0D8E8", hemiGround: "#6A5A50", hemi: 0.95, fog: "#E8D2B8", fogNear: 30, fogFar: 120, bloom: 0.5, sat: 0.04, contrast: 0.06, night: 0 };
  if (b === 14)
    return { sky: "dusk", keyColor: "#C98A8A", keyIntensity: 0.8, keyPos: [-15, 2.5, -6], hemiSky: "#6A5A8A", hemiGround: "#2A2430", hemi: 0.7, fog: "#4A3A6A", fogNear: 25, fogFar: 110, bloom: 0.7, sat: -0.05, contrast: 0.08, night: ramp(t, WINDOWS_ON, WINDOWS_ON + 0.08) };
  return { sky: "night", keyColor: "#8C8FC0", keyIntensity: 0.25, keyPos: [10, 14, 8], hemiSky: "#2A3060", hemiGround: "#141420", hemi: 0.5, fog: "#1C2147", fogNear: 30, fogFar: 140, bloom: 0.75, sat: -0.1, contrast: 0.1, night: 1 };
};

// ---------- YOU ----------
export const YOU_POS: V3 = [-8.0, 0.47, 9.0];
export const YOU_YAW = Math.atan2(8, -9); // facing the fountain
export const DIR: V3 = [Math.sin(YOU_YAW), 0, Math.cos(YOU_YAW)];
export const YOU_LOOK = { hair: "#2A2420", top: "#3E5A3A", pants: "#2E3A4A", skin: "#C99A7A" };

// joined people get a faint violet rim (never you)
export const rimAt = (t: number) => 0.15 * ramp(t, 34.3, 35.3);

const look = (k: string) => {
  const tops = ["#C8463A", "#6F9BD8", "#E8C04A", "#7FBF7A", "#EDE6DA", "#8A5A35", "#5E7C7A", "#A58BE0", "#D8A070", "#4A5A78"];
  const pants = ["#2E3A4A", "#3A3330", "#5A5048", "#1E2430", "#6A6058"];
  const hair = ["#2A2420", "#5A3A28", "#8A6A48", "#1A1A1A", "#A8A8A8", "#C49A68"];
  const skin = ["#C99A7A", "#8A5A3A", "#E8C0A0", "#6A4028", "#D8AA88"];
  const pick = (a: string[], s: string) => a[Math.floor(random(k + s) * a.length)];
  return { hair: pick(hair, "h"), top: pick(tops, "t"), pants: pick(pants, "p"), skin: pick(skin, "s"), dress: random(k + "d") < 0.15 };
};

// ---------- crowd: walkers on rings around the fountain ----------
export const N_WALKERS = 80;
export type Walker = { pos: V3; yaw: number; walk?: number; stride: number; look: ReturnType<typeof look>; scale: number };

const STEP_HZ = 1.8;

export const walkerAt = (i: number, t: number): Walker => {
  const r = (k: string) => random(`w${i}${k}`);
  const r0 = 5.2 + r("r") * 3.8;
  const lane = 5.5 + (i % 5) * 0.85;
  const th0 = r("a") * Math.PI * 2;
  const dir = r("d") < 0.5 ? -1 : 1;
  const speed = 1.0 + r("v") * 0.5;
  const ph0 = r("p") * Math.PI * 2;
  const L = look(`w${i}`);
  const scale = 0.9 + r("s") * 0.12;

  // angular position θ(t), radius and walk phase for each regime
  const thFree = (tt: number) => th0 + (dir * speed * tt) / r0;
  const thAtFreeze = thFree(FREEZE);
  const syncSpeed = 1.25;
  const thSync = (tt: number) => thAtFreeze + (syncSpeed * (tt - SYNC)) / lane;
  let th: number, rad: number, walk: number | undefined, stride = 1, heading: number;
  if (t < FREEZE) {
    th = thFree(t); rad = r0; walk = ph0 + 2 * Math.PI * STEP_HZ * (speed / 1.25) * t; heading = dir;
  } else if (t < SYNC) {
    th = thAtFreeze; rad = r0; walk = ph0 + 2 * Math.PI * STEP_HZ * (speed / 1.25) * FREEZE; heading = dir;
  } else {
    const tt = Math.min(t, TURN);
    th = thSync(tt);
    rad = lerp(r0, lane, ramp(t, SYNC, SYNC + 2.5));
    walk = 2 * Math.PI * STEP_HZ * (tt - SYNC); // ONE shared phase
    heading = 1;
    if (t >= TURN) stride = 1 - ramp(t, TURN, TURN + 0.4);
  }
  const pos: V3 = [Math.cos(th) * rad, 0, Math.sin(th) * rad];
  // tangent heading for counter-clockwise (+1) or clockwise (-1) motion
  const tangent = Math.atan2(-Math.sin(th) * heading, Math.cos(th) * heading);
  let yaw = tangent;
  if (t >= SYNC && t < SYNC + 0.5 && dir < 0) yaw = lerp(Math.atan2(Math.sin(th), -Math.cos(th)), tangent, ramp(t, SYNC, SYNC + 0.5));
  if (t >= TURN) {
    const face = Math.atan2(YOU_POS[0] - pos[0], YOU_POS[2] - pos[2]);
    let d = face - tangent;
    d = Math.atan2(Math.sin(d), Math.cos(d));
    yaw = tangent + d * ramp(t, TURN, TURN + 0.8);
  }
  return { pos, yaw, walk, stride, look: L, scale };
};

// people crossing the road (ping-pong across z 11..16.5)
export const N_CROSSERS = 10;
export const crosserAt = (i: number, t: number): Walker => {
  const r = (k: string) => random(`c${i}${k}`);
  const x = -9 + i * 2.0 + r("x") * 0.8;
  const off = r("o") * 11;
  const tEff = t < FREEZE ? t : t < SYNC ? FREEZE : FREEZE + (Math.min(t, TURN) - SYNC);
  const u = (tEff * 1.2 + off) % 11; // 0..11
  const z = 11 + (u < 5.5 ? u : 11 - u);
  const yaw0 = u < 5.5 ? 0 : Math.PI;
  const walk = t < FREEZE ? 2 * Math.PI * STEP_HZ * t + r("p") * 6 : t < SYNC ? 2 * Math.PI * STEP_HZ * FREEZE + r("p") * 6 : 2 * Math.PI * STEP_HZ * (Math.min(t, TURN) - SYNC);
  const pos: V3 = [x, 0, z];
  let yaw = yaw0;
  let stride = 1;
  if (t >= TURN) {
    const face = Math.atan2(YOU_POS[0] - pos[0], YOU_POS[2] - pos[2]);
    let d = face - yaw0;
    d = Math.atan2(Math.sin(d), Math.cos(d));
    yaw = yaw0 + d * ramp(t, TURN, TURN + 0.8);
    stride = 1 - ramp(t, TURN, TURN + 0.4);
  }
  return { pos, yaw, walk, stride, look: look(`c${i}`), scale: 0.92 + r("s") * 0.1 };
};

// ---------- café ----------
export const TABLES: V3[] = [[-10.6, 0, 8.6], [-11.2, 0, 11.0], [-9.6, 0, 12.4], [-6.4, 0, 11.8], [-7.6, 0, 8.55]]; // last = yours
export type Guest = { table: number; ang: number; laptop?: boolean };
export const GUESTS: Guest[] = [
  { table: 0, ang: 2.6 }, { table: 0, ang: 0.4, laptop: true }, { table: 0, ang: -1.4, laptop: true },
  { table: 1, ang: 0.6 }, { table: 1, ang: 3.4 },
  { table: 2, ang: 1.2 }, { table: 2, ang: -1.9 },
  { table: 3, ang: 0.2 }, { table: 3, ang: 2.9 },
];
export const guestLook = (i: number) => look(`g${i}`);

// sip arc during beat 3 (0 = cup on table, 1 = at mouth); before the freeze guests sip on their own
export const sipAt = (i: number, t: number) => {
  if (t >= 10 && t < 14) return ramp(t, 10.3, 10.9) * (1 - ramp(t, 11.8, 12.2));
  if (t < FREEZE) {
    const p = (t * 0.25 + random(`gs${i}`)) % 1;
    return p < 0.15 ? Math.sin((p / 0.15) * Math.PI) : 0;
  }
  return 0;
};

// cars on the road (stop at the freeze and when they turn to you)
export const N_CARS = 6;
export const carAt = (i: number, t: number) => {
  const lane = i % 2 ? 13.6 : 12.4;
  const dir = i % 2 ? -1 : 1;
  const v = 6;
  const brake = (t0: number, tt: number) => {
    const k = clamp((tt - t0) / 0.4);
    return 0.4 * (k - (k * k) / 2);
  };
  let teff: number;
  if (t < FREEZE) teff = t;
  else if (t < SYNC) teff = FREEZE + brake(FREEZE, t);
  else if (t < TURN) teff = FREEZE + 0.2 + (t - SYNC);
  else teff = FREEZE + 0.2 + (TURN - SYNC) + brake(TURN, t);
  const span = 44;
  const x = ((((random(`car${i}`) * span + v * teff) % span) + span) % span) - span / 2;
  return { pos: [dir * x, 0, lane] as V3, yaw: dir > 0 ? Math.PI / 2 : -Math.PI / 2, color: ["#C8463A", "#6F9BD8", "#EDE6DA", "#2E3A4A", "#E8C04A", "#5E7C7A"][i] };
};

export const clockText = (t: number) => (t < FREEZE ? "9:13" : "9:14");
export const billboardText = (t: number) => (t < 14.3 ? "GOOD MORNING" : t < 47.3 ? "" : "WE ARE HERE");
