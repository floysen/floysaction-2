import React from "react";
import { AbsoluteFill, Audio, staticFile, useCurrentFrame } from "remotion";
import { ThreeCanvas } from "@remotion/three";
import * as THREE from "three";
import beats from "./beats.json";
import { FPS, ramp } from "./lib/time";
import { beatIndex, lightAt } from "./story";
import { Room, Shelter } from "./scenes/Room";
import { CameraRig, Env, Lights, Post } from "./three/Stage";
import { Callout, Caption, EndCard, Hud, Title, Vignette, WhiteFade } from "./overlay/Overlays";

export const WhatIf: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const { width, height } = beats.meta;
  const l = lightAt(t);
  const memory = beatIndex(t) === 15;
  const [w0, w1] = beats.fades.whiteOut;
  const white = Math.max(l.white, ramp(t, w0, w1));
  return (
    <AbsoluteFill style={{ backgroundColor: "#2A2226" }}>
      {t < beats.endCard.from + 0.6 && (
        <ThreeCanvas
          width={width}
          height={height}
          shadows={{ type: THREE.PCFSoftShadowMap }}
          gl={{ alpha: false, antialias: true, preserveDrawingBuffer: true }}
          camera={{ fov: 42, near: 0.05, far: 60 }}
        >
          <color attach="background" args={[memory ? "#1A1614" : "#2A2226"]} />
          <CameraRig />
          <Env />
          <Lights l={l} />
          {memory ? <Shelter t={t} /> : <Room t={t} l={l} />}
          <Post bloom={l.bloom} sat={l.sat} contrast={l.contrast} />
        </ThreeCanvas>
      )}
      <Vignette />
      <Title t={t} />
      <Hud t={t} />
      <Callout t={t} />
      <Caption t={t} />
      <WhiteFade amount={white} />
      <EndCard t={t} />
      <Audio src={staticFile("audio/mix.wav")} />
    </AbsoluteFill>
  );
};
