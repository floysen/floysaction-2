import * as THREE from "three";
import React, { useEffect, useLayoutEffect, useMemo } from "react";
import { useThree } from "@react-three/fiber";
import { continueRender, delayRender, useCurrentFrame } from "remotion";
import { EffectComposer, N8AO, Bloom, HueSaturation, BrightnessContrast, SMAA, DepthOfField } from "@react-three/postprocessing";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { cameraAt, FPS, PREVIEW } from "../lib/time";
import type { Light } from "../story";

// Camera rig: pure function of the frame.
export const CameraRig: React.FC = () => {
  const frame = useCurrentFrame();
  const { camera } = useThree();
  useLayoutEffect(() => {
    const c = cameraAt(frame / FPS);
    const cam = camera as THREE.PerspectiveCamera;
    cam.position.set(...c.pos);
    cam.fov = c.fov;
    cam.near = 0.05;
    cam.far = 60;
    cam.lookAt(...c.look);
    cam.updateProjectionMatrix();
  }, [frame, camera]);
  return null;
};

// Procedural environment for reflections (the HDRI host is not reachable from this machine).
const envCache = new WeakMap<THREE.WebGLRenderer, THREE.Texture>();
export const Env: React.FC = () => {
  const { gl, scene } = useThree();
  useLayoutEffect(() => {
    let tex = envCache.get(gl);
    if (!tex) {
      const pm = new THREE.PMREMGenerator(gl);
      tex = pm.fromScene(new RoomEnvironment(), 0.04).texture;
      envCache.set(gl, tex);
    }
    scene.environment = tex;
    scene.environmentIntensity = 0.5;
  }, [gl, scene]);
  return null;
};

// Remotion "black frame" fix for EffectComposer.
const Kick: React.FC = () => {
  const { advance } = useThree();
  const frame = useCurrentFrame();
  useEffect(() => {
    const h = delayRender("postfx-kick");
    const id = requestAnimationFrame(() => {
      advance(performance.now());
      continueRender(h);
    });
    return () => cancelAnimationFrame(id);
  }, [advance, frame]);
  return null;
};

export const Post: React.FC<{ bloom: number; sat: number; contrast: number }> = ({ bloom, sat, contrast }) => {
  const frame = useCurrentFrame();
  const c = cameraAt(frame / FPS);
  // focus on the camera's look-at point for close/medium beats
  const target = useMemo(() => new THREE.Vector3(), []);
  target.set(...c.look);
  return (
    <>
      <EffectComposer multisampling={0} enableNormalPass={false} frameBufferType={THREE.HalfFloatType}>
        <N8AO aoRadius={0.6} intensity={1.6} distanceFalloff={0.6} quality={PREVIEW ? "performance" : "high"} halfRes={PREVIEW} />
        <DepthOfField target={target} focalLength={0.02} bokehScale={c.dof ? 2.5 : 0} />
        <Bloom mipmapBlur intensity={bloom} luminanceThreshold={0.82} luminanceSmoothing={0.12} radius={0.75} />
        <HueSaturation saturation={sat} />
        <BrightnessContrast contrast={contrast} />
        <SMAA />
      </EffectComposer>
      <Kick />
    </>
  );
};

export const Lights: React.FC<{ l: Light }> = ({ l }) => {
  const target = useMemo(() => {
    const o = new THREE.Object3D();
    o.position.set(0.3, 0, -0.2);
    return o;
  }, []);
  const size = PREVIEW ? 1024 : 2048;
  return (
    <>
      <hemisphereLight args={[l.hemiSky, l.hemiGround, l.hemi]} />
      <primitive object={target} />
      <directionalLight
        position={l.keyPos}
        color={l.keyColor}
        intensity={l.keyIntensity}
        target={target}
        castShadow
        shadow-mapSize={[size, size]}
        shadow-camera-left={-4}
        shadow-camera-right={4}
        shadow-camera-top={4}
        shadow-camera-bottom={-4}
        shadow-camera-near={1}
        shadow-camera-far={25}
        shadow-bias={-0.0004}
        shadow-normalBias={0.02}
      />
      <directionalLight position={[3, 2.5, 4]} color="#8C8FC0" intensity={0.3} />
    </>
  );
};
