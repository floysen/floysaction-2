// Real HDR sky: visible background + image-based lighting and reflections from the same photo.
import * as THREE from "three";
import React, { useLayoutEffect } from "react";
import { useThree } from "@react-three/fiber";
import { HDRI, HdriName, useHDR } from "./assets";

export const Sky: React.FC<{ name: HdriName; intensity?: number; blur?: number; rotation?: number; background?: boolean }> = ({
  name, intensity = 1, blur = 0, rotation = 0, background = true,
}) => {
  const tex = useHDR(HDRI[name]);
  const { scene } = useThree();
  useLayoutEffect(() => {
    if (!tex) return;
    scene.environment = tex;
    scene.environmentIntensity = intensity;
    scene.environmentRotation = new THREE.Euler(0, rotation, 0);
    if (background) {
      scene.background = tex;
      scene.backgroundBlurriness = blur;
      scene.backgroundIntensity = intensity;
      scene.backgroundRotation = new THREE.Euler(0, rotation, 0);
    }
  }, [tex, scene, intensity, blur, rotation, background]);
  return null;
};
