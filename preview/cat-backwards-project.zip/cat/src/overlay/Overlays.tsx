import React from "react";
import { AbsoluteFill, continueRender, delayRender, staticFile } from "remotion";
import beats from "../beats.json";
import { beatAt, fade } from "../lib/time";

// Fonts served locally (Google Fonts files fetched once into public/fonts).
const SERIF = "Spectral";
const SANS = "IBM Plex Sans";
const fontHandle = delayRender("fonts");
Promise.all([
  new FontFace(SERIF, `url(${staticFile("fonts/Spectral-normal.woff2")})`, { style: "normal", weight: "400" }),
  new FontFace(SERIF, `url(${staticFile("fonts/Spectral-italic.woff2")})`, { style: "italic", weight: "400" }),
  new FontFace(SANS, `url(${staticFile("fonts/IBMPlexSans-normal.woff2")})`, { style: "normal", weight: "500" }),
].map((f) => f.load().then((ff) => document.fonts.add(ff)))).then(() => continueRender(fontHandle));

const SHADOW = "0 2px 12px rgba(0,0,0,.6), 0 1px 3px rgba(0,0,0,.5)";
const ACCENT = beats.meta.accent;

export const Title: React.FC<{ t: number }> = ({ t }) => {
  const o = fade(t, beats.title.in - 0.3, beats.title.out + 0.3);
  if (o <= 0) return null;
  const [l1, l2] = beats.title.pre.split("\n");
  return (
    <AbsoluteFill style={{ top: "18%", height: "auto", alignItems: "center", opacity: o }}>
      <div style={{ fontFamily: SERIF, fontSize: 68, lineHeight: 1.18, color: "#FFFFFF", textAlign: "center", textShadow: SHADOW, fontWeight: 400 }}>
        {l1}
        <br />
        {l2}
        <span style={{ color: ACCENT }}>{beats.title.key}</span>
        {beats.title.post}
      </div>
    </AbsoluteFill>
  );
};

export const Hud: React.FC<{ t: number }> = ({ t }) => {
  if (t < beats.hud.in || t >= beats.hud.out) return null;
  const o = Math.min(1, (t - beats.hud.in) / 0.3) * Math.min(1, (beats.hud.out - t) / 0.3);
  const b = beatAt(t);
  // stepped value: crossfade old → new over 0.15 s at the cut
  const k = Math.min(1, (t - b.start) / 0.15);
  const word = !/^\d/.test(b.hud);
  return (
    <div style={{ position: "absolute", left: "6%", top: "44%", opacity: o, textShadow: SHADOW, color: "#FFFFFF" }}>
      <div style={{ fontFamily: SANS, fontWeight: 500, fontSize: 21, letterSpacing: "0.2em" }}>{beats.hud.label}</div>
      <div style={{ fontFamily: SERIF, fontSize: word ? 52 : 70, lineHeight: 1.1, opacity: b.start === 0 ? 1 : 0.4 + 0.6 * k, fontVariantNumeric: "tabular-nums", color: word ? ACCENT : "#FFFFFF" }}>
        {b.hud}
      </div>
      <div style={{ fontFamily: SANS, fontWeight: 500, fontSize: 17, letterSpacing: "0.2em", opacity: 0.8 }}>{b.unit}</div>
    </div>
  );
};

export const Caption: React.FC<{ t: number }> = ({ t }) => {
  const b = beatAt(t);
  if (!b.caption) return null;
  const tin = (b as { captionIn?: number }).captionIn ?? b.start;
  const o = fade(t, tin, (b as { captionOut?: number }).captionOut ?? b.end);
  if (o <= 0) return null;
  return (
    <>
      {/* soft local gradient behind the caption band for readability */}
      <div style={{ position: "absolute", left: 0, right: 0, top: "58%", height: "18%", background: "linear-gradient(transparent, rgba(0,0,0,.25), transparent)", opacity: o }} />
      <div
        style={{
          position: "absolute",
          top: "63%",
          left: 0,
          right: 0,
          padding: "0 90px",
          textAlign: "center",
          fontFamily: SERIF,
          fontStyle: "italic",
          fontSize: 50,
          lineHeight: 1.25,
          color: "#FFFFFF",
          textShadow: SHADOW,
          opacity: o,
        }}
      >
        {b.caption}
      </div>
    </>
  );
};

export const Callout: React.FC<{ t: number }> = ({ t }) => {
  const c = beats.callouts.find((x) => t >= x.from && t < x.to);
  if (!c) return null;
  const o = fade(t, c.from, c.to);
  return (
    <div style={{ position: "absolute", top: "26%", left: 0, right: 0, textAlign: "center", opacity: o, textShadow: SHADOW }}>
      <div style={{ fontFamily: SERIF, fontSize: 80, color: ACCENT, lineHeight: 1 }}>{c.value}</div>
      <div style={{ fontFamily: SANS, fontWeight: 500, fontSize: 18, letterSpacing: "0.2em", color: "#FFFFFF", marginTop: 10 }}>{c.text}</div>
    </div>
  );
};

export const EndCard: React.FC<{ t: number }> = ({ t }) => {
  const e = beats.endCard;
  if (t < e.from) return null;
  const o = Math.min(1, (t - e.from) / 0.6);
  const [l1, l2] = beats.title.pre.split("\n");
  return (
    <AbsoluteFill style={{ backgroundColor: "#0D0F10", opacity: o, alignItems: "center", justifyContent: "center", textAlign: "center" }}>
      <div style={{ fontFamily: SERIF, fontSize: 68, lineHeight: 1.18, color: "#EDE6DA", marginTop: -120 }}>
        {l1}
        <br />
        {l2}
        <span style={{ color: ACCENT }}>{beats.title.key}</span>
        {beats.title.post}
      </div>
      <div style={{ fontFamily: SANS, fontWeight: 500, fontSize: 22, letterSpacing: "0.18em", color: "#7A7A7A", lineHeight: 1.7, marginTop: 70, padding: "0 80px" }}>
        {e.fact.map((f) => (
          <div key={f}>{f}</div>
        ))}
      </div>
      <div style={{ fontFamily: SANS, fontWeight: 500, fontSize: 22, letterSpacing: "0.18em", color: "#C9A24A", marginTop: 80 }}>{e.cta}</div>
    </AbsoluteFill>
  );
};

export const WhiteFade: React.FC<{ amount: number }> = ({ amount }) =>
  amount > 0 ? <AbsoluteFill style={{ backgroundColor: "#FFFFFF", opacity: amount }} /> : null;

export const Vignette: React.FC = () => (
  <AbsoluteFill style={{ background: "radial-gradient(ellipse at 50% 45%, transparent 55%, rgba(0,0,0,.42) 100%)" }} />
);
