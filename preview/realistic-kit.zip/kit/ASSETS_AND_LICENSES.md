# Realistic kit — assets and licences

| Asset | Files | Source | Licence / credit |
|---|---|---|---|
| HDR skies (8): sunrise ×2, city overpass, plaza, bridge, quarry, sunset, night | `public/assets/hdri/*.hdr` | Poly Haven, via the three.js repository (r170) | **CC0**, no credit needed |
| X Bot mannequin (idle, walk, run, agree, headShake, sad_pose, sneak_pose) | `public/assets/chars/Xbot.glb` | Adobe Mixamo, via three.js examples | Mixamo licence: free for personal and commercial projects, including videos |
| Soldier (Idle, Walk, Run) | `public/assets/chars/Soldier.glb` | Adobe Mixamo, via three.js examples | Mixamo licence (as above) |
| Michelle (SambaDance) | `public/assets/chars/Michelle.glb` | Adobe Mixamo, via three.js examples | Mixamo licence (as above). Her rest pose differs from X Bot's, so don't drive her with X Bot clips |
| Birds: Stork, Parrot, Flamingo (flapping) | `public/assets/birds/*.glb` | three.js examples (originally from "ROME" by ro.me) | distributed with three.js (MIT) |
| Water normal maps | `public/assets/tex/*.jpg` | three.js examples | MIT (three.js) |
| Trees (Oak, Ash, Aspen, Pine, Bush; bark and leaf textures built in) | npm `@dgreenheck/ez-tree@1.1.0` | Daniel Greenheck | **MIT** |
| Paving, asphalt, brick, plaster, concrete, wood, grass (colour + normal + roughness) | generated in code (`src/kit/Surfaces.tsx`) | this project | ours |

Nothing in the kit needs a credit line in the video description.
