import * as THREE from "three";
import React, { useMemo } from "react";
import { weave } from "../textures";

// Procedural faceless human, ~1.75 m. Head is a blank low-poly sphere: no face geometry or texture, ever.
type V3 = [number, number, number];

const Limb: React.FC<{ from: V3; to: V3; r: number; color: string; map?: THREE.Texture }> = ({ from, to, r, color, map }) => {
  const a = new THREE.Vector3(...from);
  const b = new THREE.Vector3(...to);
  const dir = b.clone().sub(a);
  const len = dir.length();
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
  const mid = a.clone().add(b).multiplyScalar(0.5);
  return (
    <mesh position={mid} quaternion={q} castShadow receiveShadow>
      <capsuleGeometry args={[r, Math.max(0.001, len - 2 * r), 3, 8]} />
      <meshStandardMaterial color={color} roughness={0.85} flatShading map={map} />
    </mesh>
  );
};

const Hand: React.FC<{ p: V3; skin: string }> = ({ p, skin }) => (
  <mesh position={p} scale={[1.1, 0.6, 1.3]} castShadow>
    <sphereGeometry args={[0.05, 8, 6]} />
    <meshStandardMaterial color={skin} roughness={0.8} flatShading />
  </mesh>
);

// two-segment arm with the elbow pushed outward/down
const Arm: React.FC<{ shoulder: V3; hand: V3; side: number; color: string; skin: string; map: THREE.Texture }> = ({ shoulder, hand, side, color, skin, map }) => {
  const s = new THREE.Vector3(...shoulder);
  const h = new THREE.Vector3(...hand);
  const e = s.clone().lerp(h, 0.5).add(new THREE.Vector3(side * 0.06, -0.08, -0.02));
  const el: V3 = [e.x, e.y, e.z];
  return (
    <>
      <Limb from={shoulder} to={el} r={0.055} color={color} map={map} />
      <Limb from={el} to={hand} r={0.05} color={color} map={map} />
      <Hand p={hand} skin={skin} />
    </>
  );
};

export type Look = { hair: string; hairGrey?: number; top: string; pants: string; skin: string; dress?: boolean };

const greyHair = (hair: string, k = 0) => "#" + new THREE.Color(hair).lerp(new THREE.Color("#A8A8A8"), k).getHexString();

// head + hair group, local origin at the neck top
const Head: React.FC<{ look: Look; yaw?: number; pitch?: number }> = ({ look, yaw = 0, pitch = 0 }) => {
  const hair = greyHair(look.hair, look.hairGrey);
  return (
    <group rotation={[pitch, yaw, 0]}>
      <mesh position={[0, 0.13, 0.02]} castShadow>
        <icosahedronGeometry args={[0.12, 1]} />
        <meshStandardMaterial color={look.skin} roughness={0.8} flatShading />
      </mesh>
      <mesh position={[0, 0.17, -0.01]} scale={[1.08, 0.8, 1.1]} castShadow>
        <icosahedronGeometry args={[0.12, 1]} />
        <meshStandardMaterial color={hair} roughness={0.9} flatShading />
      </mesh>
      <mesh position={[0, 0.23, 0.07]} scale={[1, 0.35, 0.6]}>
        <icosahedronGeometry args={[0.1, 0]} />
        <meshStandardMaterial color={hair} roughness={0.9} flatShading />
      </mesh>
    </group>
  );
};

export type SeatedProps = {
  position: V3;
  yaw: number;
  // hand targets in the character's local space (hips at origin)
  handTarget: V3;
  handL?: V3;
  look: Look;
  lean?: number;
};

// Seated pose: hips on seat (local y = 0), thighs forward, shins down to floor at local y = -0.47
export const SeatedPerson: React.FC<SeatedProps> = ({ position, yaw, handTarget, handL = [-0.12, 0.1, 0.36], look, lean = 0 }) => {
  const knit = useMemo(() => weave([3, 3]), []);
  return (
    <group position={position} rotation={[0, yaw, 0]}>
      <group rotation={[0, 0, lean]}>
        <mesh position={[0, 0.08, 0]} castShadow>
          <boxGeometry args={[0.36, 0.16, 0.24]} />
          <meshStandardMaterial color={look.pants} roughness={0.85} flatShading />
        </mesh>
        <mesh position={[0, 0.34, 0]} scale={[1.25, 1, 0.72]} castShadow receiveShadow>
          <capsuleGeometry args={[0.15, 0.32, 4, 10]} />
          <meshStandardMaterial color={look.top} roughness={0.85} flatShading map={knit} />
        </mesh>
        <Limb from={[0, 0.6, 0]} to={[0, 0.72, 0.01]} r={0.055} color={look.skin} />
        <group position={[0, 0.66, 0]}>
          <Head look={look} />
        </group>
        <Arm shoulder={[-0.2, 0.5, 0]} hand={handL} side={-1} color={look.top} skin={look.skin} map={knit} />
        <Arm shoulder={[0.2, 0.5, 0]} hand={handTarget} side={1} color={look.top} skin={look.skin} map={knit} />
      </group>
      <Limb from={[-0.1, 0.05, 0]} to={[-0.1, 0.07, 0.45]} r={0.075} color={look.pants} />
      <Limb from={[0.1, 0.05, 0]} to={[0.1, 0.07, 0.45]} r={0.075} color={look.pants} />
      <Limb from={[-0.1, 0.06, 0.45]} to={[-0.11, -0.4, 0.48]} r={0.065} color={look.pants} />
      <Limb from={[0.1, 0.06, 0.45]} to={[0.11, -0.4, 0.48]} r={0.065} color={look.pants} />
      {[-0.11, 0.11].map((x) => (
        <mesh key={x} position={[x, -0.44, 0.53]} castShadow>
          <boxGeometry args={[0.1, 0.07, 0.22]} />
          <meshStandardMaterial color="#3A3330" roughness={0.9} flatShading />
        </mesh>
      ))}
    </group>
  );
};

export type StandingProps = {
  position: V3;
  yaw: number;
  look: Look;
  // hand targets in local space (feet at origin, facing +z)
  handR: V3;
  handL: V3;
  headYaw?: number;
  headPitch?: number;
  sway?: number; // whole-body rocking (radians about y)
  scale?: number;
};

export const StandingPerson: React.FC<StandingProps> = ({ position, yaw, look, handR, handL, headYaw = 0, headPitch = 0, sway = 0, scale = 1 }) => {
  const knit = useMemo(() => weave([3, 3]), []);
  return (
    <group position={position} rotation={[0, yaw + sway, 0]} scale={scale}>
      {[-0.1, 0.1].map((x) => (
        <React.Fragment key={x}>
          <Limb from={[x, 0.92, 0]} to={[x, 0.08, 0.01]} r={0.072} color={look.dress ? look.skin : look.pants} />
          <mesh position={[x, 0.035, 0.05]} castShadow>
            <boxGeometry args={[0.1, 0.07, 0.24]} />
            <meshStandardMaterial color="#3A3330" roughness={0.9} flatShading />
          </mesh>
        </React.Fragment>
      ))}
      {look.dress ? (
        <mesh position={[0, 0.88, 0]} castShadow>
          <cylinderGeometry args={[0.17, 0.3, 0.42, 10]} />
          <meshStandardMaterial color={look.top} roughness={0.85} flatShading map={knit} />
        </mesh>
      ) : (
        <mesh position={[0, 0.98, 0]} castShadow>
          <boxGeometry args={[0.36, 0.16, 0.24]} />
          <meshStandardMaterial color={look.pants} roughness={0.85} flatShading />
        </mesh>
      )}
      <mesh position={[0, 1.24, 0]} scale={[1.25, 1, 0.72]} castShadow receiveShadow>
        <capsuleGeometry args={[0.15, 0.32, 4, 10]} />
        <meshStandardMaterial color={look.top} roughness={0.85} flatShading map={knit} />
      </mesh>
      <Limb from={[0, 1.5, 0]} to={[0, 1.62, 0.01]} r={0.055} color={look.skin} />
      <group position={[0, 1.56, 0]}>
        <Head look={look} yaw={headYaw} pitch={headPitch} />
      </group>
      <Arm shoulder={[-0.2, 1.4, 0]} hand={handL} side={-1} color={look.top} skin={look.skin} map={knit} />
      <Arm shoulder={[0.2, 1.4, 0]} hand={handR} side={1} color={look.top} skin={look.skin} map={knit} />
    </group>
  );
};

// A pair of forearms + hands reaching in from outside the frame (memory beat, close-ups)
export const ReachingArms: React.FC<{ fromL: V3; fromR: V3; handL: V3; handR: V3; sleeve: string; skin: string }> = ({ fromL, fromR, handL, handR, sleeve, skin }) => {
  const knit = useMemo(() => weave([3, 3]), []);
  return (
    <>
      <Limb from={fromL} to={handL} r={0.05} color={sleeve} map={knit} />
      <Limb from={fromR} to={handR} r={0.05} color={sleeve} map={knit} />
      <Hand p={handL} skin={skin} />
      <Hand p={handR} skin={skin} />
    </>
  );
};
