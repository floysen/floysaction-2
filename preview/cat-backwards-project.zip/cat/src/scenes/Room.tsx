import * as THREE from "three";
import React, { useMemo } from "react";
import { random } from "remotion";
import { lawn, oakFloor, plaster, rugTex, textTex, weave } from "../three/textures";
import { SeatedPerson } from "../three/chars/Faceless";
import { Cat } from "../three/chars/Cat";
import { lerp, ramp } from "../lib/time";

type V3 = [number, number, number];

const Box: React.FC<{ p: V3; s: V3; c: string; map?: THREE.Texture; r?: number; shadow?: boolean }> = ({ p, s, c, map, r = 0.8, shadow = true }) => (
  <mesh position={p} castShadow={shadow} receiveShadow>
    <boxGeometry args={s} />
    <meshStandardMaterial color={c} roughness={r} flatShading map={map} />
  </mesh>
);

// sky seen through the window: dusk gradient + sun disc
const skyTex = () =>
  textTex("sky-dusk", 64, 256, (g) => {
    const gr = g.createLinearGradient(0, 0, 0, 256);
    gr.addColorStop(0, "#5A4A78");
    gr.addColorStop(0.45, "#C98A8A");
    gr.addColorStop(0.8, "#F2B07A");
    gr.addColorStop(1, "#F6C890");
    g.fillStyle = gr;
    g.fillRect(0, 0, 64, 256);
  });

const calendarTex = () =>
  textTex("cal-2025", 256, 320, (g) => {
    g.fillStyle = "#F4EEE4";
    g.fillRect(0, 0, 256, 320);
    g.fillStyle = "#C8463A";
    g.fillRect(0, 0, 256, 70);
    g.fillStyle = "#FFFFFF";
    g.font = "bold 44px sans-serif";
    g.textAlign = "center";
    g.fillText("2025", 128, 52);
    g.fillStyle = "#8A8070";
    for (let r = 0; r < 5; r++) for (let c = 0; c < 7; c++) g.fillRect(18 + c * 33, 96 + r * 42, 22, 22);
  });

const Tree: React.FC<{ p: V3; t: number; h: number; seed: string }> = ({ p, t, h, seed }) => {
  const sway = Math.sin(t * 0.75 + p[0] * 0.13 + p[2] * 0.07) * 0.16 * 0.45;
  return (
    <group position={p}>
      <mesh position={[0, h * 0.3, 0]}>
        <cylinderGeometry args={[0.12, 0.18, h * 0.6, 6]} />
        <meshStandardMaterial color="#4A3628" roughness={0.9} flatShading />
      </mesh>
      <mesh position={[sway, h * 0.75, 0]} rotation={[0, random(seed) * 3, sway * 0.3]}>
        <icosahedronGeometry args={[h * 0.32, 0]} />
        <meshStandardMaterial color="#3E5A3A" roughness={0.9} flatShading />
      </mesh>
      <mesh position={[sway * 1.2 + 0.3, h * 0.92, 0.2]}>
        <icosahedronGeometry args={[h * 0.2, 0]} />
        <meshStandardMaterial color="#4A6A42" roughness={0.9} flatShading />
      </mesh>
    </group>
  );
};

const Dust: React.FC<{ t: number }> = ({ t }) => {
  const geo = useMemo(() => new THREE.BufferGeometry(), []);
  const N = 220;
  const pos = new Float32Array(N * 3);
  for (let i = 0; i < N; i++) {
    const rx = random(`dx${i}`), ry = random(`dy${i}`), rz = random(`dz${i}`);
    const sp = 0.02 + random(`ds${i}`) * 0.03;
    pos[i * 3] = -1.0 + rx * 2.2 + Math.sin(t * 0.3 + i) * 0.05;
    pos[i * 3 + 1] = 0.2 + ((ry * 2.0 + t * sp) % 2.0);
    pos[i * 3 + 2] = -2.3 + rz * 2.6 + Math.cos(t * 0.25 + i * 1.7) * 0.05;
  }
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  return (
    <points geometry={geo}>
      <pointsMaterial color="#FFE2B0" size={0.012} transparent opacity={0.7} toneMapped={false} depthWrite={false} blending={THREE.AdditiveBlending} />
    </points>
  );
};

export const Room: React.FC<{ t: number }> = ({ t }) => {
  const floor = useMemo(() => oakFloor([3, 3]), []);
  const wall = useMemo(() => plaster([4, 2]), []);
  const sofaFab = useMemo(() => weave([4, 2]), []);
  const grass = useMemo(() => lawn([4, 4]), []);

  // ---- cat state (pure functions of t) ----
  const sit = t >= 6 ? 1 : 0;
  const lift = ramp(t, 5.6, 6.1);
  const stretch = ramp(t, 5.7, 6.0);
  const glowK = Math.min(1, Math.max(0, (t - 5.6) / 0.8));
  const glow = t >= 5.6 && t <= 6.4 ? Math.sin(Math.PI * glowK) * 0.6 : 0;
  const grey = t < 6.2 ? 0.6 : t < 10.3 ? lerp(0.6, 0.52, ramp(t, 6.2, 6.6)) : lerp(0.52, 0.2, ramp(t, 10.3, 11.0));

  // ---- person + stroking hand ----
  const personPos: V3 = [-0.42, 0.47, -0.4];
  const yaw = 0.35;
  const catPos: V3 = [0.2, 0.47, -0.36];
  const stroke = Math.sin(t * Math.PI * 2 / 1.2);
  const handWorld = sit
    ? new THREE.Vector3(catPos[0] - 0.08, catPos[1] + 0.2 + stroke * 0.04, catPos[2] - 0.04)
    : new THREE.Vector3(catPos[0] - 0.02 + stroke * 0.06, catPos[1] + 0.12, catPos[2] - 0.02);
  const local = handWorld.sub(new THREE.Vector3(...personPos)).applyAxisAngle(new THREE.Vector3(0, 1, 0), -yaw);
  const hand: V3 = [local.x, local.y, local.z];

  return (
    <group>
      {/* floor + rug */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[6, 5.2]} />
        <meshStandardMaterial color="#B98A5E" roughness={0.65} map={floor} envMapIntensity={0.5} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.006, 0.45]} receiveShadow>
        <planeGeometry args={[2.4, 1.6]} />
        <meshStandardMaterial color="#C9B79A" roughness={0.95} map={rugTex()} />
      </mesh>

      {/* back wall with window opening (x -1.2..1.2, y 0.7..2.3) */}
      <Box p={[-2.1, 1.35, -2.55]} s={[1.8, 2.7, 0.1]} c="#D8C8B2" map={wall} />
      <Box p={[2.1, 1.35, -2.55]} s={[1.8, 2.7, 0.1]} c="#D8C8B2" map={wall} />
      <Box p={[0, 0.35, -2.55]} s={[2.4, 0.7, 0.1]} c="#D8C8B2" map={wall} />
      <Box p={[0, 2.5, -2.55]} s={[2.4, 0.4, 0.1]} c="#D8C8B2" map={wall} />
      {/* window frame + mullions */}
      <Box p={[0, 0.7, -2.5]} s={[2.5, 0.06, 0.18]} c="#EDE6DA" r={0.6} />
      <Box p={[0, 2.3, -2.5]} s={[2.5, 0.06, 0.12]} c="#EDE6DA" r={0.6} />
      <Box p={[-1.22, 1.5, -2.5]} s={[0.06, 1.66, 0.12]} c="#EDE6DA" r={0.6} />
      <Box p={[1.22, 1.5, -2.5]} s={[0.06, 1.66, 0.12]} c="#EDE6DA" r={0.6} />
      <Box p={[0, 1.5, -2.52]} s={[0.05, 1.6, 0.06]} c="#EDE6DA" r={0.6} shadow={false} />
      <Box p={[0, 1.55, -2.52]} s={[2.4, 0.04, 0.06]} c="#EDE6DA" r={0.6} shadow={false} />
      {/* glass: very faint reflective sheet */}
      <mesh position={[0, 1.5, -2.53]}>
        <planeGeometry args={[2.4, 1.6]} />
        <meshStandardMaterial color="#FFFFFF" transparent opacity={0.08} roughness={0.08} metalness={0.1} depthWrite={false} envMapIntensity={1.4} />
      </mesh>
      {/* side walls */}
      <Box p={[-3.0, 1.35, 0]} s={[0.1, 2.7, 5.2]} c="#CDBBA4" map={wall} />
      <Box p={[3.0, 1.35, 0]} s={[0.1, 2.7, 5.2]} c="#CDBBA4" map={wall} />
      {/* skirting */}
      <Box p={[0, 0.05, -2.48]} s={[6, 0.1, 0.03]} c="#EDE6DA" />

      {/* outside: lawn, fence, trees, sky, sun */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.02, -9]}>
        <planeGeometry args={[30, 13]} />
        <meshStandardMaterial color="#4E6A3E" roughness={0.9} map={grass} />
      </mesh>
      {Array.from({ length: 16 }, (_, i) => (
        <Box key={i} p={[-6 + i * 0.8, 0.5, -6]} s={[0.12, 1.0, 0.05]} c="#8A6A4A" shadow={false} />
      ))}
      <Box p={[0, 0.8, -6]} s={[13, 0.08, 0.04]} c="#8A6A4A" shadow={false} />
      <Tree p={[-2.2, 0, -7.5]} t={t} h={4.2} seed="t1" />
      <Tree p={[2.6, 0, -9]} t={t} h={5} seed="t2" />
      <Tree p={[0.4, 0, -12]} t={t} h={3.6} seed="t3" />
      <mesh position={[0, 4, -16]}>
        <planeGeometry args={[40, 14]} />
        <meshBasicMaterial map={skyTex()} toneMapped={false} fog={false} />
      </mesh>
      <mesh position={[-1.6, 2.0, -15.8]}>
        <circleGeometry args={[0.5, 24]} />
        <meshBasicMaterial color={new THREE.Color("#FFE0A8").multiplyScalar(2.4)} toneMapped={false} fog={false} />
      </mesh>

      {/* radiator + cat bed under the window */}
      <Box p={[0, 0.38, -2.42]} s={[1.4, 0.5, 0.08]} c="#E6E0D6" r={0.5} />
      <mesh position={[-0.9, 0.06, -2.1]} receiveShadow castShadow>
        <cylinderGeometry args={[0.28, 0.24, 0.12, 10]} />
        <meshStandardMaterial color="#A33A2E" roughness={0.9} flatShading map={sofaFab} />
      </mesh>
      <mesh position={[0.9, 0.03, -2.0]} castShadow>
        <cylinderGeometry args={[0.1, 0.08, 0.06, 10]} />
        <meshStandardMaterial color="#6F9BD8" roughness={0.4} />
      </mesh>

      {/* sofa (seat top y = 0.47) */}
      <Box p={[0, 0.18, -0.4]} s={[2.1, 0.32, 0.9]} c="#4E6A68" map={sofaFab} />
      <Box p={[-0.5, 0.41, -0.36]} s={[0.98, 0.13, 0.8]} c="#5E7C7A" map={sofaFab} />
      <Box p={[0.5, 0.41, -0.36]} s={[0.98, 0.13, 0.8]} c="#5E7C7A" map={sofaFab} />
      <Box p={[0, 0.66, -0.78]} s={[2.1, 0.62, 0.22]} c="#5A7674" map={sofaFab} />
      <Box p={[-1.1, 0.5, -0.4]} s={[0.2, 0.32, 0.9]} c="#4E6A68" map={sofaFab} />
      <Box p={[1.1, 0.5, -0.4]} s={[0.2, 0.32, 0.9]} c="#4E6A68" map={sofaFab} />
      {/* throw blanket */}
      <Box p={[0.75, 0.49, -0.4]} s={[0.5, 0.04, 0.78]} c="#C98A5A" map={sofaFab} />

      {/* floor lamp (emissive shade + warm point light) */}
      <Box p={[1.45, 0.02, -1.15]} s={[0.3, 0.04, 0.3]} c="#2E2A28" />
      <mesh position={[1.45, 0.78, -1.15]}>
        <cylinderGeometry args={[0.015, 0.015, 1.5, 6]} />
        <meshStandardMaterial color="#2E2A28" metalness={0.4} roughness={0.4} />
      </mesh>
      <mesh position={[1.45, 1.6, -1.15]}>
        <cylinderGeometry args={[0.16, 0.24, 0.3, 12, 1, true]} />
        <meshBasicMaterial color={new THREE.Color("#F2D27A").multiplyScalar(1.6 + Math.sin(t * 7.3) * 0.02)} toneMapped={false} side={THREE.DoubleSide} />
      </mesh>
      <pointLight position={[1.45, 1.5, -1.15]} color="#FFC478" intensity={2.6} distance={7} decay={1.6} />

      {/* counter (open kitchen) */}
      <Box p={[-2.6, 0.45, -0.3]} s={[0.7, 0.9, 2.4]} c="#8A5A35" />
      <Box p={[-2.6, 0.92, -0.3]} s={[0.78, 0.05, 2.5]} c="#E8DCC8" r={0.35} />
      {[-1.1, -0.3, 0.5].map((z, i) => (
        <Box key={i} p={[-2.24, 0.45, z]} s={[0.02, 0.8, 0.02]} c="#5A3A22" shadow={false} />
      ))}
      <Box p={[-2.0, 0.22, 0.6]} s={[0.35, 0.44, 0.3]} c="#7A6A5A" />

      {/* cat tree */}
      <Box p={[2.35, 0.7, -2.05]} s={[0.1, 1.4, 0.1]} c="#B8A27E" />
      <Box p={[2.35, 0.03, -2.05]} s={[0.6, 0.06, 0.6]} c="#8A6A4A" />
      <Box p={[2.35, 0.75, -2.05]} s={[0.5, 0.05, 0.5]} c="#8A6A4A" />
      <Box p={[2.35, 1.42, -2.05]} s={[0.55, 0.05, 0.55]} c="#8A6A4A" />

      {/* calendar + photo frames (1 of 6 filled) */}
      <mesh position={[-1.8, 1.6, -2.495]}>
        <planeGeometry args={[0.32, 0.4]} />
        <meshStandardMaterial map={calendarTex()} roughness={0.8} />
      </mesh>
      {Array.from({ length: 6 }, (_, i) => {
        const x = 1.55 + (i % 3) * 0.32;
        const y = 1.85 - Math.floor(i / 3) * 0.36;
        return (
          <group key={i} position={[x, y, -2.49]}>
            <Box p={[0, 0, 0]} s={[0.26, 0.3, 0.02]} c="#2E2A28" shadow={false} />
            <mesh position={[0, 0, 0.012]}>
              <planeGeometry args={[0.2, 0.24]} />
              <meshStandardMaterial color={i === 0 ? "#C98A5A" : "#EDE6DA"} roughness={0.5} />
            </mesh>
          </group>
        );
      })}

      {/* bookshelf on the right wall */}
      <Box p={[2.8, 0.9, 0.9]} s={[0.35, 1.8, 1.0]} c="#6A4A32" />
      {Array.from({ length: 18 }, (_, i) => {
        const shelf = Math.floor(i / 6);
        const k = i % 6;
        const cols = ["#C8463A", "#6F9BD8", "#E8C04A", "#7FBF7A", "#EDE6DA", "#8A5A35"];
        return (
          <Box key={i} p={[2.6, 0.4 + shelf * 0.5 + 0.12, 0.55 + k * 0.13]} s={[0.04, 0.24 + random(`bh${i}`) * 0.06, 0.1]} c={cols[(i * 5) % 6]} shadow={false} />
        );
      })}

      {/* characters */}
      <SeatedPerson position={personPos} yaw={yaw} handTarget={hand} hair="#5A3A28" sweater="#C98A3A" pants="#2E3A4A" skin="#C99A7A" lean={-0.06} />
      <Cat position={catPos} yaw={sit ? -0.25 : 0.6} t={t} sit={sit} lift={lift} stretch={stretch} grey={grey} glow={glow} />

      <Dust t={t} />
    </group>
  );
};
