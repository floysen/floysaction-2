# Render the full video on your computer

You need **Node.js 18 or newer** (https://nodejs.org).

1. Unzip to a **short path**, e.g. `C:\wv\mind` (long paths break `npm i` on Windows).
   This is a separate project from the cat video: use its own folder.
2. Open **Git Bash** in that folder and run:

```
bash render_full.sh
```

It installs packages if needed, renders all 2220 frames, masters the sound to -16 LUFS
and prints the measured loudness. The finished video is:

`out/one-mind_en_74s.mp4` (74 s, 1080x1920, 30 fps, H.264 + AAC)

Only want a part? Example for 0-10 s:
`npx remotion render WhatIf out/part.mp4 --frames=0-299 --gl=angle`

Live preview with a timeline: `npx remotion studio`

If the picture comes out black, edit `render_full.sh` and replace `--gl=angle` with `--gl=swangle`.

Sound note: every sound is synthesised (no recordings are used), so no credits are needed.
