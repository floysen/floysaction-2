// Look test for the realistic kit: HDR sky, PBR ground + buildings, real trees, water, birds,
// rigged people (mannequin + realistic) with deterministic Mixamo animation and face mosaic.
import * as THREE from "three";
import React, { useLayoutEffect } from "react";
import { AbsoluteFill, getInputProps, useCurrentFrame } from "remotion";
import { ThreeCanvas } from "@remotion/three";
import { useThree } from "@react-three/fiber";
import { Sky } from "./kit/Sky";
import { Character, ModelName } from "./kit/Character";
import { FaceTracker } from "./kit/FaceBlur";
import { Birds, Tree, Water } from "./kit/Nature";
import { Building, Ground } from "./kit/Surfaces";
import { RealPost, RendererSetup } from "./kit/Post";

const FPS = 30;
const PREVIEW = Boolean((getInputProps() as { preview?: boolean }).preview);

const SHOT = ((getInputProps() as { shot?: string }).shot ?? "wide") as "wide" | "faces";
const Cam: React.FC<{ t: number }> = ({ t }) => {
  const { camera } = useThree();
  useLayoutEffect(() => {
    const k = t / 8;
    const cam = camera as THREE.PerspectiveCamera;
    if (SHOT === "faces") {
      // close on the soldier walking along lane 1.2 (x = -6 + 1.25 t)
      const x = -6 + 1.25 * t;
      cam.position.set(x + 2.2, 1.65, 4.2);
      cam.lookAt(x + 0.2, 1.45, 1.6);
      cam.fov = 38;
    } else {
      cam.position.set(-1 + k * 0.8, 2.3, 15 - k * 1.5);
      cam.lookAt(1.5, 3.2, -4);
      cam.fov = 52;
    }
    cam.near = 0.05;
    cam.far = 600;
    cam.updateProjectionMatrix();
  }, [t, camera]);
  return null;
};

const PEOPLE: { model: ModelName; lane: number; x0: number; speed: number; dir: number; tint?: string }[] = [
  { model: "soldier", lane: 1.2, x0: -6, speed: 1.25, dir: 1 },
  { model: "michelle", lane: 2.6, x0: 5, speed: 1.15, dir: -1 },
  { model: "xbot", lane: 0.2, x0: 2, speed: 1.3, dir: -1, tint: "#B8B0A6" },
  { model: "xbot", lane: 3.8, x0: -3, speed: 1.2, dir: 1, tint: "#6F8AA8" },
  { model: "soldier", lane: -1.0, x0: 7, speed: 1.1, dir: -1 },
  { model: "michelle", lane: -2.2, x0: -8, speed: 1.2, dir: 1 },
  { model: "xbot", lane: 5.2, x0: 0, speed: 1.0, dir: 1, tint: "#A8583A" },
];

export const KitTest: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  return (
    <AbsoluteFill style={{ backgroundColor: "#000" }}>
      <ThreeCanvas width={1080} height={1920} shadows gl={{ antialias: true, preserveDrawingBuffer: true }} camera={{ fov: 44, near: 0.05, far: 600 }}>
        <RendererSetup />
        <Cam t={t} />
        <Sky name="plaza" intensity={1.0} rotation={1.2} />
        <hemisphereLight args={["#DDE6F0", "#6A6050", 0.25]} />
        <directionalLight position={[-18, 22, 10]} intensity={2.4} color="#FFF0DC" castShadow shadow-mapSize={[PREVIEW ? 2048 : 4096, PREVIEW ? 2048 : 4096]}
          shadow-camera-left={-25} shadow-camera-right={25} shadow-camera-top={25} shadow-camera-bottom={-25} shadow-camera-far={90} shadow-bias={-0.0004} shadow-normalBias={0.03} />
        <Ground kind="paving" size={[80, 80]} repeat={[40, 40]} />
        <Ground kind="asphalt" size={[80, 6]} repeat={[24, 2]} position={[0, 0.005, 9.5]} />
        <Building position={[-9, 0, -14]} size={[12, 16, 8]} wall="brick" seed="b1" />
        <Building position={[5, 0, -16]} size={[14, 22, 8]} wall="plaster" tint="#E8DCC8" seed="b2" />
        <Building position={[17, 0, -10]} size={[8, 12, 10]} wall="concrete" seed="b3" rotation={-0.5} />
        {/* fountain basin with real water */}
        <mesh position={[2.5, 0.25, -3]} castShadow receiveShadow>
          <cylinderGeometry args={[2.4, 2.5, 0.5, 40, 1, true]} />
          <meshStandardMaterial color="#D8D2C8" roughness={0.6} side={THREE.DoubleSide} />
        </mesh>
        <mesh position={[2.5, 0.5, -3]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[2.3, 2.6, 40]} />
          <meshStandardMaterial color="#E4DED4" roughness={0.5} />
        </mesh>
        <Water position={[2.5, 0.4, -3]} size={[5, 5]} circle={2.35} t={t} sun={[-18, 22, 10]} />
        <Tree preset="Oak Medium" seed={3} position={[-5, 0, -5]} t={t} scale={0.9} />
        <Tree preset="Ash Medium" seed={7} position={[8, 0, -6]} t={t} scale={0.85} rotation={1.3} />
        <Tree preset="Aspen Medium" seed={11} position={[-9, 0, 2]} t={t} scale={0.8} />
        <Tree preset="Bush 2" seed={2} position={[6, 0, 2.5]} t={t} scale={0.9} />
        {PEOPLE.map((p, i) => {
          const x = p.x0 + p.dir * p.speed * t;
          return (
            <Character key={i} id={`p${i}`} model={p.model} position={[x, 0, p.lane]} yaw={p.dir > 0 ? Math.PI / 2 : -Math.PI / 2}
              clips={[{ clip: p.model === "soldier" ? "Walk" : "walk", time: t + i * 0.31, speed: p.speed / 1.2 }]} tint={p.tint} />
          );
        })}
        <Character id="idle" model="xbot" position={[0.2, 0, 5.2]} yaw={0.6} clips={[{ clip: "idle", time: t }]} tint="#7FA07A" />
        <Birds kind="Stork" count={5} t={t} scale={0.025} path={(i, tt) => ({ pos: [-20 + tt * 4 + i * 1.6, 14 + Math.sin(tt + i) * 0.6 + i * 0.4, -12 - i * 1.3], yaw: Math.PI / 2 })} />
        <FaceTracker />
        <RealPost preview={PREVIEW} />
      </ThreeCanvas>
    </AbsoluteFill>
  );
};
